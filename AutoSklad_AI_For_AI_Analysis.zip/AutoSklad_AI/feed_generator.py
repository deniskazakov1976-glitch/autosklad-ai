"""
Модуль 3: feed_generator.py
Платформа «АВТОСКЛАД-ИИ»
Генератор боевых фидов автозагрузки для маркетплейсов:
1. Дедупликация и объединение строк 1С по master_id (защита от бана Авито за дублирование)
2. Фильтры безопасности: stock_qty >= 1, price_retail >= 300 руб.
3. Генерация валидного XML-фида для Авито (Avito Autoload v3) с CDATA-описанием
4. Генерация CSV-прайс-листа для Базы.Дром (baza.drom.ru / FarPost) в utf-8-sig
5. Генерация интерактивной витрины предпросмотра feeds_preview.html
"""

import os
import sys
import json
import sqlite3
import argparse
import csv
import math
import re
from datetime import datetime
from typing import Dict, List, Any, Tuple
import pandas as pd
from jinja2 import Template
import xml.etree.ElementTree as ET
from config import DB_PATH, STORE_ADDRESS, STORE_PHONE
from inventory_guard import clean_avito_title, sanitize_xml_string, detect_and_read_1c_file, parse_1c_number

DEFAULT_ADDRESS = STORE_ADDRESS
DEFAULT_PHONE = STORE_PHONE


class FeedGenerator:
    def __init__(
        self,
        db_path: str = DB_PATH,
        client_id: str = "client_main",
        address: str = DEFAULT_ADDRESS,
        phone: str = DEFAULT_PHONE
    ):
        self.db_path = db_path
        self.client_id = client_id
        self.address = address
        self.phone = phone
        self.master_records: Dict[str, Dict[str, Any]] = {}
        self.load_master_catalog()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=30000;")
        return conn

    def load_master_catalog(self) -> None:
        """Загружает эталонные карточки из SQLite master_catalog."""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        rows = cursor.execute("SELECT * FROM master_catalog").fetchall()
        conn.close()

        for r in rows:
            cols = r.keys()
            oem_disp = r["oem_display"] if "oem_display" in cols and r["oem_display"] else r["oem_number"]
            self.master_records[r["master_id"]] = {
                "master_id": r["master_id"],
                "canonical_title": r["canonical_title"],
                "oem_display": oem_disp,
                "oem_number": oem_disp,
                "oem_normalized": r["oem_number"],
                "cross_numbers": json.loads(r["cross_numbers"]),
                "brands_analogs": json.loads(r["brands_analogs"]),
                "applicability": r["applicability"],
                "avito_category": r["avito_category"],
                "image_urls": json.loads(r["image_urls"]),
            }

    def aggregate_and_filter(self, df_1c: pd.DataFrame) -> Dict[str, Any]:
        """
        Агрегирует строки 1С по master_id (дедупликация дублей 1С) и применяет фильтры безопасности.
        """
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        mappings = cursor.execute(
            "SELECT raw_code, master_id, match_stage FROM client_sku_mapping WHERE client_id = ?",
            (self.client_id,)
        ).fetchall()
        conn.close()

        mapping_dict = {r["raw_code"]: r["master_id"] for r in mappings}

        # Группировка
        grouped: Dict[str, Dict[str, Any]] = {}
        unmatched_rows = []
        zero_stock_filtered = []
        cheap_filtered = []

        for _, row in df_1c.iterrows():
            raw_code = str(row.get("Код", row.get("raw_code", ""))).strip()
            raw_name = str(row.get("Наименование", row.get("raw_name", ""))).strip()
            raw_art = str(row.get("Артикул", row.get("raw_article", ""))).strip()
            stock_qty = float(row.get("Остаток", row.get("stock_qty", 0.0)))
            price_retail = float(row.get("ЦенаРозница", row.get("price_retail", 0.0)))
            price_cost_raw = row.get("ЦенаЗакупки", row.get("price_cost", 0.0))
            price_cost = parse_1c_number(price_cost_raw, round(price_retail * 0.72, 2))
            if price_cost <= 0.0 and price_retail > 0.0:
                price_cost = round(price_retail * 0.72, 2)
            sales_12m = float(row.get("Продажи12мес", row.get("sales_12m", 0.0)))
            days_no_movement = int(row.get("ДнейБезДвижения", row.get("days_no_movement", 0)))

            master_id = mapping_dict.get(raw_code)
            if not master_id or master_id not in self.master_records:
                unmatched_rows.append({
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "stock_qty": stock_qty
                })
                continue

            if master_id not in grouped:
                grouped[master_id] = {
                    "master_id": master_id,
                    "total_stock": 0.0,
                    "max_price": 0.0,
                    "min_price": float("inf"),
                    "max_cost": 0.0,
                    "source_1c_codes": set(),
                    "source_items": [],
                    "has_dead_stock": False,
                    "sales_12m_total": 0.0,
                    "max_days_no_movement": 0
                }

            g = grouped[master_id]
            g["total_stock"] += stock_qty
            g["max_cost"] = max(g.get("max_cost", 0.0), price_cost)
            g["source_1c_codes"].add(raw_code)
            g["source_items"].append({
                "raw_code": raw_code,
                "raw_name": raw_name,
                "raw_article": raw_art,
                "stock_qty": stock_qty,
                "price_retail": price_retail,
                "price_cost": price_cost,
                "sales_12m": sales_12m,
                "days_no_movement": days_no_movement
            })

            if stock_qty > 0:
                g["max_price"] = max(g["max_price"], price_retail)
                g["min_price"] = min(g["min_price"], price_retail)
            elif g["max_price"] == 0:
                g["max_price"] = max(g["max_price"], price_retail)

            if sales_12m == 0 or days_no_movement >= 270:
                g["has_dead_stock"] = True

            g["sales_12m_total"] += sales_12m
            g["max_days_no_movement"] = max(g["max_days_no_movement"], days_no_movement)

        # Применение фильтров безопасности
        feed_items: List[Dict[str, Any]] = []

        for master_id, g in grouped.items():
            master = self.master_records[master_id]
            final_price = g["max_price"] if g["max_price"] > 0 else 0.0
            total_stock = g["total_stock"]

            # Фильтр 1: Остаток >= 1 шт.
            if total_stock < 1.0:
                zero_stock_filtered.append({
                    "master_id": master_id,
                    "title": master["canonical_title"],
                    "total_stock": total_stock,
                    "source_codes": list(g["source_1c_codes"])
                })
                continue

            # Фильтр 2: Цена >= 300 ₽
            if final_price < 300.0:
                cheap_filtered.append({
                    "master_id": master_id,
                    "title": master["canonical_title"],
                    "price": final_price,
                    "stock": total_stock
                })
                continue

            # MarginFloorGuard: Защита маржинальности (не продавать в минус)
            margin_guard_triggered = False
            cost_floor = g.get("max_cost", final_price * 0.72)

            # Если в 1С розничная цена ошибочно ниже закупа:
            if final_price < cost_floor:
                final_price = math.ceil(max(final_price, cost_floor * 1.10))
                margin_guard_triggered = True

            # Расчет промо-цены для быстрого слива неликвида (скидка 10% с округлением)
            promo_price = None
            if g["has_dead_stock"]:
                discounted = round(final_price * 0.90, -1)
                # Промо-цена не должна опускаться ниже 105% себестоимости
                if discounted < cost_floor * 1.05:
                    promo_price = math.ceil(cost_floor * 1.05)
                    margin_guard_triggered = True
                else:
                    promo_price = discounted

            # Ограничение длины заголовка для Авито (строго до 50 символов по границе слова)
            avito_title = clean_avito_title(master["canonical_title"], max_len=50)

            primary_brand = master["brands_analogs"][0] if master["brands_analogs"] else "Россия"

            # Описание
            description = self.build_avito_description(
                master=master,
                stock_qty=int(total_stock),
                source_codes=sorted(list(g["source_1c_codes"])),
                is_dead_stock=g["has_dead_stock"]
            )

            feed_items.append({
                "master_id": master_id,
                "canonical_title": master["canonical_title"],
                "avito_title": avito_title,
                "oem_display": master.get("oem_display", master["oem_number"]),
                "oem_number": master.get("oem_display", master["oem_number"]),
                "oem_normalized": master.get("oem_normalized", master["oem_number"]),
                "cross_numbers": master["cross_numbers"],
                "brands_analogs": master["brands_analogs"],
                "primary_brand": primary_brand,
                "applicability": master["applicability"],
                "avito_category": master["avito_category"],
                "image_urls": master["image_urls"],
                "total_stock": int(total_stock),
                "price_retail": int(final_price),
                "price_cost": cost_floor,
                "promo_price": int(promo_price) if promo_price else None,
                "margin_guard_triggered": margin_guard_triggered,
                "is_dead_stock": g["has_dead_stock"],
                "source_1c_codes": sorted(list(g["source_1c_codes"])),
                "merged_count": len(g["source_1c_codes"]),
                "description": description
            })

        feed_items.sort(key=lambda x: (not x["is_dead_stock"], -x["price_retail"]))

        total_valuation = sum(item["price_retail"] * item["total_stock"] for item in feed_items)
        total_units = sum(item["total_stock"] for item in feed_items)
        dead_units = sum(item["total_stock"] for item in feed_items if item["is_dead_stock"])

        return {
            "feed_items": feed_items,
            "total_feed_skus": len(feed_items),
            "total_feed_units": total_units,
            "total_feed_valuation": total_valuation,
            "dead_stock_skus": sum(1 for it in feed_items if it["is_dead_stock"]),
            "dead_stock_units": dead_units,
            "zero_stock_filtered": zero_stock_filtered,
            "cheap_filtered": cheap_filtered,
            "unmatched_rows": unmatched_rows,
            "merged_clusters_count": sum(1 for it in feed_items if it["merged_count"] > 1)
        }

    def build_avito_description(
        self,
        master: Dict[str, Any],
        stock_qty: int,
        source_codes: List[str],
        is_dead_stock: bool
    ) -> str:
        """Собирает продающий структурированный текст объявления по канону автозапчастей."""
        cross_str = ", ".join(master["cross_numbers"]) if master["cross_numbers"] else "нет данных"
        brands_str = ", ".join(master["brands_analogs"]) if master["brands_analogs"] else "Россия"
        codes_str = ", ".join(source_codes)

        promo_block = ""
        if is_dead_stock:
            promo_block = "⚡ РАСПРОДАЖА СКЛАДСКИХ ЗАПАСОВ: Деталь из наличия по специальной сниженной цене!\n\n"

        desc = (
            f"✅ В НАЛИЧИИ: {master['canonical_title']}\n"
            f"Состояние: Новое в заводской упаковке.\n"
            f"Актуальный остаток на полке магазина: {stock_qty} шт.\n\n"
            f"{promo_block}"
            f"🔧 ПРИМЕНЯЕМОСТЬ (Автомобили и Двигатели):\n"
            f"{master['applicability']}\n\n"
            f"🔎 ЗАВОДСКИЕ НОМЕРА И КРОСС-АРТИКУЛЫ (для поиска аналогов):\n"
            f"Основной OEM: {master['oem_number']}\n"
            f"Кроссы и взаимозаменяемые номера: {cross_str}\n"
            f"Производители в наличии и под заказ: {brands_str}\n\n"
            f"📌 Коды детали в учетной системе 1С: {codes_str}\n\n"
            f"⚡ СВЯЗЬ И БРОНИРОВАНИЕ:\n"
            f"Напишите нам в чат Авито прямо сейчас — наш автоматический помощник за 5 секунд проверит актуальный остаток на кассе, подберет проверенный аналог и забронирует товар до вашего приезда!\n\n"
            f"📦 ДОСТАВКА И САМОВЫВОЗ:\n"
            f"• Самовывоз: {self.address}\n"
            f"• Авито-Доставка по всей России: СДЭК, Почта России, Boxberry, DPD, Яндекс Доставка.\n"
            f"• Отправка Транспортными Компаниями (Деловые Линии, КИТ, ПЭК, Энергия) в день заказа."
        )
        return desc

    def generate_avito_xml(self, feed_data: Dict[str, Any], output_path: str = "avito_feed.xml") -> str:
        """Генерирует валидный XML по официальному стандарту Avito Автозагрузка v3 через ElementTree."""
        items = feed_data["feed_items"]
        ads = ET.Element("Ads", formatVersion="3", target="Avito.ru")

        for it in items:
            ad = ET.SubElement(ads, "Ad")
            ET.SubElement(ad, "Id").text = str(it["master_id"])
            ET.SubElement(ad, "Category").text = "Запчасти и аксессуары"
            ET.SubElement(ad, "GoodsType").text = "Запчасти"
            ET.SubElement(ad, "AdType").text = "Товар приобретен на продажу"
            ET.SubElement(ad, "ProductType").text = "Для автомобилей"
            ET.SubElement(ad, "Condition").text = "Новое"
            ET.SubElement(ad, "OEM").text = str(it.get("oem_display") or it.get("oem_number") or "")
            ET.SubElement(ad, "Brand").text = str(it["primary_brand"])
            ET.SubElement(ad, "Title").text = str(it["avito_title"])

            # Если позиция - неликвид со скидкой, выгружаем реальную промо-цену!
            final_price = it["promo_price"] if (it.get("is_dead_stock") and it.get("promo_price")) else it["price_retail"]
            ET.SubElement(ad, "Price").text = str(int(final_price))
            ET.SubElement(ad, "Stock").text = str(int(it["total_stock"]))
            ET.SubElement(ad, "Address").text = str(self.address)
            ET.SubElement(ad, "ContactPhone").text = str(self.phone)

            clean_desc = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(it["description"]))
            desc_el = ET.SubElement(ad, "Description")
            desc_el.text = clean_desc

            if it.get("image_urls"):
                imgs_el = ET.SubElement(ad, "Images")
                for img in it["image_urls"]:
                    clean_img = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(img)).strip()
                    if clean_img:
                        ET.SubElement(imgs_el, "Image", url=clean_img)

        # Безопасная сериализация с XML declaration
        ET.indent(ads, space="  ", level=0)
        xml_bytes = ET.tostring(ads, encoding="utf-8", xml_declaration=True)

        with open(output_path, "wb") as f:
            f.write(xml_bytes)

        return output_path

    def generate_drom_csv(self, feed_data: Dict[str, Any], output_path: str = "drom_feed.csv") -> str:
        """Генерирует прайс-лист для baza.drom.ru / FarPost в формате utf-8-sig с защитой от CSV Formula Injection."""
        items = feed_data["feed_items"]

        def sanitize_csv_cell(val: Any) -> str:
            s = str(val) if val is not None else ""
            if s and s[0] in ("=", "+", "-", "@", "\t", "\r"):
                return "'" + s
            return s

        headers = [
            "Артикул (OEM)",
            "Кросс-номера",
            "Наименование",
            "Производитель",
            "Применяемость (Марка/Модель/Двигатель)",
            "Состояние",
            "Цена",
            "Наличие (шт)",
            "Коды в 1С",
            "Фото URL",
            "Описание"
        ]

        with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(headers)

            for it in items:
                cross_str = ", ".join(it["cross_numbers"])
                photos_str = " ".join(it["image_urls"])
                codes_str = ", ".join(it["source_1c_codes"])
                clean_desc = it["description"].replace("\n", " ").replace(";", ",")
                final_price = it["promo_price"] if (it.get("is_dead_stock") and it.get("promo_price")) else it["price_retail"]
                oem_val = it.get("oem_display") or it.get("oem_number") or ""

                writer.writerow([
                    sanitize_csv_cell(oem_val),
                    sanitize_csv_cell(cross_str),
                    sanitize_csv_cell(it["canonical_title"]),
                    sanitize_csv_cell(it["primary_brand"]),
                    sanitize_csv_cell(it["applicability"]),
                    "Новое",
                    int(final_price),
                    int(it["total_stock"]),
                    sanitize_csv_cell(codes_str),
                    photos_str,
                    sanitize_csv_cell(clean_desc)
                ])

        return output_path

    def generate_preview_html(self, feed_data: Dict[str, Any], output_path: str = "feeds_preview.html") -> str:
        """Генерирует интерактивную витрину предпросмотра объявлений Авито и Дрома."""
        template_str = """
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Витрина объявлений Авито и Дром • АВТОСКЛАД-ИИ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@500;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #070a10; color: #f1f5f9; }
    .mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="p-3 sm:p-8">

  <div class="max-w-7xl mx-auto">
    <!-- ШАПКА МОДУЛЯ -->
    <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
      <div class="flex items-center gap-3">
        <span class="bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 text-xs font-black px-3 py-1.5 rounded-lg tracking-wider uppercase shadow">
          ★ МОДУЛЬ 3: FEED_GENERATOR
        </span>
        <span class="text-sm text-slate-400">Форматы: <b class="text-white">Avito XML v3</b> + <b class="text-white">Drom CSV</b></span>
      </div>
      <div class="flex flex-wrap gap-2 text-xs">
        <a href="avito_feed.xml" download class="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow">
          📥 Скачать avito_feed.xml
        </a>
        <a href="drom_feed.csv" download class="bg-sky-600 hover:bg-sky-500 text-white font-black px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow">
          📥 Скачать drom_feed.csv
        </a>
        <a href="index.html" class="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold px-4 py-2 rounded-xl transition">
          Главная ➔
        </a>
      </div>
    </div>

    <!-- ТИТУЛЬНЫЙ БЛОК И KPI ВИТРИНЫ -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl relative overflow-hidden">
      <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-6 mb-6">
        <div>
          <div class="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
            Защита от бана за дубли • Автоматическая дедупликация 1С
          </div>
          <h1 class="text-xl sm:text-3xl font-black text-white">
            Интерактивная витрина готовых объявлений для Авито и Дрома
          </h1>
          <p class="text-slate-400 text-sm mt-1">
            Все дубли 1С объединены в единые карточки с суммированием остатка и привязкой фото
          </p>
        </div>
        <div class="text-right">
          <div class="text-3xl sm:text-4xl font-black text-emerald-400 mono">
            {{ "{:,.0f}".format(data.total_feed_valuation).replace(',', ' ') }} ₽
          </div>
          <div class="text-xs text-slate-400">Общая сумма товаров на витрине</div>
        </div>
      </div>

      <!-- 4 КАРТОЧКИ KPI -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div class="text-[11px] font-bold text-slate-400 uppercase">Готово объявлений к выгрузке</div>
          <div class="text-2xl font-black text-white mono mt-1">{{ data.total_feed_skus }} SKU</div>
          <div class="text-[11px] text-emerald-400 mt-1">{{ data.total_feed_units }} шт. деталей на полках</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-cyan-500/40">
          <div class="text-[11px] font-bold text-cyan-400 uppercase">Склеено дублей в 1С</div>
          <div class="text-2xl font-black text-cyan-400 mono mt-1">{{ data.merged_clusters_count }} групп</div>
          <div class="text-[11px] text-slate-400 mt-1">Защита от бана Авито за дубли</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-orange-500/40">
          <div class="text-[11px] font-bold text-orange-400 uppercase">Неликвиды на распродажу</div>
          <div class="text-2xl font-black text-orange-400 mono mt-1">{{ data.dead_stock_skus }} SKU</div>
          <div class="text-[11px] text-slate-400 mt-1">{{ data.dead_stock_units }} шт. на слив со спецценой</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-red-500/30">
          <div class="text-[11px] font-bold text-red-400 uppercase">Отсеяно фильтрами</div>
          <div class="text-2xl font-black text-red-400 mono mt-1">{{ data.zero_stock_filtered|length + data.cheap_filtered|length }} SKU</div>
          <div class="text-[11px] text-slate-400 mt-1">Остаток 0 шт. (не сжигает лимиты)</div>
        </div>
      </div>
    </div>

    <!-- ВИТРИНА КАРТОЧЕК ОБЪЯВЛЕНИЙ -->
    <div class="mb-8">
      <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h2 class="text-lg sm:text-2xl font-black text-white">Превью карточек на витрине Авито</h2>
          <p class="text-xs text-slate-400">Нажмите «Посмотреть текст Авито», чтобы раскрыть полное форматированное описание</p>
        </div>
        <div class="text-xs text-slate-400 font-mono">
          Адрес: <b class="text-slate-200">{{ address }}</b>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {% for item in data.feed_items %}
        <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl hover:border-slate-700 transition flex flex-col justify-between">
          <div>
            <!-- ФОТО ТОВАРА -->
            <div class="relative h-48 bg-slate-950 overflow-hidden">
              {% if item.image_urls %}
                <img src="{{ item.image_urls[0] }}" alt="{{ item.canonical_title }}" class="w-full h-full object-cover" />
              {% else %}
                <div class="flex items-center justify-center h-full text-slate-600 font-bold text-xs">НЕТ ФОТО</div>
              {% endif %}

              <div class="absolute top-3 left-3 flex flex-col gap-1.5">
                {% if item.is_dead_stock %}
                  <span class="bg-orange-500 text-slate-950 font-black text-[10px] uppercase px-2.5 py-1 rounded-md shadow">
                    🔥 Распродажа запасов
                  </span>
                {% endif %}
                {% if item.merged_count > 1 %}
                  <span class="bg-cyan-500/90 text-slate-950 font-black text-[10px] uppercase px-2 py-0.5 rounded-md shadow">
                    Склеено: {{ item.merged_count }} дубля 1С
                  </span>
                {% endif %}
              </div>

              <div class="absolute bottom-3 right-3 bg-slate-950/90 backdrop-blur border border-slate-700 text-white font-mono text-xs px-2.5 py-1 rounded-lg">
                Остаток: <b class="text-emerald-400 font-bold">{{ item.total_stock }} шт.</b>
              </div>
            </div>

            <!-- ИНФОРМАЦИЯ -->
            <div class="p-4">
              <div class="text-[11px] text-slate-400 mb-1 flex justify-between">
                <span>OEM: <b class="text-slate-200 font-mono">{{ item.oem_number }}</b></span>
                <span class="text-slate-400">{{ item.primary_brand }}</span>
              </div>

              <h3 class="font-bold text-white text-sm sm:text-base mb-2 leading-snug line-clamp-2">
                {{ item.canonical_title }}
              </h3>

              <div class="flex items-baseline gap-2 mb-3">
                {% if item.promo_price and item.is_dead_stock %}
                  <span class="text-xl font-black text-emerald-400 mono">
                    {{ "{:,.0f}".format(item.promo_price).replace(',', ' ') }} ₽
                  </span>
                  <span class="text-xs text-slate-500 mono font-bold line-through">
                    {{ "{:,.0f}".format(item.price_retail).replace(',', ' ') }} ₽
                  </span>
                  <span class="text-[10px] font-bold text-orange-400 bg-orange-950/80 border border-orange-800/60 px-1.5 py-0.5 rounded">
                    -10%
                  </span>
                {% else %}
                  <span class="text-xl font-black text-white mono">
                    {{ "{:,.0f}".format(item.price_retail).replace(',', ' ') }} ₽
                  </span>
                {% endif %}
              </div>

              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1 mb-3">
                <div class="truncate"><b>Применяемость:</b> {{ item.applicability }}</div>
                <div class="truncate"><b>Кроссы:</b> {{ item.cross_numbers|join(', ') }}</div>
                <div class="text-slate-500 text-[10px] truncate"><b>Коды 1С:</b> {{ item.source_1c_codes|join(', ') }}</div>
              </div>
            </div>
          </div>

          <!-- КНОПКА РАСКРЫТИЯ ОПИСАНИЯ -->
          <div class="p-4 pt-0">
            <button onclick="toggleDesc('{{ item.master_id }}')" class="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs py-2 rounded-xl transition">
              Посмотреть текст Авито ▼
            </button>
            <div id="desc-{{ item.master_id }}" class="hidden mt-3 bg-slate-950 border border-slate-800 p-3 rounded-xl text-[11px] text-slate-300 font-mono whitespace-pre-line leading-relaxed max-h-56 overflow-y-auto">
              {{ item.description }}
            </div>
          </div>
        </div>
        {% endfor %}
      </div>
    </div>

    <!-- ПОДВАЛ И ССЫЛКИ -->
    <div class="bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
      <div>
        <h3 class="text-lg font-bold text-white">Фиды готовы к прямой автозагрузке в кабинеты Авито и Дром</h3>
        <p class="text-xs text-slate-400 mt-1 max-w-xl">
          При обновлении остатков на кассе 1С конвейер автоматически пересобирает фиды. Проданные товары мгновенно исчезают из рекламы, защищая магазин от жалоб и штрафов.
        </p>
      </div>
      <div class="flex flex-wrap gap-3">
        <a href="avito_feed.xml" download class="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black px-5 py-3 rounded-xl text-xs transition shadow-lg">
          📥 avito_feed.xml (Автозагрузка v3)
        </a>
        <a href="drom_feed.csv" download class="bg-sky-500 hover:bg-sky-600 text-slate-950 font-black px-5 py-3 rounded-xl text-xs transition shadow-lg">
          📥 drom_feed.csv (Прайс Дром)
        </a>
      </div>
    </div>
  </div>

  <script>
    function toggleDesc(id) {
      const el = document.getElementById('desc-' + id);
      if (el) el.classList.toggle('hidden');
    }
  </script>

</body>
</html>
"""
        template = Template(template_str, autoescape=True)
        rendered_html = template.render(data=feed_data, address=self.address, phone=self.phone)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(rendered_html)
        return output_path


def main():
    parser = argparse.ArgumentParser(description="АВТОСКЛАД-ИИ: Модуль 3 (Генератор фидов Авито и Дром)")
    parser.add_argument("file_path", nargs="?", default="sample_1c_gaz_uaz.xlsx", help="Путь к файлу выгрузки 1С")
    parser.add_argument("--client_id", default="client_main", help="ID клиента в базе client_sku_mapping")
    parser.add_argument("--db", default=DB_PATH, help="Путь к SQLite базе master_catalog.db")
    parser.add_argument("--xml", default="avito_feed.xml", help="Путь к результирующему avito_feed.xml")
    parser.add_argument("--csv", default="drom_feed.csv", help="Путь к результирующему drom_feed.csv")
    parser.add_argument("--html", default="feeds_preview.html", help="Путь к витрине предпросмотра feeds_preview.html")
    parser.add_argument("--address", default=DEFAULT_ADDRESS, help="Адрес магазина")
    parser.add_argument("--phone", default=DEFAULT_PHONE, help="Телефон контакта")

    args = parser.parse_args()

    print(f"🚀 Запуск генератора фидов по файлу: {args.file_path}")
    print(f"📦 База данных: {args.db}")
    print(f"🏢 Client ID: {args.client_id}")

    if not os.path.exists(args.file_path):
        print(f"❌ Файл не найден: {args.file_path}")
        sys.exit(1)

    df, _ = detect_and_read_1c_file(args.file_path)

    gen = FeedGenerator(db_path=args.db, client_id=args.client_id, address=args.address, phone=args.phone)
    feed_data = gen.aggregate_and_filter(df)

    print("\n--- РЕЗУЛЬТАТЫ ФИЛЬТРАЦИИ И АГРЕГАЦИИ ---")
    print(f"Всего позиций в фиде:       {feed_data['total_feed_skus']} объявлений")
    print(f"Всего штук на витрине:      {feed_data['total_feed_units']} шт.")
    print(f"Общая розничная стоимость:  {feed_data['total_feed_valuation']:,.0f} ₽".replace(",", " "))
    print(f"Склеено дублей в единые:    {feed_data['merged_clusters_count']} групп карточек")
    print(f"Неликвид на распродажу:     {feed_data['dead_stock_skus']} SKU ({feed_data['dead_stock_units']} шт.)")
    print(f"Отсеяно (остаток 0 шт):     {len(feed_data['zero_stock_filtered'])} SKU")
    print(f"Отсеяно (мелочевка <300 ₽): {len(feed_data['cheap_filtered'])} SKU")

    xml_path = gen.generate_avito_xml(feed_data, args.xml)
    csv_path = gen.generate_drom_csv(feed_data, args.csv)
    html_path = gen.generate_preview_html(feed_data, args.html)

    print(f"\n✅ XML-фид Авито сформирован:   {xml_path}")
    print(f"✅ CSV-фид Дром сформирован:    {csv_path}")
    print(f"✅ Витрина предпросмотра:       {html_path}")


if __name__ == "__main__":
    main()
