import json
import re
from inventory_guard import safe_json_dumps

with open("F:/AutoSklad_AI/radar_summary.json", "r", encoding="utf-8") as f:
    radar_data = json.load(f)

json_str = safe_json_dumps(radar_data)

html_template = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Модуль 5: Радар Собственника • Недельный Контроль Склада • АВТОСКЛАД-ИИ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700;800&display=swap" rel="stylesheet">
  <style>
    body {{ font-family: 'Inter', sans-serif; background-color: #090d16; color: #f1f5f9; }}
    .mono {{ font-family: 'JetBrains Mono', monospace; }}
    ::-webkit-scrollbar {{ width: 6px; height: 6px; }}
    ::-webkit-scrollbar-track {{ background: #0b1120; }}
    ::-webkit-scrollbar-thumb {{ background: #334155; border-radius: 3px; }}
    ::-webkit-scrollbar-thumb:hover {{ background: #475569; }}
    @keyframes pulse-subtle {{
      0%, 100% {{ opacity: 1; }}
      50% {{ opacity: 0.4; }}
    }}
    .live-pulse {{ animation: pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }}
    @media print {{
      header, .no-print, button {{ display: none !important; }}
      body {{ background-color: #ffffff; color: #000000; }}
      .print-area {{ width: 100% !important; max-width: 100% !important; }}
    }}
  </style>
</head>
<body class="min-h-screen flex flex-col">

  <!-- ВЕРХНЯЯ ШАПКА -->
  <header class="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-50 px-4 py-3 no-print">
    <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <a href="dashboard.html" class="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold transition flex items-center gap-1.5">
          <span>←</span> В кабинет (ERP)
        </a>
        <div class="h-4 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-xs px-2.5 py-0.5 rounded-lg mono">МОДУЛЬ 5</span>
          <h1 class="text-sm sm:text-base font-extrabold text-white">«Радар Собственника»: Еженедельный контроль и анти-откат</h1>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <span class="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
          <span class="w-2 h-2 rounded-full bg-emerald-500 live-pulse"></span>
          Период: 10.11 – 17.11 (7 дней)
        </span>
        <button onclick="window.print()" class="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold transition flex items-center gap-1">
          <span>🖨️</span> Распечатать сводку
        </button>
      </div>
    </div>
  </header>

  <!-- ГЛАВНЫЙ КОНТЕЙНЕР ДВУХ ОКОН -->
  <main class="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

    <!-- ЛЕВАЯ КОЛОНКА: СМАРТФОН ДИРЕКТОРА (col-span-5) -->
    <div class="lg:col-span-5 flex flex-col items-center">
      <div class="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
        <span>📱 Экран телефона директора</span>
        <span class="text-sky-400 font-normal lowercase">(понедельник, 09:00)</span>
      </div>

      <!-- МОК-АП СМАРТФОНА (IPHONE FRAME) -->
      <div class="w-full max-w-sm bg-slate-950 border-[6px] border-slate-800 rounded-[42px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col h-[760px] relative">
        
        <!-- СТАТУС БАР ТЕЛЕФОНА -->
        <div class="bg-slate-900 px-6 pt-3 pb-2 flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/60 select-none">
          <span class="font-bold text-white mono">09:00</span>
          <div class="w-24 h-4 bg-slate-950 rounded-full mx-auto -mt-1 border border-slate-800"></div>
          <div class="flex items-center gap-1.5 text-xs">
            <span>5G</span>
            <span>98% 🔋</span>
          </div>
        </div>

        <!-- ШАПКА TELEGRAM ЧАТА -->
        <div class="bg-gradient-to-r from-slate-900 via-sky-950/40 to-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="relative">
              <div class="w-10 h-10 rounded-full bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center font-black text-white text-base shadow">
                🛡️
              </div>
              <span class="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
            </div>
            <div>
              <div class="font-bold text-white text-xs leading-tight">🛡️ Радар Собственника</div>
              <div class="text-[10px] text-sky-400 flex items-center gap-1 mt-0.5">
                <span>автоматический бот</span> • <span>отчет за неделю</span>
              </div>
            </div>
          </div>
          <span class="text-[10px] bg-slate-800 text-slate-300 px-2 py-1 rounded-md font-semibold mono">
            ПН, 09:00
          </span>
        </div>

        <!-- ЛЕНТА TELEGRAM СООБЩЕНИЙ -->
        <div class="flex-1 p-3 overflow-y-auto space-y-3 bg-[#0c121e] text-xs">
          
          <!-- Системная дата -->
          <div class="text-center my-1">
            <span class="bg-slate-900/90 border border-slate-800 text-slate-400 text-[10px] px-3 py-1 rounded-full font-medium">
              Понедельник, 09:00 • Еженедельная сводка
            </span>
          </div>

          <!-- СООБЩЕНИЕ ДАЙДЖЕСТА -->
          <div class="flex items-start gap-2 max-w-[96%]">
            <div class="w-6 h-6 rounded-full bg-sky-500 flex-shrink-0 flex items-center justify-center text-[10px] font-black text-white mt-1">
              Бот
            </div>
            <div class="bg-slate-900 border border-slate-800 p-3 rounded-2xl rounded-tl-none text-slate-200 shadow-md leading-relaxed text-[11px] space-y-2.5">
              
              <div class="font-bold text-sky-300 text-xs border-b border-slate-800 pb-1.5">
                🛡️ РАДАР СОБСТВЕННИКА: НЕДЕЛЬНЫЙ РАЗБОР
                <div class="text-[10px] text-slate-400 font-normal">Лично для: <b class="text-white">Вячеслава Юрьевича</b> (ГАЗ / УАЗ, Пермь)</div>
              </div>

              <!-- БЛОК 1: РАЗМОРОЖЕНО КЭША -->
              <div class="bg-emerald-950/40 border border-emerald-800/40 p-2 rounded-xl">
                <div class="text-emerald-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>💰 1. Разморожено кэша (Авито/Дром):</span>
                  <span class="text-xs font-black mono text-emerald-300">+193 800 ₽</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  <div>• КПП ГАЗ-3309 дизель 5-ст: <b>1 шт. (+92 000 ₽)</b></div>
                  <div>• Раздатка УАЗ Хантер: <b>1 шт. (+47 000 ₽)</b></div>
                  <div>• Редуктор моста 3302 ГП 8х41: <b>1 шт. (+28 500 ₽)</b></div>
                  <div>• Рессоры Чусовая 5-лист: <b>2 шт. (+15 800 ₽)</b></div>
                  <div>• Картер сцепления УАЗ Патриот: <b>1 шт. (+10 500 ₽)</b></div>
                </div>
              </div>

              <!-- БЛОК 2: АНТИ-ОТКАТ / ОШИБКИ ЗАКУПЩИКА -->
              <div class="bg-red-950/40 border border-red-800/40 p-2 rounded-xl">
                <div class="text-red-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>🚨 2. Претензии к закупщику:</span>
                  <span class="text-xs font-black mono text-red-300">-42 100 ₽</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  <div>⚠️ Радиатор медный 3302 (дубль): <b>+2 шт. (-22 500 ₽)</b></div>
                  <div>⚠️ Фонари Next борт (00-003010): <b>+4 шт. (-10 000 ₽)</b></div>
                  <div>⚠️ Насос ГУР 4216 (пустой дубль): <b>+2 шт. (-9 600 ₽)</b></div>
                </div>
              </div>

              <!-- БЛОК 3: ПРОСПАННЫЙ ДЕФИЦИТ -->
              <div class="bg-amber-950/40 border border-amber-800/40 p-2 rounded-xl">
                <div class="text-amber-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>📉 3. Проспанный дефицит:</span>
                  <span class="text-xs font-black mono text-amber-300">50 616 ₽/мес риск</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  <div>❌ Стартер редукторный КЗАТЭ: <b>остаток 0 шт.</b></div>
                  <div>❌ Крестовина кардана Патриот: <b>остаток 0 шт.</b></div>
                  <div>❌ РЦС 3302 чугун: <b>остаток 0 шт.</b></div>
                </div>
              </div>

              <!-- БЛОК 4: НОЧНЫЕ БРОНИ -->
              <div class="bg-purple-950/40 border border-purple-800/40 p-2 rounded-xl">
                <div class="text-purple-300 font-extrabold flex items-center justify-between text-[11px]">
                  <span>🤖 4. Касса ночного ИИ-бота (23:00-08:00):</span>
                  <span class="text-xs font-black mono text-purple-200">+15 650 ₽</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1">
                  Оформлено <b>3 ночные брони</b> (Сергей, Алексей, Дмитрий)
                </div>
              </div>

              <!-- ИТОГОВЫЙ БАЛАНС -->
              <div class="pt-1.5 border-t border-slate-800 flex items-center justify-between font-bold text-xs">
                <span>Итоговый баланс недели:</span>
                <span class="text-emerald-400 font-black mono text-sm">+167 350 ₽</span>
              </div>

              <!-- ИНТЕРАКТИВНЫЕ КНОПКИ В TELEGRAM -->
              <div class="pt-2 border-t border-slate-800 space-y-1.5">
                <button onclick="handleBotAction('block_order')" class="w-full bg-red-950/80 hover:bg-red-900 border border-red-700/60 text-red-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>🚫</span> Заблокировать лишний заказ закупщика (42 100 ₽)
                </button>
                <button onclick="handleBotAction('send_deficit')" class="w-full bg-amber-950/80 hover:bg-amber-900 border border-amber-700/60 text-amber-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>📋</span> Отправить список дефицита на дозаказ
                </button>
                <button onclick="handleBotAction('discount_promo')" class="w-full bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>🏷️</span> Уценить остаток неликвида на -10%
                </button>
              </div>

              <div class="text-[9px] text-slate-400 text-right mono pt-1">09:00 ✓✓</div>
            </div>
          </div>

          <!-- Ответ пользователя на кнопки (появится при клике) -->
          <div id="userFeedbackMsg" class="hidden flex items-start justify-end gap-2 max-w-[90%] ml-auto">
            <div id="userFeedbackText" class="bg-sky-600 text-white p-2.5 rounded-2xl rounded-tr-none text-xs leading-relaxed">
              Команда отправлена
            </div>
          </div>

        </div>

      </div>

      <div class="text-[11px] text-slate-400 mt-2 text-center">
        💡 Нажмите на кнопки внутри Telegram-сообщения, чтобы протестировать реакцию системы.
      </div>
    </div>

    <!-- ПРАВАЯ КОЛОНКА: ДЕТАЛЬНЫЙ АНАЛИТИЧЕСКИЙ ОТЧЕТ ДИРЕКТОРА (col-span-7) -->
    <div class="lg:col-span-7 space-y-4 print-area">

      <!-- ПЛИТКА СВОДНЫХ ИТОГОВ НЕДЕЛИ -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="bg-slate-950 border border-emerald-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Разморожено кэша</div>
          <div class="text-lg font-black text-emerald-400 mono mt-1">+193 800 ₽</div>
          <div class="text-[10px] text-slate-400 mt-0.5">5 позиций с Авито/Дром</div>
        </div>
        <div class="bg-slate-950 border border-red-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Ошибки закупщика</div>
          <div class="text-lg font-black text-red-400 mono mt-1">-42 100 ₽</div>
          <div class="text-[10px] text-slate-400 mt-0.5">3 заказа по дублям</div>
        </div>
        <div class="bg-slate-950 border border-amber-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Риск дефицита</div>
          <div class="text-lg font-black text-amber-400 mono mt-1">50 616 ₽/мес</div>
          <div class="text-[10px] text-slate-400 mt-0.5">3 ходовых товара в 0</div>
        </div>
        <div class="bg-slate-950 border border-purple-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Ночной ИИ-бот</div>
          <div class="text-lg font-black text-purple-400 mono mt-1">+15 650 ₽</div>
          <div class="text-[10px] text-slate-400 mt-0.5">3 ночные брони</div>
        </div>
      </div>

      <!-- ТАБЛИЧНЫЙ АНАЛИЗ ПО 4 КАТЕГОРИЯМ -->
      <div class="bg-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <span class="text-lg">📊</span>
            <h2 class="font-extrabold text-white text-sm sm:text-base">Детализация движений: Неделя 1 vs Неделя 2</h2>
          </div>
          <button onclick="copyTelegramDigest()" class="bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 no-print">
            <span>📋</span> Скопировать дайджест в буфер
          </button>
        </div>

        <!-- ВКЛАДКИ -->
        <div class="flex gap-2 border-b border-slate-800/80 pb-2 overflow-x-auto text-xs no-print">
          <button onclick="switchTab('unfrozen')" id="tabBtn-unfrozen" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            💰 Проданный неликвид (5)
          </button>
          <button onclick="switchTab('overbuy')" id="tabBtn-overbuy" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            🚨 Ошибки закупщика (3)
          </button>
          <button onclick="switchTab('deficits')" id="tabBtn-deficits" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            📉 Проспанный дефицит (3)
          </button>
          <button onclick="switchTab('reservations')" id="tabBtn-reservations" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            🤖 Ночные брони (3)
          </button>
        </div>

        <!-- ТАБЛИЦА 1: ПРОДАННЫЙ НЕЛИКВИД -->
        <div id="tabContent-unfrozen" class="space-y-2 text-xs">
          <div class="text-[11px] text-slate-400 mb-2">
            Позиции, которые лежали без движения более 300 дней и были успешно проданы после выгрузки на Авито и Дром:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Продано</th>
                  <th class="p-2.5 text-right">Выручка (кэш)</th>
                  <th class="p-2.5 text-center">Лежало без движ.</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                <tr>
                  <td class="p-2.5 mono text-orange-400">00-003002</td>
                  <td class="p-2.5 text-white font-bold">Коробка передач (КПП) ГАЗ-3309 дизель 5-ст</td>
                  <td class="p-2.5 text-center mono text-emerald-400">1 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-emerald-300">92 000 ₽</td>
                  <td class="p-2.5 text-center text-slate-400">520 дней</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-orange-400">00-003005</td>
                  <td class="p-2.5 text-white font-bold">Раздаточная коробка УАЗ 31519 Хантер косозубая</td>
                  <td class="p-2.5 text-center mono text-emerald-400">1 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-emerald-300">47 000 ₽</td>
                  <td class="p-2.5 text-center text-slate-400">390 дней</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-orange-400">00-003001</td>
                  <td class="p-2.5 text-white font-bold">Редуктор заднего моста ГАЗ-3302 ГП 8х41 (4.3)</td>
                  <td class="p-2.5 text-center mono text-emerald-400">1 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-emerald-300">28 500 ₽</td>
                  <td class="p-2.5 text-center text-slate-400">410 дней</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-orange-400">00-003007</td>
                  <td class="p-2.5 text-white font-bold">Рессора задняя ГАЗ-3302 5-листовая усиленная Чусовая</td>
                  <td class="p-2.5 text-center mono text-emerald-400">2 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-emerald-300">15 800 ₽</td>
                  <td class="p-2.5 text-center text-slate-400">310 дней</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-orange-400">00-003008</td>
                  <td class="p-2.5 text-white font-bold">Картер сцепления (колокол) УАЗ Патриот ЗМЗ-409</td>
                  <td class="p-2.5 text-center mono text-emerald-400">1 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-emerald-300">10 500 ₽</td>
                  <td class="p-2.5 text-center text-slate-400">365 дней</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="bg-emerald-950/30 border border-emerald-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-emerald-300 mt-2">
            <span>Итого возвращено в оборот живых денег:</span>
            <span class="text-base font-black mono">+193 800 ₽</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 2: ОШИБКИ ЗАКУПЩИКА -->
        <div id="tabContent-overbuy" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Позиции, по которым закупщик оформил новую поставку по дублям или сверх нормы, заморозив оборотные средства зря:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Дозаказано</th>
                  <th class="p-2.5 text-right">Заморожено кэша</th>
                  <th class="p-2.5">Причина выявления (Анти-откат)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                <tr>
                  <td class="p-2.5 mono text-red-400">00-001088</td>
                  <td class="p-2.5 text-white font-bold">Радиатор охлаждения ГАЗ-3302 медный 3-х рядный</td>
                  <td class="p-2.5 text-center mono text-red-400">+2 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-red-300">-22 500 ₽</td>
                  <td class="p-2.5 text-amber-300">Заказ по дублю 1С (на складе уже лежало 3 шт. радиаторов по 00-001089)</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-red-400">00-003010</td>
                  <td class="p-2.5 text-white font-bold">Фонарь задний светодиодный ГАЗель Next борт</td>
                  <td class="p-2.5 text-center mono text-red-400">+4 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-red-300">-10 000 ₽</td>
                  <td class="p-2.5 text-amber-300">Аномальный перезакуп (запас без движения превышал 40 месяцев)</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-red-400">00-001041</td>
                  <td class="p-2.5 text-white font-bold">Насос ГУР ГАЗель Бизнес, Next (УМЗ 4216) ШНКФ</td>
                  <td class="p-2.5 text-center mono text-red-400">+2 шт.</td>
                  <td class="p-2.5 text-right mono font-black text-red-300">-9 600 ₽</td>
                  <td class="p-2.5 text-amber-300">Заказ по пустой карточке-дублю (на складе уже лежало 4 шт. по 00-001042/1043)</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="bg-red-950/30 border border-red-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-red-300 mt-2">
            <span>Итого необоснованно заморожено закупщиком:</span>
            <span class="text-base font-black mono">-42 100 ₽</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 3: ПРОСПАННЫЙ ДЕФИЦИТ -->
        <div id="tabContent-deficits" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Ходовые позиции с высоким спросом, которые закончились до 0 шт., а заказ поставщику не был отправлен вовремя:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Текущий остаток</th>
                  <th class="p-2.5 text-center">Спрос в месяц</th>
                  <th class="p-2.5 text-right">Потери выручки</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                <tr>
                  <td class="p-2.5 mono text-amber-400">00-002004</td>
                  <td class="p-2.5 text-white font-bold">Стартер редукторный ГАЗ, УАЗ дв. ЗМЗ 406/405/409 КЗАТЭ</td>
                  <td class="p-2.5 text-center mono font-black text-red-400">0 шт.</td>
                  <td class="p-2.5 text-center text-slate-300">4.3 шт./мес</td>
                  <td class="p-2.5 text-right mono font-black text-amber-300">29 683 ₽/мес</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-amber-400">00-002003</td>
                  <td class="p-2.5 text-white font-bold">Крестовина карданного вала УАЗ Патриот, Хантер</td>
                  <td class="p-2.5 text-center mono font-black text-red-400">0 шт.</td>
                  <td class="p-2.5 text-center text-slate-300">5.3 шт./мес</td>
                  <td class="p-2.5 text-right mono font-black text-amber-300">6 133 ₽/мес</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-amber-400">00-001151</td>
                  <td class="p-2.5 text-white font-bold">Цилиндр сцепления рабочий (РЦС) 3302, Соболь чугун</td>
                  <td class="p-2.5 text-center mono font-black text-red-400">0 шт.</td>
                  <td class="p-2.5 text-center text-slate-300">3.5 шт./мес</td>
                  <td class="p-2.5 text-right mono font-black text-amber-300">4 480 ₽/мес</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="bg-amber-950/30 border border-amber-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-amber-300 mt-2">
            <span>Общий риск потерь выручки из-за пустого склада:</span>
            <span class="text-base font-black mono">40 297 ₽/мес (до 50 616 ₽ с сопутствующими)</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 4: НОЧНЫЕ БРОНИ -->
        <div id="tabContent-reservations" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Заказы, автоматически принятые ИИ-продавцом в ночные часы (23:00 - 08:00) в чатах Авито и WhatsApp:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">ID Брони</th>
                  <th class="p-2.5">Время</th>
                  <th class="p-2.5">Покупатель</th>
                  <th class="p-2.5">Товар</th>
                  <th class="p-2.5 text-right">Сумма</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                <tr>
                  <td class="p-2.5 mono text-purple-300 font-bold">RES-20261117-001</td>
                  <td class="p-2.5 text-slate-400 mono">23:22</td>
                  <td class="p-2.5 text-white">Сергей (+7 912 345-67-89)</td>
                  <td class="p-2.5 text-slate-300">Стартер редукторный КЗАТЭ 5732/5742</td>
                  <td class="p-2.5 text-right mono font-black text-purple-300">6 850 ₽</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-purple-300 font-bold">RES-20261117-002</td>
                  <td class="p-2.5 text-slate-400 mono">01:14</td>
                  <td class="p-2.5 text-white">Алексей (+7 908 221-44-55)</td>
                  <td class="p-2.5 text-slate-300">Насос ГУР ГАЗель 4216 ШНКФ</td>
                  <td class="p-2.5 text-right mono font-black text-purple-300">6 950 ₽</td>
                </tr>
                <tr>
                  <td class="p-2.5 mono text-purple-300 font-bold">RES-20261117-003</td>
                  <td class="p-2.5 text-slate-400 mono">04:45</td>
                  <td class="p-2.5 text-white">Дмитрий (+7 950 443-12-80)</td>
                  <td class="p-2.5 text-slate-300">Колодки тормозные передние Next</td>
                  <td class="p-2.5 text-right mono font-black text-purple-300">1 850 ₽</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="bg-purple-950/30 border border-purple-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-purple-300 mt-2">
            <span>Итого поймано ИИ-продавцом ночной кассы:</span>
            <span class="text-base font-black mono">+15 650 ₽</span>
          </div>
        </div>

      </div>

    </div>
  </main>

  <script>
    const RADAR_DATA = {json_str};

    function switchTab(tabId) {{
      const tabs = ['unfrozen', 'overbuy', 'deficits', 'reservations'];
      tabs.forEach(t => {{
        const btn = document.getElementById('tabBtn-' + t);
        const content = document.getElementById('tabContent-' + t);
        if (t === tabId) {{
          btn.className = "tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-sky-500/20 text-sky-300 border border-sky-500/40";
          content.classList.remove('hidden');
        }} else {{
          btn.className = "tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800 hover:text-white";
          content.classList.add('hidden');
        }}
      }});
    }}

    function handleBotAction(action) {{
      const fbMsg = document.getElementById('userFeedbackMsg');
      const fbText = document.getElementById('userFeedbackText');

      if (action === 'block_order') {{
        fbText.textContent = "🚫 Заблокировать лишний заказ закупщика на 42 100 ₽";
        fbMsg.classList.remove('hidden');
        setTimeout(() => {{
          alert("✅ Команда принята!\\n\\nЗаказ поставщику на сумму 42 100 ₽ (Радиатор медный 3302, Фонари Next, Насос ГУР 4216) заблокирован в 1С до согласования с Вячеславом Юрьевичем.");
        }}, 200);
      }} else if (action === 'send_deficit') {{
        fbText.textContent = "📋 Сформировать срочный заказ на дефицит";
        fbMsg.classList.remove('hidden');
        setTimeout(() => {{
          alert("✅ Срочный лист дефицита сформирован!\\n\\nЗакупщику отправлено уведомление в Telegram: срочно заказать Стартер 406/409 КЗАТЭ (5 шт.), Крестовины Патриот (10 шт.), РЦС 3302 чугун (6 шт.).");
        }}, 200);
      }} else if (action === 'discount_promo') {{
        fbText.textContent = "🏷️ Уценить остаток неликвида на -10%";
        fbMsg.classList.remove('hidden');
        setTimeout(() => {{
          alert("✅ Скидка 10% применена!\\n\\nЦены на зависшие позиции снижены в фиде автозагрузки Авито (avito_feed.xml) с бейджем «Распродажа складских запасов».");
        }}, 200);
      }}
    }}

    function copyTelegramDigest() {{
      const text = `🛡️ РАДАР СОБСТВЕННИКА: НЕДЕЛЬНЫЙ РАЗБОР\\n👤 Лично для: Вячеслава Юрьевича\\n💰 1. Разморожено кэша: +193 800 ₽ (КПП 3309, Раздатка Хантер, Редуктор 3302, Рессоры, Картер УАЗ)\\n🚨 2. Ошибки закупщика: -42 100 ₽ (Радиатор по дублю -22.5k, Фонари -10k, ГУР по дублю -9.6k)\\n📉 3. Дефицит ходовых: риск 50 616 ₽/мес (Стартер 0 шт, Крестовина 0 шт, РЦС 0 шт)\\n🤖 4. Ночной ИИ-бот: +15 650 ₽ (3 брони с 23:00 до 08:00)\\n━━━━━━━━━━━━━━━━━━\\n📊 Чистый баланс недели: +167 350 ₽\\n📞 Поддержка: +7 (902) 802-82-46 (Telegram: @dkazak1999)`;
      navigator.clipboard.writeText(text).then(() => {{
        alert("✅ Текст утреннего дайджеста скопирован в буфер обмена для отправки в Telegram/WhatsApp:\\n\\n" + text);
      }});
    }}
  </script>
</body>
</html>
"""

with open("F:/AutoSklad_AI/owner_radar.html", "w", encoding="utf-8") as f:
    f.write(html_template)

with open("F:/AutoSklad_AI/github-pages/owner_radar.html", "w", encoding="utf-8") as f:
    f.write(html_template)

print(f"owner_radar.html generated successfully ({len(html_template)} bytes)")
