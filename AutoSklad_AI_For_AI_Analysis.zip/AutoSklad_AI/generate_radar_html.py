import json
import re
from config import BASE_DIR, GITHUB_PAGES_DIR, OWNER_NAME, STORE_PHONE
from inventory_guard import safe_json_dumps

radar_summary_file = BASE_DIR / "radar_summary.json"
with open(radar_summary_file, "r", encoding="utf-8") as f:
    radar_data = json.load(f)

json_str = safe_json_dumps(radar_data)

m = radar_data["metrics"]
unfrozen_rub = f"+{m['unfrozen_cash_rub']:,.0f} ₽".replace(",", " ")
overbuy_rub = f"-{m['overbuy_waste_rub']:,.0f} ₽".replace(",", " ")
deficit_rub = f"{m['lost_revenue_risk_rub']:,.0f} ₽/мес".replace(",", " ")
night_rub = f"+{m['night_bot_revenue_rub']:,.0f} ₽".replace(",", " ")
net_rub = f"+{m['net_financial_impact_rub']:,.0f} ₽".replace(",", " ")

# Генерация строк таблицы 1: Разморозка неликвида
unfrozen_rows = []
for it in radar_data.get("dead_stock_sales", []):
    unfrozen_rows.append(f"""
    <tr>
      <td class="p-2.5 mono text-orange-400">{it['code']}</td>
      <td class="p-2.5 text-white font-bold">{it['canonical_title']}</td>
      <td class="p-2.5 text-center mono text-emerald-400">{it['qty_sold']:.0f} шт.</td>
      <td class="p-2.5 text-right mono font-black text-emerald-300">{it['cash_freed_rub']:,.0f} ₽</td>
      <td class="p-2.5 text-center text-slate-400">{it['days_no_movement']} дней</td>
    </tr>
    """.strip())
unfrozen_rows_html = "\n".join(unfrozen_rows)

# Генерация строк таблицы 2: Ошибки закупщика
overbuy_rows = []
for it in radar_data.get("overbuy_alerts", []):
    overbuy_rows.append(f"""
    <tr>
      <td class="p-2.5 mono text-red-400">{it['code']}</td>
      <td class="p-2.5 text-white font-bold">{it['canonical_title']}</td>
      <td class="p-2.5 text-center mono text-red-400">+{it['qty_added']:.0f} шт.</td>
      <td class="p-2.5 text-right mono font-black text-red-300">-{it['waste_cost_rub']:,.0f} ₽</td>
      <td class="p-2.5 text-amber-300">{it['reason']}</td>
    </tr>
    """.strip())
overbuy_rows_html = "\n".join(overbuy_rows)

# Генерация строк таблицы 3: Дефицит
deficit_rows = []
for it in radar_data.get("new_deficits", []):
    deficit_rows.append(f"""
    <tr>
      <td class="p-2.5 mono text-amber-400">{it['code']}</td>
      <td class="p-2.5 text-white font-bold">{it['canonical_title']}</td>
      <td class="p-2.5 text-center mono text-red-400">0 шт.</td>
      <td class="p-2.5 text-center mono text-slate-300">{it['monthly_demand']:.1f} шт/мес</td>
      <td class="p-2.5 text-right mono font-black text-amber-400">{it['monthly_lost_revenue_rub']:,.0f} ₽</td>
    </tr>
    """.strip())
deficit_rows_html = "\n".join(deficit_rows)

# Генерация строк таблицы 4: Брони
res_rows = []
for it in radar_data.get("night_reservations", []):
    res_rows.append(f"""
    <tr>
      <td class="p-2.5 mono text-sky-400">{it['res_id']}</td>
      <td class="p-2.5 text-slate-300">{it.get('created_at', '')}</td>
      <td class="p-2.5 text-white font-bold">{it['client_name']} ({it['client_phone']})</td>
      <td class="p-2.5 text-slate-200">{it['canonical_title']}</td>
      <td class="p-2.5 text-right mono font-black text-purple-300">{it['price']:,.0f} ₽</td>
      <td class="p-2.5 text-center"><span class="bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold">ОТЛОЖЕНО</span></td>
    </tr>
    """.strip())
res_rows_html = "\n".join(res_rows)

# Элементы списка в телефоне
phone_unfrozen_list = "\n".join([f"<div>• {it['canonical_title']}: <b>{it['qty_sold']:.0f} шт. (+{it['cash_freed_rub']:,.0f} ₽)</b></div>" for it in radar_data.get("dead_stock_sales", [])[:5]])
phone_overbuy_list = "\n".join([f"<div>⚠️ {it['canonical_title']}: <b>+{it['qty_added']:.0f} шт. (-{it['waste_cost_rub']:,.0f} ₽)</b></div>" for it in radar_data.get("overbuy_alerts", [])[:3]])
phone_deficit_list = "\n".join([f"<div>❌ {it['canonical_title']}: <b>остаток 0 шт.</b></div>" for it in radar_data.get("new_deficits", [])[:3]])
night_names = ", ".join([r['client_name'] for r in radar_data.get("night_reservations", [])[:3]])

html_template = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Модуль 5: Радар Собственника • Недельный Контроль Склада • АВТОСКЛАД-ИИ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700;800&display=swap" rel="stylesheet">
  <style>
    body {{ font-family: 'Inter', sans-serif; background-color: #090d16; color: #f1f5f9; }}
    .mono {{ font-family: 'JetBrains Mono', monospace; }}
    ::-webkit-scrollbar {{ width: 6px; height: 6px; }}
    ::-webkit-scrollbar-track {{ background: #0b1120; }}
    ::-webkit-scrollbar-thumb {{ background: #334155; border-radius: 3px; }}
    ::-webkit-scrollbar-thumb:hover {{ background: #475569; }}
    @keyframes pulse-subtle {{
      0%, 100% {{ opacity: 1; }}
      50% {{ opacity: 0.4; }}
    }}
    .live-pulse {{ animation: pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }}
    @media print {{
      header, .no-print, button {{ display: none !important; }}
      body {{ background-color: #ffffff; color: #000000; }}
      .print-area {{ width: 100% !important; max-width: 100% !important; }}
    }}
  </style>
</head>
<body class="min-h-screen flex flex-col">

  <!-- ВЕРХНЯЯ ШАПКА -->
  <header class="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-50 px-4 py-3 no-print">
    <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <a href="dashboard.html" class="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold transition flex items-center gap-1.5">
          <span>←</span> В кабинет (ERP)
        </a>
        <div class="h-4 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-xs px-2.5 py-0.5 rounded-lg mono">МОДУЛЬ 5</span>
          <h1 class="text-sm sm:text-base font-extrabold text-white">«Радар Собственника»: Еженедельный контроль и анти-откат</h1>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <span class="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
          <span class="w-2 h-2 rounded-full bg-emerald-500 live-pulse"></span>
          Период: Неделя 2 vs Неделя 1 (7 дней)
        </span>
        <button onclick="window.print()" class="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold transition flex items-center gap-1">
          <span>🖨️</span> Распечатать сводку
        </button>
      </div>
    </div>
  </header>

  <!-- ГЛАВНЫЙ КОНТЕЙНЕР ДВУХ ОКОН -->
  <main class="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

    <!-- ЛЕВАЯ КОЛОНКА: СМАРТФОН ДИРЕКТОРА (col-span-5) -->
    <div class="lg:col-span-5 flex flex-col items-center">
      <div class="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
        <span>📱 Экран телефона директора</span>
        <span class="text-sky-400 font-normal lowercase">(понедельник, 09:00)</span>
      </div>

      <!-- МОК-АП СМАРТФОНА (IPHONE FRAME) -->
      <div class="w-full max-w-sm bg-slate-950 border-[6px] border-slate-800 rounded-[42px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col h-[760px] relative">
        
        <!-- СТАТУС БАР ТЕЛЕФОНА -->
        <div class="bg-slate-900 px-6 pt-3 pb-2 flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/60 select-none">
          <span class="font-bold text-white mono">09:00</span>
          <div class="w-24 h-4 bg-slate-950 rounded-full mx-auto -mt-1 border border-slate-800"></div>
          <div class="flex items-center gap-1.5 text-xs">
            <span>5G</span>
            <span>98% 🔋</span>
          </div>
        </div>

        <!-- ШАПКА TELEGRAM ЧАТА -->
        <div class="bg-gradient-to-r from-slate-900 via-sky-950/40 to-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="relative">
              <div class="w-10 h-10 rounded-full bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center font-black text-white text-base shadow">
                🛡️
              </div>
              <span class="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
            </div>
            <div>
              <div class="font-bold text-white text-xs leading-tight">🛡️ Радар Собственника</div>
              <div class="text-[10px] text-sky-400 flex items-center gap-1 mt-0.5">
                <span>автоматический бот</span> • <span>отчет за неделю</span>
              </div>
            </div>
          </div>
          <a href="https://t.me/dkazak1999" target="_blank" class="text-xs text-sky-400 hover:text-sky-300 font-bold bg-sky-950/80 px-2 py-1 rounded-lg border border-sky-800/60">
            @dkazak1999
          </a>
        </div>

        <!-- ТЕЛО ЧАТА (СООБЩЕНИЕ ДАЙДЖЕСТА) -->
        <div class="flex-1 bg-slate-950 p-3 overflow-y-auto space-y-3 text-xs">
          
          <div class="text-center">
            <span class="bg-slate-900/90 text-slate-400 text-[10px] font-semibold px-2.5 py-0.5 rounded-full border border-slate-800">
              Понедельник, 09:00
            </span>
          </div>

          <!-- СООБЩЕНИЕ БОТА С ДАЙДЖЕСТОМ -->
          <div class="flex items-start gap-2 max-w-[96%]">
            <div class="bg-slate-900 border border-slate-800 p-3 rounded-2xl rounded-tl-none space-y-2.5 shadow-xl text-slate-200">
              
              <div class="border-b border-slate-800 pb-2">
                <div class="font-black text-amber-400 text-xs flex items-center gap-1.5">
                  <span>📊</span> ЕЖЕНЕДЕЛЬНЫЙ ДАЙДЖЕСТ ДЛЯ ДИРЕКТОРА
                </div>
                <div class="text-[10px] text-slate-400 mt-0.5">
                  Сеть магазинов ГАЗ/УАЗ • <b>{OWNER_NAME}</b>
                </div>
              </div>

              <!-- БЛОК 1: РАЗМОРОЖЕНО КЭША -->
              <div class="bg-emerald-950/40 border border-emerald-800/40 p-2 rounded-xl">
                <div class="text-emerald-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>💰 1. Разморожено кэша (Авито/Дром):</span>
                  <span class="text-xs font-black mono text-emerald-300">{unfrozen_rub}</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  {phone_unfrozen_list}
                </div>
              </div>

              <!-- БЛОК 2: АНТИ-ОТКАТ / ОШИБКИ ЗАКУПЩИКА -->
              <div class="bg-red-950/40 border border-red-800/40 p-2 rounded-xl">
                <div class="text-red-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>🚨 2. Претензии к закупщику:</span>
                  <span class="text-xs font-black mono text-red-300">{overbuy_rub}</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  {phone_overbuy_list}
                </div>
              </div>

              <!-- БЛОК 3: ПРОСПАННЫЙ ДЕФИЦИТ -->
              <div class="bg-amber-950/40 border border-amber-800/40 p-2 rounded-xl">
                <div class="text-amber-400 font-extrabold flex items-center justify-between text-[11px]">
                  <span>📉 3. Проспанный дефицит:</span>
                  <span class="text-xs font-black mono text-amber-300">{deficit_rub} риск</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1 space-y-0.5">
                  {phone_deficit_list}
                </div>
              </div>

              <!-- БЛОК 4: НОЧНЫЕ БРОНИ -->
              <div class="bg-purple-950/40 border border-purple-800/40 p-2 rounded-xl">
                <div class="text-purple-300 font-extrabold flex items-center justify-between text-[11px]">
                  <span>🤖 4. Касса ночного ИИ-бота (23:00-08:00):</span>
                  <span class="text-xs font-black mono text-purple-200">{night_rub}</span>
                </div>
                <div class="text-[10px] text-slate-300 mt-1">
                  Оформлено <b>{len(radar_data.get('night_reservations', []))} ночные брони</b> ({night_names})
                </div>
              </div>

              <!-- ИТОГОВЫЙ БАЛАНС -->
              <div class="pt-1.5 border-t border-slate-800 flex items-center justify-between font-bold text-xs">
                <span>Итоговый баланс недели:</span>
                <span class="text-emerald-400 font-black mono text-sm">{net_rub}</span>
              </div>

              <!-- ИНТЕРАКТИВНЫЕ КНОПКИ В TELEGRAM -->
              <div class="pt-2 border-t border-slate-800 space-y-1.5">
                <button onclick="handleBotAction('block_order')" class="w-full bg-red-950/80 hover:bg-red-900 border border-red-700/60 text-red-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>🚫</span> Заблокировать лишний заказ закупщика ({overbuy_rub})
                </button>
                <button onclick="handleBotAction('send_deficit')" class="w-full bg-amber-950/80 hover:bg-amber-900 border border-amber-700/60 text-amber-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>📋</span> Отправить список дефицита на дозаказ
                </button>
                <button onclick="handleBotAction('discount_promo')" class="w-full bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-200 font-bold py-1.5 px-2 rounded-lg text-[10px] flex items-center justify-center gap-1.5 transition">
                  <span>🏷️</span> Уценить остаток неликвида на -10%
                </button>
              </div>

              <div class="text-[9px] text-slate-400 text-right mono pt-1">09:00 ✓✓</div>
            </div>
          </div>

          <!-- Ответ пользователя на кнопки (появится при клике) -->
          <div id="userFeedbackMsg" class="hidden flex items-start justify-end gap-2 max-w-[90%] ml-auto">
            <div id="userFeedbackText" class="bg-sky-600 text-white p-2.5 rounded-2xl rounded-tr-none text-xs leading-relaxed">
              Команда отправлена
            </div>
          </div>

        </div>

      </div>

      <div class="text-[11px] text-slate-400 mt-2 text-center">
        💡 Нажмите на кнопки внутри Telegram-сообщения, чтобы протестировать реакцию системы.
      </div>
    </div>

    <!-- ПРАВАЯ КОЛОНКА: ДЕТАЛЬНЫЙ АНАЛИТИЧЕСКИЙ ОТЧЕТ ДИРЕКТОРА (col-span-7) -->
    <div class="lg:col-span-7 space-y-4 print-area">

      <!-- ПЛИТКА СВОДНЫХ ИТОГОВ НЕДЕЛИ -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="bg-slate-950 border border-emerald-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Разморожено кэша</div>
          <div class="text-lg font-black text-emerald-400 mono mt-1">{unfrozen_rub}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{len(radar_data.get('dead_stock_sales', []))} позиций с Авито/Дром</div>
        </div>
        <div class="bg-slate-950 border border-red-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Ошибки закупщика</div>
          <div class="text-lg font-black text-red-400 mono mt-1">{overbuy_rub}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{len(radar_data.get('overbuy_alerts', []))} заказа по дублям</div>
        </div>
        <div class="bg-slate-950 border border-amber-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Риск дефицита</div>
          <div class="text-lg font-black text-amber-400 mono mt-1">{deficit_rub}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{len(radar_data.get('new_deficits', []))} ходовых товара в 0</div>
        </div>
        <div class="bg-slate-950 border border-purple-500/40 p-3.5 rounded-2xl shadow">
          <div class="text-[10px] font-bold text-slate-400 uppercase">Ночной ИИ-бот</div>
          <div class="text-lg font-black text-purple-400 mono mt-1">{night_rub}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{len(radar_data.get('night_reservations', []))} ночные брони</div>
        </div>
      </div>

      <!-- ТАБЛИЧНЫЙ АНАЛИЗ ПО 4 КАТЕГОРИЯМ -->
      <div class="bg-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <span class="text-lg">📊</span>
            <h2 class="font-extrabold text-white text-sm sm:text-base">Детализация движений: Неделя 1 vs Неделя 2</h2>
          </div>
          <button onclick="copyTelegramDigest()" class="bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 no-print">
            <span>📋</span> Скопировать дайджест в буфер
          </button>
        </div>

        <!-- ВКЛАДКИ -->
        <div class="flex gap-2 border-b border-slate-800/80 pb-2 overflow-x-auto text-xs no-print">
          <button onclick="switchTab('unfrozen')" id="tabBtn-unfrozen" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            💰 Проданный неликвид ({len(radar_data.get('dead_stock_sales', []))})
          </button>
          <button onclick="switchTab('overbuy')" id="tabBtn-overbuy" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            🚨 Ошибки закупщика ({len(radar_data.get('overbuy_alerts', []))})
          </button>
          <button onclick="switchTab('deficits')" id="tabBtn-deficits" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            📉 Проспанный дефицит ({len(radar_data.get('new_deficits', []))})
          </button>
          <button onclick="switchTab('reservations')" id="tabBtn-reservations" class="tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800">
            🤖 Ночные брони ({len(radar_data.get('night_reservations', []))})
          </button>
        </div>

        <!-- ТАБЛИЦА 1: ПРОДАННЫЙ НЕЛИКВИД -->
        <div id="tabContent-unfrozen" class="space-y-2 text-xs">
          <div class="text-[11px] text-slate-400 mb-2">
            Позиции, которые лежали без движения более 180 дней и были успешно проданы после выгрузки на Авито и Дром:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Продано</th>
                  <th class="p-2.5 text-right">Выручка (кэш)</th>
                  <th class="p-2.5 text-center">Лежало без движ.</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                {unfrozen_rows_html}
              </tbody>
            </table>
          </div>
          <div class="bg-emerald-950/30 border border-emerald-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-emerald-300 mt-2">
            <span>Итого возвращено в оборот живых денег:</span>
            <span class="text-base font-black mono">{unfrozen_rub}</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 2: ОШИБКИ ЗАКУПЩИКА -->
        <div id="tabContent-overbuy" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Позиции, по которым закупщик оформил новую поставку по дублям или сверх нормы, заморозив оборотные средства зря:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Дозаказано</th>
                  <th class="p-2.5 text-right">Заморожено кэша</th>
                  <th class="p-2.5">Причина выявления (Анти-откат)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                {overbuy_rows_html}
              </tbody>
            </table>
          </div>
          <div class="bg-red-950/30 border border-red-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-red-300 mt-2">
            <span>Итого заморожено денег в лишних закупках:</span>
            <span class="text-base font-black mono">{overbuy_rub}</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 3: ПРОСПАННЫЙ ДЕФИЦИТ -->
        <div id="tabContent-deficits" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Ходовые позиции, которые закончились на складе и приводят к упущенной прибыли прямо сейчас:
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">Код 1С</th>
                  <th class="p-2.5">Наименование</th>
                  <th class="p-2.5 text-center">Остаток сейчас</th>
                  <th class="p-2.5 text-center">Спрос в месяц</th>
                  <th class="p-2.5 text-right">Риск потерь в месяц</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                {deficit_rows_html}
              </tbody>
            </table>
          </div>
          <div class="bg-amber-950/30 border border-amber-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-amber-300 mt-2">
            <span>Суммарный риск упущенной выручки:</span>
            <span class="text-base font-black mono">{deficit_rub}</span>
          </div>
        </div>

        <!-- ТАБЛИЦА 4: НОЧНЫЕ БРОНИ -->
        <div id="tabContent-reservations" class="space-y-2 text-xs hidden">
          <div class="text-[11px] text-slate-400 mb-2">
            Реальные брони, оформленные ботом во внерабочее время (кассир видит товар отложенным на кассе):
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="p-2.5">ID брони</th>
                  <th class="p-2.5">Дата и время</th>
                  <th class="p-2.5">Клиент</th>
                  <th class="p-2.5">Деталь</th>
                  <th class="p-2.5 text-right">Сумма</th>
                  <th class="p-2.5 text-center">Статус в кассе</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                {res_rows_html}
              </tbody>
            </table>
          </div>
          <div class="bg-purple-950/30 border border-purple-800/40 p-3 rounded-xl flex items-center justify-between text-xs font-bold text-purple-300 mt-2">
            <span>Выручка ночного бота, сохраненная магазину:</span>
            <span class="text-base font-black mono">{night_rub}</span>
          </div>
        </div>

      </div>

    </div>

  </main>

  <footer class="mt-8 border-t border-slate-800/80 py-4 text-center text-xs text-slate-400">
    «АВТОСКЛАД-ИИ» • Система автоматизации и ликвидации неликвида для Вячеслава Юрьевича | Пермь • Телефон поддержки: <a href="tel:+79028028246" class="text-sky-400 hover:underline">+7 (902) 802-82-46</a> • Telegram: <a href="https://t.me/dkazak1999" target="_blank" class="text-sky-400 hover:underline">@dkazak1999</a>
  </footer>

  <script>
    const RADAR_DATA = {json_str};

    function switchTab(tabId) {{
      const tabs = ['unfrozen', 'overbuy', 'deficits', 'reservations'];
      tabs.forEach(t => {{
        const btn = document.getElementById('tabBtn-' + t);
        const content = document.getElementById('tabContent-' + t);
        if (t === tabId) {{
          btn.className = "tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-emerald-500/20 text-emerald-300 border border-emerald-500/40";
          content.classList.remove('hidden');
        }} else {{
          btn.className = "tab-btn px-3 py-1.5 rounded-xl font-bold transition bg-slate-900 text-slate-400 border border-slate-800";
          content.classList.add('hidden');
        }}
      }});
    }}

    function handleBotAction(action) {{
      const feedback = document.getElementById('userFeedbackMsg');
      const textEl = document.getElementById('userFeedbackText');
      feedback.classList.remove('hidden');

      if (action === 'block_order') {{
        textEl.textContent = "🚫 Заблокировать лишний заказ закупщика ({overbuy_rub})";
        alert("✅ Команда принята! Заказ поставщику на сумму {overbuy_rub} заблокирован в 1С. Закупщику отправлено уведомление о наличии дублей на складе.");
      }} else if (action === 'send_deficit') {{
        textEl.textContent = "📋 Отправить список дефицита на дозаказ";
        alert("✅ Список из 3 ходовых позиций с нулевым остатком сформирован и направлен старшему менеджеру по закупкам!");
      }} else if (action === 'discount_promo') {{
        textEl.textContent = "🏷️ Уценить остаток неликвида на -10%";
        alert("✅ Скидка 10% применена! Цены в фидах Avito XML и Drom CSV обновлены автоматически.");
      }}
    }}

    function copyTelegramDigest() {{
      const m = RADAR_DATA.metrics;
      const digest = `📊 ЕЖЕНЕДЕЛЬНЫЙ РАДАР СОБСТВЕННИКА • АВТОСКЛАД-ИИ\\n👤 Для: {OWNER_NAME}\\n==============================================\\n💰 ФИНАНСОВЫЙ ИТОГ НЕДЕЛИ: ${{m.net_financial_impact_rub.toLocaleString()}} ₽\\n==============================================\\n🟢 Разморожено неликвида: +${{m.unfrozen_cash_rub.toLocaleString()}} ₽\\n🔴 Ошибки закупщика (анти-откат): -${{m.overbuy_waste_rub.toLocaleString()}} ₽\\n🚨 Риск дефицита: ${{m.lost_revenue_risk_rub.toLocaleString()}} ₽/мес\\n🌙 Ночной ИИ-бот: +${{m.night_bot_revenue_rub.toLocaleString()}} ₽`;
      navigator.clipboard.writeText(digest).then(() => {{
        alert("✅ Текст еженедельного дайджеста скопирован в буфер обмена!");
      }});
    }}
  </script>
</body>
</html>
"""

out_root = BASE_DIR / "owner_radar.html"
with open(out_root, "w", encoding="utf-8") as f:
    f.write(html_template)

if GITHUB_PAGES_DIR.exists():
    with open(GITHUB_PAGES_DIR / "owner_radar.html", "w", encoding="utf-8") as f:
        f.write(html_template)

print(f"owner_radar.html written successfully ({len(html_template)} bytes)")
