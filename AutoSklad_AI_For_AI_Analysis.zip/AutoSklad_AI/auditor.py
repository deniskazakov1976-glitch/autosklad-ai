"""
Модуль 1: auditor.py
Платформа «АВТОСКЛАД-ИИ»
Генератор технического отчета ревизии склада из 1С:
- Поиск скрытых дублей и пересортицы (через нормализацию артикулов + нечеткий поиск rapidfuzz)
- Выявление замороженного неликвида (>270 дней без движения или 0 продаж)
- Выявление скрытого дефицита ходовых позиций и расчет упущенной выручки
- Экспорт сводки в JSON и генерация визуального HTML-отчета на Jinja2
"""

import sys
import os
import re
import math
import json
import argparse
from typing import Dict, List, Any, Optional, Tuple
import pandas as pd
from rapidfuzz import fuzz
from jinja2 import Template
from inventory_guard import detect_and_read_1c_file, parse_1c_number, AntonymGuard, clean_article

# 1. СЛОВАРЬ СИНОНИМОВ АВТОСЛЕНГА ДЛЯ ВЫРАВНИВАНИЯ НАИМЕНОВАНИЙ
SLANG_SYNONYMS = {
    r"\bгур\b": "гидроусилитель руля насос",
    r"\bг/у\b": "гидроусилитель руля насос",
    r"\bрцс\b": "рабочий цилиндр сцепления",
    r"\bгцс\b": "главный цилиндр сцепления",
    r"\bгтц\b": "главный тормозной цилиндр",
    r"\bртц\b": "рабочий тормозной цилиндр",
    r"\bгбц\b": "головка блока цилиндров",
    r"\bкпп\b": "коробка передач",
    r"\bдв\b": "двигатель",
    r"\bдвс\b": "двигатель",
    r"\bэбу\b": "блок управления двигателем",
    r"\bоренбург\b": "радиатор оренбург",
    r"\bмедн\b": "медный",
    r"\bориг\b": "оригинал",
    r"\bохл\b": "охлаждения",
}


def normalize_item_name(name: str) -> str:
    """Очищает наименование детали и раскрывает сокращения автосленга."""
    if not name or pd.isna(name):
        return ""
    text = str(name).lower().strip()
    text = re.sub(r"[^\w\s\.-]", " ", text)
    for pattern, replacement in SLANG_SYNONYMS.items():
        text = re.sub(pattern, replacement, text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


class InventoryAuditor:
    """Анализатор складской базы 1С для выявления дублей, неликвида и дефицита."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.raw_df: pd.DataFrame = pd.DataFrame()
        self.df: pd.DataFrame = pd.DataFrame()
        self.anomalies: List[Dict[str, Any]] = []
        self.summary: Dict[str, Any] = {}

    def load_data(self) -> None:
        """Загружает файл Excel или CSV и стандартизирует имена колонок с авто-пропуском шапки и защитой от пересортицы."""
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"Файл не найден: {self.file_path}")

        df_clean, anomalies = detect_and_read_1c_file(self.file_path)
        self.anomalies = anomalies
        self.raw_df = df_clean.copy()

        df = df_clean.copy()
        df["clean_article"] = df["raw_article"].apply(clean_article)
        df["norm_name"] = df["raw_name"].apply(normalize_item_name)
        df["total_cost_val"] = df["stock_qty"] * df["price_cost"]
        df["total_retail_val"] = df["stock_qty"] * df["price_retail"]

        self.df = df

    def find_duplicates(self) -> List[Dict[str, Any]]:
        """
        Ищет скрытые дубликаты внутри базы 1С:
        1. Точное совпадение по clean_article (если артикул не пустой).
        2. Высокое нечеткое сходство по norm_name (rapidfuzz token_set_ratio >= 82%).
        """
        clusters: List[Dict[str, Any]] = []
        assigned_indices = set()

        # 1. Поиск по нормализованному артикулу
        has_article = self.df[self.df["clean_article"] != ""]
        article_groups = has_article.groupby("clean_article")

        for clean_art, group in article_groups:
            if len(group) > 1:
                indices = group.index.tolist()
                items = group.to_dict(orient="records")
                # Проверяем, есть ли критичный дисбаланс (на одном дубле 0, на другом > 0)
                has_zero = any(it["stock_qty"] == 0 for it in items)
                has_positive = any(it["stock_qty"] > 0 for it in items)
                risk_overbuy = has_zero and has_positive

                clusters.append({
                    "cluster_id": f"ART-{clean_art}",
                    "match_type": "Артикул (точное совпадение)",
                    "clean_article": clean_art,
                    "count": len(items),
                    "total_stock": sum(it["stock_qty"] for it in items),
                    "risk_overbuy": risk_overbuy,
                    "item_list": [
                        {
                            "raw_code": it["raw_code"],
                            "raw_name": it["raw_name"],
                            "raw_article": it["raw_article"],
                            "stock_qty": it["stock_qty"],
                            "price_retail": it["price_retail"],
                            "price_cost": it["price_cost"],
                            "sales_12m": it["sales_12m"]
                        }
                        for it in items
                    ]
                })
                assigned_indices.update(indices)

        # 2. Нечеткий поиск по наименованию (для строк без артикула или не вошедших в группы)
        unmatched = self.df[~self.df.index.isin(assigned_indices)].copy()
        unmatched_records = unmatched.to_dict(orient="index")
        unmatched_keys = list(unmatched_records.keys())

        visited_keys = set()
        for i, idx1 in enumerate(unmatched_keys):
            if idx1 in visited_keys:
                continue
            rec1 = unmatched_records[idx1]
            cluster_items = [rec1]
            matched_with_idx1 = []

            for j in range(i + 1, len(unmatched_keys)):
                idx2 = unmatched_keys[j]
                if idx2 in visited_keys:
                    continue
                rec2 = unmatched_records[idx2]

                # Защита от склейки: если у обеих записей есть разные артикулы,
                # они не могут быть дублями одной детали!
                art1 = rec1.get("clean_article", "")
                art2 = rec2.get("clean_article", "")
                if art1 and art2 and art1 != art2:
                    continue

                # Antonym Guard: Защита от опасных склеек левый/правый, передний/задний и др.
                is_conf, reason = AntonymGuard.are_conflicting(rec1["raw_name"], rec2["raw_name"])
                if is_conf:
                    continue

                # Защита от несовместимых типов узлов (картер/колокол vs диск, блок vs гбц и др.)
                n1 = rec1["norm_name"].lower()
                n2 = rec2["norm_name"].lower()
                incompatible_types = [
                    (r"\bкартер\b|\bколокол\b", r"\bдиск\b"),
                    (r"\bблок\b", r"\bголовк|\bгбц\b"),
                    (r"\bстартер\b", r"\bгенератор\b"),
                    (r"\bрадиатор\b", r"\bпатруб|\bтермостат\b"),
                ]
                incompat = False
                for p1, p2 in incompatible_types:
                    if (re.search(p1, n1) and re.search(p2, n2)) or (re.search(p2, n1) and re.search(p1, n2)):
                        incompat = True
                        break
                if incompat:
                    continue

                # Сравнение нормализованных наименований
                score = fuzz.token_set_ratio(rec1["norm_name"], rec2["norm_name"])
                if score >= 85.0:
                    cluster_items.append(rec2)
                    matched_with_idx1.append(idx2)

            if len(cluster_items) > 1:
                visited_keys.add(idx1)
                visited_keys.update(matched_with_idx1)
                has_zero = any(it["stock_qty"] == 0 for it in cluster_items)
                has_positive = any(it["stock_qty"] > 0 for it in cluster_items)

                clusters.append({
                    "cluster_id": f"FUZZ-{rec1['raw_code']}",
                    "match_type": "Автосленг и нечеткое совпадение",
                    "clean_article": rec1.get("clean_article", ""),
                    "count": len(cluster_items),
                    "total_stock": sum(it["stock_qty"] for it in cluster_items),
                    "risk_overbuy": has_zero and has_positive,
                    "item_list": [
                        {
                            "raw_code": it["raw_code"],
                            "raw_name": it["raw_name"],
                            "raw_article": it["raw_article"],
                            "stock_qty": it["stock_qty"],
                            "price_retail": it["price_retail"],
                            "price_cost": it["price_cost"],
                            "sales_12m": it["sales_12m"]
                        }
                        for it in cluster_items
                    ]
                })

        return clusters

    def calculate_dead_stock(self) -> Tuple[float, float, List[Dict[str, Any]]]:
        """
        Расчет неликвидов:
        Остаток > 0 И (Продажи за 12 мес == 0 ИЛИ дней без движения >= 270).
        """
        dead_cond = (self.df["stock_qty"] > 0) & (
            (self.df["sales_12m"] == 0) | (self.df["days_no_movement"] >= 270)
        )
        dead_df = self.df[dead_cond].copy()

        dead_capital_cost = float(dead_df["total_cost_val"].sum())
        dead_capital_retail = float(dead_df["total_retail_val"].sum())

        dead_df = dead_df.sort_values(by="total_cost_val", ascending=False)
        top_dead = dead_df.head(30).to_dict(orient="records")

        formatted_top_dead = [
            {
                "raw_code": row["raw_code"],
                "raw_name": row["raw_name"],
                "raw_article": row["raw_article"],
                "stock_qty": row["stock_qty"],
                "price_cost": row["price_cost"],
                "price_retail": row["price_retail"],
                "frozen_cost": round(row["total_cost_val"], 2),
                "frozen_retail": round(row["total_retail_val"], 2),
                "days_no_movement": int(row["days_no_movement"]),
                "sales_12m": row["sales_12m"]
            }
            for row in top_dead
        ]

        return dead_capital_cost, dead_capital_retail, formatted_top_dead, int(len(dead_df))

    def calculate_out_of_stock(self) -> Tuple[float, float, List[Dict[str, Any]]]:
        """
        Расчет дефицита ходовых позиций:
        Среднемесячные продажи (sales_12m / 12) >= 3.0 И текущий остаток <= 1.
        """
        out_of_stock_list: List[Dict[str, Any]] = []
        total_monthly_loss = 0.0
        total_recommended_budget = 0.0

        for _, row in self.df.iterrows():
            avg_monthly = row["sales_12m"] / 12.0
            if avg_monthly >= 3.0 and row["stock_qty"] <= 1.0:
                # Упущенная месячная выручка
                lost_revenue_month = avg_monthly * row["price_retail"]
                total_monthly_loss += lost_revenue_month

                # Рекомендуемый объем заказа на 30 дней с запасом 20%
                rec_qty = max(1, math.ceil(avg_monthly * 1.2) - int(row["stock_qty"]))
                budget_needed = rec_qty * row["price_cost"]
                total_recommended_budget += budget_needed

                out_of_stock_list.append({
                    "raw_code": row["raw_code"],
                    "raw_name": row["raw_name"],
                    "raw_article": row["raw_article"],
                    "stock_qty": row["stock_qty"],
                    "sales_12m": row["sales_12m"],
                    "avg_monthly_sales": round(avg_monthly, 1),
                    "price_retail": row["price_retail"],
                    "price_cost": row["price_cost"],
                    "lost_monthly_revenue": round(lost_revenue_month, 2),
                    "recommended_order_qty": rec_qty,
                    "budget_needed": round(budget_needed, 2)
                })

        out_of_stock_list.sort(key=lambda x: x["lost_monthly_revenue"], reverse=True)
        return total_monthly_loss, total_recommended_budget, out_of_stock_list

    def run_audit(self) -> Dict[str, Any]:
        """Запускает полный цикл ревизии базы склада 1С."""
        self.load_data()

        total_skus = len(self.df)
        total_stock_units = float(self.df["stock_qty"].sum())
        total_cost_valuation = float(self.df["total_cost_val"].sum())
        total_retail_valuation = float(self.df["total_retail_val"].sum())

        duplicates = self.find_duplicates()
        dead_cost, dead_retail, top_dead, total_dead_count = self.calculate_dead_stock()
        lost_monthly, rec_budget, out_of_stock = self.calculate_out_of_stock()

        dup_items_count = sum(d["count"] for d in duplicates)
        risk_overbuy_count = sum(1 for d in duplicates if d["risk_overbuy"])

        self.summary = {
            "file_name": os.path.basename(self.file_path),
            "anomalies": self.anomalies,
            "anomalies_count": len(self.anomalies),
            "kpi": {
                "total_skus": total_skus,
                "total_stock_units": round(total_stock_units, 1),
                "total_cost_valuation": round(total_cost_valuation, 2),
                "total_retail_valuation": round(total_retail_valuation, 2),
                "dead_capital_cost": round(dead_cost, 2),
                "dead_capital_retail": round(dead_retail, 2),
                "dead_stock_ratio_pct": round((dead_cost / total_cost_valuation * 100), 1) if total_cost_valuation > 0 else 0,
                "dead_items_count": total_dead_count,
                "duplicate_clusters_count": len(duplicates),
                "duplicate_items_total": dup_items_count,
                "risk_overbuy_clusters": risk_overbuy_count,
                "out_of_stock_count": len(out_of_stock),
                "lost_monthly_revenue": round(lost_monthly, 2),
                "recommended_order_budget": round(rec_budget, 2)
            },
            "duplicate_clusters": duplicates,
            "top_dead_stock": top_dead,
            "out_of_stock_items": out_of_stock
        }

        return self.summary

    def export_json(self, output_path: str = "audit_summary.json") -> str:
        """Сохраняет сводные результаты ревизии в JSON."""
        if not self.summary:
            self.run_audit()
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(self.summary, f, ensure_ascii=False, indent=2)
        return output_path

    def export_html_report(self, output_path: str = "audit_report.html") -> str:
        """Генерирует визуальный презентационный HTML-отчет ревизии склада."""
        if not self.summary:
            self.run_audit()

        html_template = """
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Отчет технической ревизии склада 1С • АВТОСКЛАД-ИИ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #0b0f19; color: #f1f5f9; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    @media print {
      body { background-color: #ffffff; color: #0f172a; }
      .no-print { display: none !important; }
      .print-border { border: 1px solid #cbd5e1 !important; }
      .print-text-dark { color: #0f172a !important; }
    }
  </style>
</head>
<body class="p-3 sm:p-8">

  <div class="max-w-6xl mx-auto">
    <!-- ПАНЕЛЬ УПРАВЛЕНИЯ -->
    <div class="flex flex-wrap items-center justify-between gap-4 mb-6 no-print">
      <div class="flex items-center gap-3">
        <span class="bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 text-xs font-black px-3 py-1.5 rounded-lg tracking-wider uppercase shadow">
          ★ АВТОСКЛАД-ИИ
        </span>
        <span class="text-sm text-slate-400">Файл анализа: <b class="text-slate-200">{{ summary.file_name }}</b></span>
      </div>
      <div class="flex gap-2">
        <button onclick="window.print()" class="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition flex items-center gap-1.5">
          🖨 Печать / Сохранить в PDF
        </button>
      </div>
    </div>

    <!-- ТИТУЛЬНЫЙ БЛОК -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl relative overflow-hidden">
      <div class="absolute -right-12 -top-12 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-6 mb-6">
        <div>
          <div class="text-xs font-black uppercase tracking-widest text-orange-400 mb-1">
            Конфиденциально • Технический аудит склада 1С
          </div>
          <h1 class="text-xl sm:text-3xl font-black text-white">
            Отчет ревизии складских остатков и упущенной выгоды
          </h1>
          <p class="text-slate-400 text-sm mt-1">
            Специфика учета: автозапчасти ГАЗ / Волга / УАЗ / LCV • Найдено дублей, неликвидов и дефицита
          </p>
        </div>
        <div class="text-right text-xs text-slate-400">
          <div class="font-bold text-slate-200 text-sm">Система «АВТОСКЛАД-ИИ»</div>
          <div>Прямой контакт: <b class="text-orange-400">+7 (902) 802-82-46</b></div>
          <div>Telegram: <a href="https://t.me/dkazak1999" target="_blank" class="text-sky-400 hover:underline">@dkazak1999</a></div>
        </div>
      </div>

      <!-- 4 КЛЮЧЕВЫХ KPI В ДЕНЬГАХ -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- KPI 1 -->
        <div class="bg-slate-950 p-4 rounded-xl border border-red-500/30">
          <div class="text-[11px] font-bold text-red-400 uppercase tracking-wider mb-1">Заморожено в неликвиде</div>
          <div class="text-2xl font-black text-red-400 mono">{{ "{:,.0f}".format(summary.kpi.dead_capital_cost).replace(',', ' ') }} ₽</div>
          <div class="text-xs text-slate-400 mt-1">По закупочной цене ({{ summary.kpi.dead_stock_ratio_pct }}% от склада)</div>
        </div>

        <!-- KPI 2 -->
        <div class="bg-slate-950 p-4 rounded-xl border border-amber-500/30">
          <div class="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-1">Скрытые дубли в 1С</div>
          <div class="text-2xl font-black text-amber-400 mono">{{ summary.kpi.duplicate_clusters_count }} кластеров</div>
          <div class="text-xs text-slate-400 mt-1">{{ summary.kpi.risk_overbuy_clusters }} групп с риском лишнего закупа</div>
        </div>

        <!-- KPI 3 -->
        <div class="bg-slate-950 p-4 rounded-xl border border-emerald-500/30">
          <div class="text-[11px] font-bold text-emerald-400 uppercase tracking-wider mb-1">Упущенная касса в мес.</div>
          <div class="text-2xl font-black text-emerald-400 mono">{{ "{:,.0f}".format(summary.kpi.lost_monthly_revenue).replace(',', ' ') }} ₽</div>
          <div class="text-xs text-slate-400 mt-1">{{ summary.kpi.out_of_stock_count }} ходовых позиций в нуле</div>
        </div>

        <!-- KPI 4 -->
        <div class="bg-slate-950 p-4 rounded-xl border border-cyan-500/30">
          <div class="text-[11px] font-bold text-cyan-400 uppercase tracking-wider mb-1">Весь склад в себестоимости</div>
          <div class="text-2xl font-black text-white mono">{{ "{:,.0f}".format(summary.kpi.total_cost_valuation).replace(',', ' ') }} ₽</div>
          <div class="text-xs text-slate-400 mt-1">{{ summary.kpi.total_skus }} SKU / {{ "{:,.0f}".format(summary.kpi.total_stock_units).replace(',', ' ') }} шт. деталей</div>
        </div>
      </div>
    </div>

    <!-- РАЗДЕЛ 1: СКРЫТЫЕ ДУБЛИ В 1С -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <div>
          <span class="text-xs font-bold text-amber-400 uppercase tracking-wider">Дыра в учете №1</span>
          <h2 class="text-lg sm:text-xl font-bold text-white">Скрытые дубли в 1С (Опасность ложного дефицита)</h2>
        </div>
        <span class="bg-amber-500/20 text-amber-300 font-bold text-xs px-3 py-1 rounded-full">
          Найдено: {{ summary.kpi.duplicate_clusters_count }} групп
        </span>
      </div>
      <p class="text-xs text-slate-400 mb-6">
        Одна и та же деталь заведена в 1С под разными названиями или с опечатками в артикуле. Когда на одной карточке остаток становится 0, закупщик видит дефицит и заказывает деталь снова, хотя на соседнем складе или дубле лежит остаток!
      </p>

      <div class="space-y-4">
        {% for cluster in summary.duplicate_clusters %}
        <div class="bg-slate-950 border {% if cluster.risk_overbuy %}border-red-500/50{% else %}border-slate-800{% endif %} rounded-xl p-4">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2 mb-3">
            <div class="flex items-center gap-2">
              <span class="bg-slate-800 text-slate-300 text-[10px] font-mono px-2 py-0.5 rounded">{{ cluster.match_type }}</span>
              <span class="text-xs font-bold text-slate-200">Кластер {{ cluster.cluster_id }}</span>
              {% if cluster.risk_overbuy %}
              <span class="bg-red-500/20 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded">⚠ РИСК ПЕРЕЗАКУПА: остаток 0 + >0</span>
              {% endif %}
            </div>
            <div class="text-xs text-slate-400 font-mono">
              Суммарный остаток: <b class="text-emerald-400">{{ cluster.total_stock }} шт.</b>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="text-slate-400 border-b border-slate-900">
                  <th class="py-1 px-2">Код 1С</th>
                  <th class="py-1 px-2">Наименование в базе</th>
                  <th class="py-1 px-2">Артикул 1С</th>
                  <th class="py-1 px-2 text-right">Остаток</th>
                  <th class="py-1 px-2 text-right">Розница</th>
                  <th class="py-1 px-2 text-right">Продажи (год)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-900 font-mono">
                {% for it in cluster.item_list %}
                <tr class="{% if it.stock_qty == 0 %}text-red-400/90{% else %}text-slate-200{% endif %}">
                  <td class="py-1 px-2 text-slate-400">{{ it.raw_code }}</td>
                  <td class="py-1 px-2 font-sans font-medium">{{ it.raw_name }}</td>
                  <td class="py-1 px-2 text-slate-300">{{ it.raw_article or '—' }}</td>
                  <td class="py-1 px-2 text-right font-bold {% if it.stock_qty == 0 %}text-red-400{% else %}text-emerald-400{% endif %}">{{ it.stock_qty }} шт.</td>
                  <td class="py-1 px-2 text-right text-slate-300">{{ "{:,.0f}".format(it.price_retail) }} ₽</td>
                  <td class="py-1 px-2 text-right text-slate-400">{{ it.sales_12m }} шт.</td>
                </tr>
                {% endfor %}
              </tbody>
            </table>
          </div>
        </div>
        {% endfor %}
      </div>
    </div>

    <!-- РАЗДЕЛ 2: ТОП-30 НЕЛИКВИДОВ -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <div>
          <span class="text-xs font-bold text-red-400 uppercase tracking-wider">Замороженные деньги</span>
          <h2 class="text-lg sm:text-xl font-bold text-white">ТОП неликвидных позиций (Без движения > 270 дней)</h2>
        </div>
        <div class="text-right">
          <span class="text-xs text-slate-400">Сумма в топе: </span>
          <span class="text-sm font-bold text-red-400 mono">
            {{ "{:,.0f}".format(summary.kpi.dead_capital_cost).replace(',', ' ') }} ₽
          </span>
        </div>
      </div>
      <p class="text-xs text-slate-400 mb-6">
        Эти запчасти годами лежат на стеллажах. В 1С их не ищут, но покупатели в соседних регионах прямо сейчас ищут их на Авито и Дроме через поиск по артикулу и модели.
      </p>

      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
          <thead>
            <tr class="text-slate-400 border-b border-slate-800 pb-2">
              <th class="py-2 px-3">Код</th>
              <th class="py-2 px-3">Наименование</th>
              <th class="py-2 px-3">Артикул</th>
              <th class="py-2 px-3 text-right">Остаток</th>
              <th class="py-2 px-3 text-right">Закупка</th>
              <th class="py-2 px-3 text-right">Заморожено (Закуп)</th>
              <th class="py-2 px-3 text-right">Простой</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800 font-mono">
            {% for item in summary.top_dead_stock %}
            <tr class="hover:bg-slate-800/40 transition">
              <td class="py-2 px-3 text-slate-400">{{ item.raw_code }}</td>
              <td class="py-2 px-3 font-sans font-medium text-slate-200">{{ item.raw_name }}</td>
              <td class="py-2 px-3 text-slate-300">{{ item.raw_article or '—' }}</td>
              <td class="py-2 px-3 text-right text-white font-bold">{{ item.stock_qty }} шт.</td>
              <td class="py-2 px-3 text-right text-slate-400">{{ "{:,.0f}".format(item.price_cost) }} ₽</td>
              <td class="py-2 px-3 text-right font-bold text-red-400">{{ "{:,.0f}".format(item.frozen_cost).replace(',', ' ') }} ₽</td>
              <td class="py-2 px-3 text-right text-amber-400">{{ item.days_no_movement }} дн.</td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>

    <!-- РАЗДЕЛ 3: ДЕФИЦИТ ХОДОВЫХ ПОЗИЦИЙ -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <div>
          <span class="text-xs font-bold text-emerald-400 uppercase tracking-wider">Упущенная прибыль</span>
          <h2 class="text-lg sm:text-xl font-bold text-white">Скрытый дефицит ходовых позиций (Out-of-Stock)</h2>
        </div>
        <div class="text-right">
          <span class="text-xs text-slate-400">Упущенная выручка в месяц: </span>
          <span class="text-sm font-bold text-emerald-400 mono">
            + {{ "{:,.0f}".format(summary.kpi.lost_monthly_revenue).replace(',', ' ') }} ₽
          </span>
        </div>
      </div>
      <p class="text-xs text-slate-400 mb-6">
        Товары с высоким годовым спросом, которые на складе подошли к нулю. Магазин ежедневно теряет постоянных клиентов и выручку из-за отсутствия базовых расходников.
      </p>

      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
          <thead>
            <tr class="text-slate-400 border-b border-slate-800 pb-2">
              <th class="py-2 px-3">Код</th>
              <th class="py-2 px-3">Наименование</th>
              <th class="py-2 px-3 text-right">Текущий остаток</th>
              <th class="py-2 px-3 text-right">Спрос в мес.</th>
              <th class="py-2 px-3 text-right">Упущенная выручка/мес</th>
              <th class="py-2 px-3 text-right">Реком. заказ на 30 дн.</th>
              <th class="py-2 px-3 text-right">Бюджет заказа</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800 font-mono">
            {% for item in summary.out_of_stock_items %}
            <tr class="hover:bg-slate-800/40 transition">
              <td class="py-2 px-3 text-slate-400">{{ item.raw_code }}</td>
              <td class="py-2 px-3 font-sans font-medium text-slate-200">{{ item.raw_name }}</td>
              <td class="py-2 px-3 text-right font-bold text-red-400">{{ item.stock_qty }} шт.</td>
              <td class="py-2 px-3 text-right text-slate-300">{{ item.avg_monthly_sales }} шт/мес</td>
              <td class="py-2 px-3 text-right font-bold text-emerald-400">+ {{ "{:,.0f}".format(item.lost_monthly_revenue).replace(',', ' ') }} ₽</td>
              <td class="py-2 px-3 text-right text-white font-bold">{{ item.recommended_order_qty }} шт.</td>
              <td class="py-2 px-3 text-right text-slate-400">{{ "{:,.0f}".format(item.budget_needed).replace(',', ' ') }} ₽</td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>

    <!-- ПОДВАЛ С РЕШЕНИЕМ -->
    <div class="bg-gradient-to-r from-slate-900 to-slate-950 border-2 border-orange-500/50 rounded-2xl p-6 sm:p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
      <div class="space-y-2">
        <h3 class="text-lg sm:text-xl font-black text-white">Как вернуть эти деньги в кассу магазина?</h3>
        <p class="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          Система «АВТОСКЛАД-ИИ» за 14 дней наводит порядок в справочнике 1С, склеивает дубли, привязывает кросс-номера и автоматически выгружает неликвиды на Авито и Дром с круглосуточным ИИ-продавцом в чатах.
        </p>
      </div>
      <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
        <a href="https://wa.me/79028028246" target="_blank" class="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black px-6 py-3.5 rounded-xl text-center text-xs sm:text-sm transition shadow-lg">
          💬 Написать в WhatsApp
        </a>
        <a href="https://t.me/dkazak1999" target="_blank" class="bg-sky-500 hover:bg-sky-600 text-slate-950 font-black px-6 py-3.5 rounded-xl text-center text-xs sm:text-sm transition shadow-lg">
          ✈️ Telegram: @dkazak1999
        </a>
      </div>
    </div>

  </div>

</body>
</html>
"""
        template = Template(html_template, autoescape=True)
        rendered_html = template.render(summary=self.summary)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(rendered_html)

        return output_path


def main():
    parser = argparse.ArgumentParser(description="АВТОСКЛАД-ИИ: Модуль 1 (Аудитор склада)")
    parser.add_argument("file_path", nargs="?", default="sample_1c_gaz_uaz.xlsx", help="Путь к файлу выгрузки 1С (.xlsx или .csv)")
    parser.add_argument("--json", default="audit_summary.json", help="Путь к результирующему файлу JSON")
    parser.add_argument("--html", default="audit_report.html", help="Путь к результирующему файлу HTML")

    args = parser.parse_args()

    print(f"🚀 Запуск аудита склада 1С по файлу: {args.file_path}")
    auditor = InventoryAuditor(args.file_path)
    summary = auditor.run_audit()

    kpi = summary["kpi"]
    print("\n--- РЕЗУЛЬТАТЫ АУДИТА СКЛАДА ---")
    print(f"Всего позиций в выгрузке: {kpi['total_skus']} SKU ({kpi['total_stock_units']} шт.)")
    print(f"Общая себестоимость склада: {kpi['total_cost_valuation']:,.0f} ₽".replace(",", " "))
    print(f"💸 Заморожено в неликвиде (>270 дней / 0 продаж): {kpi['dead_capital_cost']:,.0f} ₽ ({kpi['dead_stock_ratio_pct']}% склада)".replace(",", " "))
    print(f"🔍 Найдено групп дублей в 1С: {kpi['duplicate_clusters_count']} (в т.ч. с риском перезакупа: {kpi['risk_overbuy_clusters']})")
    print(f"🚨 Дефицит ходовых позиций (остаток <= 1): {kpi['out_of_stock_count']} SKU")
    print(f"📈 Упущенная месячная выручка: {kpi['lost_monthly_revenue']:,.0f} ₽ / мес".replace(",", " "))

    json_file = auditor.export_json(args.json)
    html_file = auditor.export_html_report(args.html)

    print(f"\n✅ JSON-сводка сохранена: {json_file}")
    print(f"✅ HTML-отчет сохранен: {html_file}")


if __name__ == "__main__":
    main()
