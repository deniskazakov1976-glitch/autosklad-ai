"""
Платформа «АВТОСКЛАД-ИИ»
Централизованная конфигурация системы (config.py)
Устраняет жесткую привязку к путям Windows (диск F:) и обеспечивает переносимость (Linux/Docker/macOS).
"""

import os
from pathlib import Path

# Базовая директория проекта (определяется динамически относительно расположения файла)
BASE_DIR = Path(__file__).resolve().parent

# Пути к базам данных и файлам данных
DB_PATH = os.environ.get("AUTOSKLAD_DB_PATH", str(BASE_DIR / "master_catalog.db"))
SAMPLE_1C_PATH = os.environ.get("AUTOSKLAD_1C_PATH", str(BASE_DIR / "sample_1c_gaz_uaz.xlsx"))
WEEK_PREV_PATH = os.environ.get("AUTOSKLAD_WEEK_PREV", str(BASE_DIR / "week_prev.xlsx"))
WEEK_CURR_PATH = os.environ.get("AUTOSKLAD_WEEK_CURR", str(BASE_DIR / "week_curr.xlsx"))

# Папка публикации для GitHub Pages
GITHUB_PAGES_DIR = BASE_DIR / "github-pages"

# Бизнес-константы платформы и контакты собственника
OWNER_NAME = "Вячеслав Юрьевич"
STORE_PHONE = "+7 (902) 802-82-46"
STORE_PHONE_CLEAN = "79028028246"
STORE_ADDRESS = "г. Пермь, ул. Промышленная, 8"
TELEGRAM_SUPPORT = "@dkazak1999"
WHATSAPP_LINK = f"https://wa.me/{STORE_PHONE_CLEAN}"

# Параметры аудита и пороговые значения
DEAD_STOCK_DAYS_THRESHOLD = 180  # Дней без движения для квалификации как неликвид
DISCOUNT_DEAD_STOCK_PERCENT = 0.10  # Скидка на неликвид (10%)
MIN_MARGIN_MULTIPLIER = 1.05  # Минимальная маржинальность (себестоимость * 1.05)
MIN_PRICE_FILTER = 300.0  # Фильтр дешевой мелочевки для витрин
MAX_AVITO_TITLE_LEN = 50  # Максимальная длина заголовка Авито по границе слова
