"""
Модуль 2: seed_master_catalog.py
Платформа «АВТОСКЛАД-ИИ»
Создание и первичное наполнение базы данных SQLite: master_catalog.db
Таблицы:
1. master_catalog — «Золотой справочник» запчастей ГАЗ/УАЗ/Волга
2. client_sku_mapping — Таблица кэширования связей выгрузок 1С с эталонной базой
"""

import sqlite3
import json
import os
import re
from typing import List, Dict, Any
from pathlib import Path
from config import DB_PATH
from inventory_guard import clean_article as clean_art


MASTER_RECORDS = [
    # 1. Насос ГУР ГАЗель Бизнес
    {
        "master_id": "GAZ-STEER-001",
        "canonical_title": "Насос ГУР ГАЗель Бизнес, Next (УМЗ 4216) ШНКФ",
        "oem_number": clean_art("ШНКФ 453471.125"),
        "cross_numbers": [clean_art(x) for x in ["3302-3407010", "4216-3407010", "ШНКФ453471125", "453471.125-40", "PP-3302-4216"]],
        "brands_analogs": ["БЗАГУ (Борисов)", "Пекар", "АДС", "Автогидроусилитель", "Kraft"],
        "applicability": "ГАЗ-3302, ГАЗель Бизнес, ГАЗель Next, Соболь 2752, Баргузин; дв. УМЗ-4216, Evotech 2.7 (A274)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Рулевое управление/Насосы ГУР",
        "image_urls": [
            "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"
        ]
    },
    # 2. Радиатор охлаждения 3302 медный 3-рядный
    {
        "master_id": "GAZ-COOL-001",
        "canonical_title": "Радиатор охлаждения ГАЗ-3302 медный 3-х рядный",
        "oem_number": clean_art("3302-1301010-33"),
        "cross_numbers": [clean_art(x) for x in ["3302.1301.010-33", "3302130101033", "LRc 0302b", "TR-3302-3R"]],
        "brands_analogs": ["Оренбургский радиаторный завод", "ШААЗ", "Luzar", "Tadashi"],
        "applicability": "ГАЗ-3302, 2705, 3221 ГАЗель Бизнес; дв. УМЗ-4216, ЗМЗ-405, ЗМЗ-406",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система охлаждения/Радиаторы",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 3. Рабочий цилиндр сцепления РЦС
    {
        "master_id": "GAZ-CLUTCH-001",
        "canonical_title": "Цилиндр сцепления рабочий (РЦС) ГАЗ-3302, Соболь",
        "oem_number": clean_art("3302-1602510"),
        "cross_numbers": [clean_art(x) for x in ["33021602510", "3110-1602510", "CSC-3302", "3302-1602510-01"]],
        "brands_analogs": ["ГАЗ (Оригинал)", "Fenox", "Пекар", "Kraft", "TRIALLI"],
        "applicability": "ГАЗ-3302, Соболь 2752, ГАЗ-31105 Волга; дв. ЗМЗ-405, ЗМЗ-406, УМЗ-4216",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Сцепление",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 4. Колодки тормозные передние Next
    {
        "master_id": "GAZ-BRAKE-001",
        "canonical_title": "Колодки тормозные передние ГАЗель Next, Бизнес",
        "oem_number": clean_art("A21R23-3501170"),
        "cross_numbers": [clean_art(x) for x in ["A21R233501170", "3302-3501170-01", "BP-A21R23", "TIIR-299"]],
        "brands_analogs": ["ТИИР (Оригинал конвейер)", "Allied Nippon", "Маркон", "Kotl"],
        "applicability": "ГАЗель Next (A21R23, A21R33), ГАЗель Бизнес, Соболь Next; все типы дв.",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Тормозная система/Тормозные колодки",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 5. Сцепление комплект Cummins ISF 2.8
    {
        "master_id": "GAZ-CLUTCH-002",
        "canonical_title": "Комплект сцепления ГАЗель Бизнес, Next Cummins 2.8",
        "oem_number": clean_art("3000950503"),
        "cross_numbers": [clean_art(x) for x in ["3000 950 503", "3000950503", "201878005456", "3400700645"]],
        "brands_analogs": ["Sachs (ZF)", "Luk", "KraftTech", "HOLA"],
        "applicability": "ГАЗель Бизнес, ГАЗель Next, Соболь; двигатель Cummins ISF 2.8 дизель",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Сцепление",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 6. Крестовина кардана УАЗ Патриот
    {
        "master_id": "UAZ-DRIVE-001",
        "canonical_title": "Крестовина карданного вала УАЗ Патриот, Хантер",
        "oem_number": clean_art("3160-2201025"),
        "cross_numbers": [clean_art(x) for x in ["31602201025", "3160-2201025-01", "CR-3160", "UJ-3160"]],
        "brands_analogs": ["АДС-Эксперт", "Чернянка", "HOLA", "RedBTR", "MetalPart"],
        "applicability": "УАЗ 3163 Патриот, УАЗ Пикап, УАЗ 31519 Хантер, УАЗ 452 Буханка",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Карданные валы",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 7. Стартер редукторный ЗМЗ 405 406 409
    {
        "master_id": "GAZ-ELEC-001",
        "canonical_title": "Стартер редукторный ГАЗ, УАЗ дв. ЗМЗ 406, 405, 409",
        "oem_number": clean_art("5732.3708"),
        "cross_numbers": [clean_art(x) for x in ["57323708", "5742.3708", "5732-3708000", "5742-3708000", "406.3708000", "ST-5732", "6002.3708"]],
        "brands_analogs": ["КЗАТЭ (Самара)", "БАТЭ", "Пекар", "СтартВОЛЬТ", "Прамо"],
        "applicability": "ГАЗ-3302 ГАЗель, Волга 3110, 31105, УАЗ Патриот, Хантер; дв. ЗМЗ-406, 405, 409",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Электрооборудование/Стартеры",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 8. Свечи зажигания А17ДВРМ
    {
        "master_id": "GAZ-IGNIT-001",
        "canonical_title": "Свечи зажигания А17ДВРМ блистер 4 шт. ЗМЗ, УМЗ, ВАЗ",
        "oem_number": clean_art("А17ДВРМ"),
        "cross_numbers": [clean_art(x) for x in ["A17DVRM", "WR7DC", "LR15YC", "A17ДВРМ-10", "0242235663"]],
        "brands_analogs": ["ЭЗ (Энгельс / Bosch)", "Brisk", "NGK", "Finwhale"],
        "applicability": "ГАЗель, Волга, УАЗ, ВАЗ 2108-2115, Приора 8 кл; дв. ЗМЗ-405, 406, УМЗ-4216",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система зажигания/Свечи",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 9. Фильтр масляный дв. 406, 405, 409
    {
        "master_id": "GAZ-FILT-001",
        "canonical_title": "Фильтр масляный ГАЗ, УАЗ дв. ЗМЗ-406, 405, 409 Ливны",
        "oem_number": clean_art("406-1012005"),
        "cross_numbers": [clean_art(x) for x in ["4061012005", "2101С-1012005", "W920/21", "OF-406", "OC384"]],
        "brands_analogs": ["Автоагрегат (Ливны)", "Mann-Filter", "BIG Filter", "Невский фильтр", "SCT"],
        "applicability": "ГАЗ-3302, Соболь, Волга, УАЗ Патриот, Хантер; дв. ЗМЗ-406, 405, 409",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Масляная система/Масляные фильтры",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 10. Редуктор заднего моста ГАЗ-3302
    {
        "master_id": "GAZ-AXLE-001",
        "canonical_title": "Редуктор заднего моста ГАЗ-3302 ГП 8х41 (4.3)",
        "oem_number": clean_art("3302-2402010-10"),
        "cross_numbers": [clean_art(x) for x in ["3302240201010", "3302-2402010", "RD-3302-43"]],
        "brands_analogs": ["ГАЗ (Оригинал завод)", "Русские Узоры", "АвтоТех"],
        "applicability": "ГАЗ-3302 ГАЗель, ГАЗель Бизнес, ГАЗ-2705; задний ведущий мост",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Редукторы",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 11. КПП ГАЗ-3309 дизель 5-ступка
    {
        "master_id": "GAZ-TRANS-001",
        "canonical_title": "Коробка передач (КПП) ГАЗ-3309, 33081 дизель 5-ст",
        "oem_number": clean_art("3309-1700010"),
        "cross_numbers": [clean_art(x) for x in ["33091700010", "3309-1700010-02", "GB-3309"]],
        "brands_analogs": ["ГАЗ (Нижний Новгород)"],
        "applicability": "ГАЗ-3309, ГАЗ-33081 Садко; дизельные двигатели ММЗ Д-245.7",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Коробки передач",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 12. Вал коленчатый УМЗ-4216
    {
        "master_id": "GAZ-ENG-001",
        "canonical_title": "Вал коленчатый (коленвал) УМЗ-4216 под сальник",
        "oem_number": clean_art("4216.1005011"),
        "cross_numbers": [clean_art(x) for x in ["42161005011", "4216-1005015", "CW-4216"]],
        "brands_analogs": ["УМЗ (Ульяновск оригинал)"],
        "applicability": "ГАЗ-3302 ГАЗель Бизнес, Соболь; дв. УМЗ-4216, УМЗ-42164 Евро-3, Евро-4",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Коленвалы",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 13. Блок цилиндров ЗМЗ-405
    {
        "master_id": "GAZ-ENG-002",
        "canonical_title": "Блок цилиндров ЗМЗ-405 Евро-3 голый (d=95.5)",
        "oem_number": clean_art("40524.1002010"),
        "cross_numbers": [clean_art(x) for x in ["405241002010", "40522.1002010", "EB-405"]],
        "brands_analogs": ["ЗМЗ (Заволжский моторный завод)"],
        "applicability": "ГАЗель, Соболь, Волга 31105; дв. ЗМЗ-40524 Евро-3, ЗМЗ-40522 Евро-2",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Блоки цилиндров",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 14. Раздаточная коробка УАЗ Хантер
    {
        "master_id": "UAZ-TRANS-001",
        "canonical_title": "Раздаточная коробка УАЗ 31519 Хантер косозубая",
        "oem_number": clean_art("31519-1800020"),
        "cross_numbers": [clean_art(x) for x in ["315191800020", "31512-1800020", "TC-31519"]],
        "brands_analogs": ["УАЗ (Ульяновск)"],
        "applicability": "УАЗ 31519 Хантер, УАЗ 469, 3151; мелкомодульная косозубая РК",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Раздаточные коробки",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 15. Балка передней подвески Соболь
    {
        "master_id": "GAZ-SUSP-001",
        "canonical_title": "Балка передней подвески Соболь 2752, 2217 голая",
        "oem_number": clean_art("2752-2904012"),
        "cross_numbers": [clean_art(x) for x in ["27522904012", "2752-2904010"]],
        "brands_analogs": ["ГАЗ (Нижний Новгород)"],
        "applicability": "ГАЗ-2752, 2217 Соболь, Баргузин (задний привод 4х2)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Балки и подрамники",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 16. Рессора задняя ГАЗ-3302
    {
        "master_id": "GAZ-SUSP-002",
        "canonical_title": "Рессора задняя ГАЗ-3302 5-листовая усиленная",
        "oem_number": clean_art("3302-2912010-02"),
        "cross_numbers": [clean_art(x) for x in ["3302291201002", "3302-2912010", "LS-3302-5L"]],
        "brands_analogs": ["Чусовской металлургический завод (ЧМЗ)", "Белорецк"],
        "applicability": "ГАЗ-3302 ГАЗель, ГАЗель Бизнес, ГАЗель Next борт",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Рессоры",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 17. Картер сцепления УАЗ дв. 409 Патриот (колокол)
    {
        "master_id": "UAZ-CLUTCH-001",
        "canonical_title": "Картер сцепления (колокол) УАЗ Патриот дв. ЗМЗ-409",
        "oem_number": clean_art("409.1601015"),
        "cross_numbers": [clean_art(x) for x in ["4091601015", "409-1601015-10", "BH-409"]],
        "brands_analogs": ["ЗМЗ", "УАЗ"],
        "applicability": "УАЗ Патриот, УАЗ Хантер, УАЗ Профи; дв. ЗМЗ-409 под КПП Dymos / АДС",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Сцепление",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 18. Дверь передняя левая ГАЗель Бизнес
    {
        "master_id": "GAZ-BODY-001",
        "canonical_title": "Дверь передняя левая ГАЗель Бизнес катафорез",
        "oem_number": clean_art("3302-6100015"),
        "cross_numbers": [clean_art(x) for x in ["33026100015", "3302-6100015-10"]],
        "brands_analogs": ["ГАЗ (Заводской катафорезный грунт)"],
        "applicability": "ГАЗ-3302, 2705, 3221 ГАЗель Бизнес, Соболь 2752",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Кузов/Двери",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 19. Фонарь задний светодиодный Next
    {
        "master_id": "GAZ-LIGHT-001",
        "canonical_title": "Фонарь задний светодиодный ГАЗель Next борт",
        "oem_number": clean_art("A21R23-3716010"),
        "cross_numbers": [clean_art(x) for x in ["A21R233716010", "A21R23.3716010", "RL-A21R23"]],
        "brands_analogs": ["Руденск (Беларусь)", "Освар", "Формула Света"],
        "applicability": "ГАЗель Next борт, ГАЗон Next, каркас бортовой платформы",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Автосвет/Фонари",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 20. Генератор Cummins ISF 2.8 140A
    {
        "master_id": "GAZ-ELEC-002",
        "canonical_title": "Генератор ГАЗель Next, Бизнес Cummins 2.8 (140A)",
        "oem_number": clean_art("5263795"),
        "cross_numbers": [clean_art(x) for x in ["5263795", "4990782", "JFZ2805", "LG 0328", "A004TU5081"]],
        "brands_analogs": ["Cummins", "Luzar", "СтартВОЛЬТ", "Krauf"],
        "applicability": "ГАЗель Бизнес, ГАЗель Next, Соболь; двигатель Cummins ISF 2.8",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Электрооборудование/Генераторы",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 21. Амортизатор СААЗ 3302
    {
        "master_id": "GAZ-SUSP-003",
        "canonical_title": "Амортизатор передний ГАЗ-3302 масляный СААЗ",
        "oem_number": clean_art("3302-2905006"),
        "cross_numbers": [clean_art(x) for x in ["33022905006", "3302-2905004", "SA-3302", "SH-3302"]],
        "brands_analogs": ["СААЗ (Скопин)", "Белмаг", "HOLA", "Fenox"],
        "applicability": "ГАЗ-3302, 2705 ГАЗель, ГАЗель Бизнес передняя подвеска",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Амортизаторы",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 22. Помпа ЗМЗ 405 406 с электромагнитной муфтой
    {
        "master_id": "GAZ-COOL-002",
        "canonical_title": "Насос водяной (помпа) ЗМЗ-405, 406 с эл/муфтой",
        "oem_number": clean_art("40624-1307010-10"),
        "cross_numbers": [clean_art(x) for x in ["40624130701010", "40624.1307010", "LWP 0306", "WP-40624"]],
        "brands_analogs": ["ЗМЗ", "Пекар", "Luzar", "Tza"],
        "applicability": "ГАЗель, Соболь, Волга; дв. ЗМЗ-40524, 40522, 406 с электромуфтой",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система охлаждения/Помпы",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 23. Тяга рулевая Соболь
    {
        "master_id": "GAZ-STEER-002",
        "canonical_title": "Тяга рулевая продольная ГАЗ-2217 Соболь",
        "oem_number": clean_art("2217-3414010"),
        "cross_numbers": [clean_art(x) for x in ["22173414010", "TR-2217", "2217-3414050"]],
        "brands_analogs": ["ГАЗ (Оригинал)", "Белмаг", "Трек"],
        "applicability": "ГАЗ-2217, 2752 Соболь, Баргузин",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Рулевое управление/Тяги и наконечники",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 24. Диск сцепления ведомый УАЗ Патриот 409
    {
        "master_id": "UAZ-CLUTCH-002",
        "canonical_title": "Диск сцепления ведомый УАЗ Патриот дв. ЗМЗ-409",
        "oem_number": clean_art("3160-1601130"),
        "cross_numbers": [clean_art(x) for x in ["31601601130", "3160-1601130-10", "CD-3160", "1878002205"]],
        "brands_analogs": ["ЗМЗ", "УАЗ", "Sachs", "TRIALLI", "Luk"],
        "applicability": "УАЗ 3163 Патриот, УАЗ Хантер, УАЗ Карго; дв. ЗМЗ-409",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Сцепление",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 25. Термостат 82С УМЗ-4216, Evotech
    {
        "master_id": "GAZ-COOL-003",
        "canonical_title": "Термостат 82С УМЗ-4216, Evotech 2.7 ПРАМО",
        "oem_number": clean_art("ТА107-1306100-04"),
        "cross_numbers": [clean_art(x) for x in ["ТА107130610004", "107-1306100", "LT 0321", "TH-107-82"]],
        "brands_analogs": ["Прамо (Элтра)", "Luzar", "Пекар", "Metal-Incar"],
        "applicability": "ГАЗель Бизнес, Next; дв. УМЗ-4216, Evotech 2.7 (A274, A275)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система охлаждения/Термостаты",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 26. Датчик коленвала Bosch
    {
        "master_id": "GAZ-SENS-001",
        "canonical_title": "Датчик положения коленвала (ДПКВ) ЗМЗ 406/405/409 Bosch",
        "oem_number": clean_art("0261210302"),
        "cross_numbers": [clean_art(x) for x in ["0 261 210 302", "0261210302", "406.3847050", "23.3847"]],
        "brands_analogs": ["Bosch", "Автотрейд (Калуга)", "Пекар", "СОАТЭ"],
        "applicability": "ГАЗель, Соболь, Волга, УАЗ Патриот; дв. ЗМЗ-406, 405, 409",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Электрооборудование/Датчики",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 27. Модуль зажигания 4216 СОАТЭ
    {
        "master_id": "GAZ-IGNIT-002",
        "canonical_title": "Модуль катушка зажигания дв. УМЗ-4216 Евро-3 СОАТЭ",
        "oem_number": clean_art("48.3705"),
        "cross_numbers": [clean_art(x) for x in ["483705", "48.3705000", "IC-483705", "4216.3705010"]],
        "brands_analogs": ["СОАТЭ (Старый Оскол)", "Пекар", "Север", "HOLA"],
        "applicability": "ГАЗ-3302 ГАЗель Бизнес, Соболь; дв. УМЗ-4216 Евро-3",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система зажигания/Катушки",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 28. Глушитель основной 3302 Евро-3
    {
        "master_id": "GAZ-EXH-001",
        "canonical_title": "Глушитель основной ГАЗ-3302 Евро-3 закатной",
        "oem_number": clean_art("3302-1201008-20"),
        "cross_numbers": [clean_art(x) for x in ["3302120100820", "3302-1201008", "MUF-3302-E3"]],
        "brands_analogs": ["Арзамасский завод глушителей", "Фобос", "CBD", "Экрис"],
        "applicability": "ГАЗ-3302, 33023 ГАЗель Бизнес удлиненная база; Евро-3, Евро-4",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Выхлопная система/Глушители",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 29. Бензонасос модуль погружной Утёс
    {
        "master_id": "GAZ-FUEL-001",
        "canonical_title": "Бензонасос модуль погружной ГАЗель Бизнес дв. 4216",
        "oem_number": clean_art("9П2.960.035"),
        "cross_numbers": [clean_art(x) for x in ["9П2960035", "9P2.960.035", "9P2960035", "FP-4216-UTES"]],
        "brands_analogs": ["Утёс (Ульяновск)", "СОАТЭ", "Bosch", "Пекар"],
        "applicability": "ГАЗ-3302 ГАЗель Бизнес; инжекторные дв. УМЗ-4216",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Топливная система/Топливные насосы",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 30. Подвесной подшипник 3302 Бизнес
    {
        "master_id": "GAZ-DRIVE-002",
        "canonical_title": "Опора промежуточная (подвесной) ГАЗель Бизнес в сб.",
        "oem_number": clean_art("3302-2201090-01"),
        "cross_numbers": [clean_art(x) for x in ["3302220109001", "3302-2201090", "CB-3302", "53-2201090"]],
        "brands_analogs": ["ГАЗ (Оригинал)", "БРТ (Балаково)", "Белмаг", "HOLA"],
        "applicability": "ГАЗ-3302, 2705 ГАЗель Бизнес; карданный вал с промежуточной опорой",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Трансмиссия и привод/Подшипники",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 31. Комплект силиконовых патрубков 4216
    {
        "master_id": "GAZ-COOL-004",
        "canonical_title": "Патрубки радиатора силикон синий ГАЗель Бизнес 4216",
        "oem_number": clean_art("3302-1303000-СИЛ"),
        "cross_numbers": [clean_art(x) for x in ["33021303000СИЛ", "3302-1303010", "SIL-3302-4216"]],
        "brands_analogs": ["Хорт Силикон", "Salers", "CS-20", "БРТ"],
        "applicability": "ГАЗ-3302 ГАЗель Бизнес; двигатель УМЗ-4216",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система охлаждения/Патрубки",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 32. Шкворень комплект ГАЗель Бизнес
    {
        "master_id": "GAZ-SUSP-004",
        "canonical_title": "Комплект шкворней с подшипниками ГАЗель Бизнес",
        "oem_number": clean_art("3302-3000100"),
        "cross_numbers": [clean_art(x) for x in ["33023000100", "KP-3302-BRG", "3302-3001019"]],
        "brands_analogs": ["ГАЗ (Нижний Новгород)", "Белмаг", "Чернянка", "Трек"],
        "applicability": "ГАЗ-3302, 2705 ГАЗель, ГАЗель Бизнес передняя ось",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Ремкомплекты",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 33. Главный тормозной цилиндр Bosch
    {
        "master_id": "GAZ-BRAKE-002",
        "canonical_title": "Цилиндр тормозной главный (ГТЦ) ГАЗель Бизнес Bosch",
        "oem_number": clean_art("0204123730"),
        "cross_numbers": [clean_art(x) for x in ["0 204 123 730", "0204123730", "3302-3505010-BOSCH"]],
        "brands_analogs": ["Bosch (Оригинал конвейер)"],
        "applicability": "ГАЗель Бизнес (с вакуумным усилителем Bosch)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Тормозная система/Главные цилиндры",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 34. Ступица передняя в сборе 3302
    {
        "master_id": "GAZ-SUSP-005",
        "canonical_title": "Ступица колеса передняя ГАЗ-3302 в сборе",
        "oem_number": clean_art("3302-3103015"),
        "cross_numbers": [clean_art(x) for x in ["33023103015", "3302-3103012", "HUB-3302-F"]],
        "brands_analogs": ["ГАЗ (Оригинал завод)", "АвтоТех", "Красная Этна"],
        "applicability": "ГАЗ-3302, 2705 ГАЗель Бизнес; передняя ось",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Ступицы",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 35. Зеркало боковое левое ГАЗель Бизнес
    {
        "master_id": "GAZ-BODY-002",
        "canonical_title": "Зеркало боковое левое ГАЗель Бизнес с обогревом",
        "oem_number": clean_art("3302-8201021"),
        "cross_numbers": [clean_art(x) for x in ["33028201021", "3302-8201051", "MR-3302-L"]],
        "brands_analogs": ["Автокомпонент", "Политех", "Салют"],
        "applicability": "ГАЗ-3302, Соболь 2752 ГАЗель Бизнес; левая сторона",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Кузов/Зеркала",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 36. Трос ручника длинный 3302
    {
        "master_id": "GAZ-BRAKE-003",
        "canonical_title": "Трос стояночного тормоза задний длинный ГАЗ-3302",
        "oem_number": clean_art("3302-3508180"),
        "cross_numbers": [clean_art(x) for x in ["33023508180", "3302-3508068", "HBC-3302-L"]],
        "brands_analogs": ["Автопартнер (Димитровград)", "Тросики.ру", "Белмаг"],
        "applicability": "ГАЗ-3302 ГАЗель стандартная и удлиненная база",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Тормозная система/Тросы ручника",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 37. Форсунка топливная Siemens DEKA
    {
        "master_id": "GAZ-FUEL-002",
        "canonical_title": "Форсунка топливная инжектор ЗМЗ-405, 409 Siemens",
        "oem_number": clean_art("ZMZ6354"),
        "cross_numbers": [clean_art(x) for x in ["ZMZ 6354", "ZMZ6354", "406.1132010", "A2C53099415"]],
        "brands_analogs": ["Siemens DEKA", "Continental", "Bosch", "СОАТЭ"],
        "applicability": "ГАЗель, Волга, УАЗ Патриот; дв. ЗМЗ-40522, ЗМЗ-409 Евро-2, Евро-3",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Топливная система/Форсунки",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 38. Прокладка ГБЦ ЗМЗ-405 Евро-3 металл
    {
        "master_id": "GAZ-ENG-003",
        "canonical_title": "Прокладка ГБЦ металлопакет ЗМЗ-405 Евро-3 (d=95.5)",
        "oem_number": clean_art("40524.1003020"),
        "cross_numbers": [clean_art(x) for x in ["405241003020", "405.1003020", "HG-40524"]],
        "brands_analogs": ["БРТ (Балаково)", "Фритекс", "ВАТИ", "Espra"],
        "applicability": "ГАЗель, Соболь, Волга 31105; дв. ЗМЗ-40524 Евро-3, Евро-4",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Прокладки ГБЦ",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 39. Катушка зажигания Next Evotech 2.7
    {
        "master_id": "GAZ-IGNIT-003",
        "canonical_title": "Катушка зажигания индивидуальная ГАЗель Next Evotech",
        "oem_number": clean_art("2112-3705010-13"),
        "cross_numbers": [clean_art(x) for x in ["2112370501013", "2112-3705010", "0221504473", "IC-2112"]],
        "brands_analogs": ["СОАТЭ", "Bosch", "ИТЭЛМА", "Север"],
        "applicability": "ГАЗель Next, Бизнес; дв. УМЗ Evotech 2.7 (A274), ВАЗ 16V",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Система зажигания/Катушки",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 40. Втулка рессоры полиуретан 3302
    {
        "master_id": "GAZ-SUSP-006",
        "canonical_title": "Втулки рессоры полиуретан ГАЗ-3302 комплект 12 шт.",
        "oem_number": clean_art("3302-2912028-ПУ"),
        "cross_numbers": [clean_art(x) for x in ["33022912028ПУ", "3302-2912028", "PU-3302-12"]],
        "brands_analogs": ["Полиуретан.ру", "Точка Опоры", "Фортуна", "БРТ"],
        "applicability": "ГАЗ-3302 ГАЗель, ГАЗель Бизнес, Соболь передние и задние рессоры",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Подвеска/Сайлентблоки и втулки",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 41. Ремень поликлиновой 6PK 1370
    {
        "master_id": "GAZ-ENG-004",
        "canonical_title": "Ремень генератора поликлиновой 6PK 1370 УМЗ-4216 с ГУР",
        "oem_number": clean_art("6PK1370"),
        "cross_numbers": [clean_art(x) for x in ["6PK 1370", "6PK1370", "4216-1308020", "Gates 6PK1368"]],
        "brands_analogs": ["Gates", "ContiTech", "БРТ", "LynxAuto", "Dayco"],
        "applicability": "ГАЗель Бизнес; двигатель УМЗ-4216 с гидроусилителем руля (ГУР)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Ремни приводные",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 42. Наконечник рулевой правый 3302
    {
        "master_id": "GAZ-STEER-003",
        "canonical_title": "Наконечник рулевой тяги правый ГАЗ-3302 ГАЗель",
        "oem_number": clean_art("3302-3414056"),
        "cross_numbers": [clean_art(x) for x in ["33023414056", "3302-3414056-01", "TRE-3302-R"]],
        "brands_analogs": ["Белмаг", "ГАЗ", "Трек Мастер", "HOLA"],
        "applicability": "ГАЗ-3302, 2705 ГАЗель, ГАЗель Бизнес рулевая трапеция",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Рулевое управление/Тяги и наконечники",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    },
    # 43. Ремкомплект ГРМ Евро-3 БОН
    {
        "master_id": "GAZ-ENG-005",
        "canonical_title": "Комплект ГРМ Евро-3 ЗМЗ 405, 406, 409 с башмаками БОН",
        "oem_number": clean_art("406.1006040-БОН"),
        "cross_numbers": [clean_art(x) for x in ["4061006040БОН", "406-1006040", "TC-ZMZ-BON", "40624-1006040"]],
        "brands_analogs": ["БОН (Челябинск)", "Прогресс", "ЗМЗ Золотая серия", "Русмаш"],
        "applicability": "ГАЗель, Соболь, УАЗ Патриот; дв. ЗМЗ-405, 406, 409 Евро-3 (цепи 70/90 звеньев)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Ремкомплекты ГРМ",
        "image_urls": ["https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80"]
    },
    # 44. Прокладка клапанной крышки 406 405 силикон
    {
        "master_id": "GAZ-ENG-006",
        "canonical_title": "Прокладка клапанной крышки ЗМЗ 406, 405 силикон",
        "oem_number": clean_art("406-1007245-СИЛ"),
        "cross_numbers": [clean_art(x) for x in ["4061007245СИЛ", "406-1007245", "406-1007245-01", "VCG-406"]],
        "brands_analogs": ["CS-20", "Хорт", "БРТ", "ВАТИ"],
        "applicability": "ГАЗель, Соболь, Волга, УАЗ; дв. ЗМЗ-406, 405 (алюминиевая крышка)",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Двигатель/Прокладки двигателя",
        "image_urls": ["https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80"]
    },
    # 45. Фильтр топливный Ливны
    {
        "master_id": "GAZ-FILT-002",
        "canonical_title": "Фильтр топливный тонкой очистки ГАЗ под штуцер",
        "oem_number": clean_art("3110-1117010"),
        "cross_numbers": [clean_art(x) for x in ["31101117010", "3110-1117010-01", "WK 512", "FF-3110"]],
        "brands_analogs": ["Автоагрегат (Ливны)", "BIG Filter", "Mann", "Невский фильтр"],
        "applicability": "ГАЗ-3110 Волга, ГАЗ-3302 ГАЗель инжектор; штуцерное соединение",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Топливная система/Топливные фильтры",
        "image_urls": ["https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80"]
    },
    # 46. Датчик положения дросселя ДПДЗ 406 Рикор
    {
        "master_id": "GAZ-SENS-002",
        "canonical_title": "Датчик положения дроссельной заслонки (ДПДЗ) ЗМЗ-406 Рикор",
        "oem_number": clean_art("406.1130000-01"),
        "cross_numbers": [clean_art(x) for x in ["406113000001", "406-1130000", "0280122001", "TPS-406"]],
        "brands_analogs": ["Рикор Электроникс", "Bosch", "Автотрейд", "Пекар"],
        "applicability": "ГАЗель, Волга, УАЗ; инжекторные двигатели ЗМЗ-406, 405, 409",
        "avito_category": "Запчасти и аксессуары/Запчасти/Для автомобилей/Электрооборудование/Датчики",
        "image_urls": ["https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=800&q=80"]
    }
]


OEM_DISPLAY_MAPPING = {
    "GAZ-STEER-001": "ШНКФ 453471.125",
    "GAZ-COOL-001": "3302-1301010-33",
    "GAZ-CLUTCH-001": "3302-1602510",
    "GAZ-BRAKE-001": "A21R23-3501170",
    "GAZ-CLUTCH-002": "3000 950 503",
    "UAZ-DRIVE-001": "3160-2201025",
    "GAZ-ELEC-001": "5732.3708",
    "GAZ-IGNIT-001": "А17ДВРМ",
    "GAZ-FILT-001": "406-1012005",
    "GAZ-AXLE-001": "3302-2402010-10",
    "GAZ-TRANS-001": "3309-1700010",
    "GAZ-ENG-001": "4216.1005011",
    "GAZ-ENG-002": "40524.1002010",
    "UAZ-TRANS-001": "31519-1800020",
    "GAZ-SUSP-001": "2752-2904012",
    "GAZ-SUSP-002": "3302-2912010-02",
    "UAZ-CLUTCH-001": "409.1601015",
    "GAZ-BODY-001": "3302-6100015",
    "GAZ-LIGHT-001": "A21R23-3716010",
    "GAZ-ELEC-002": "5263795",
    "GAZ-SUSP-003": "3302-2905006",
    "GAZ-COOL-002": "40624-1307010-10",
    "GAZ-STEER-002": "2217-3414010",
    "UAZ-CLUTCH-002": "3160-1601130",
    "GAZ-COOL-003": "ТА107-1306100-04",
    "GAZ-SENS-001": "0261210302",
    "GAZ-IGNIT-002": "48.3705",
    "GAZ-EXH-001": "3302-1201008-20",
    "GAZ-FUEL-001": "9П2.960.035",
    "GAZ-DRIVE-002": "3302-2201090-01",
    "GAZ-COOL-004": "3302-1303000-СИЛ",
    "GAZ-SUSP-004": "3302-3000100",
    "GAZ-BRAKE-002": "0204123730",
    "GAZ-SUSP-005": "3302-3103015",
    "GAZ-BODY-002": "3302-8201021",
    "GAZ-BRAKE-003": "3302-3508180",
    "GAZ-FUEL-002": "ZMZ 6354",
    "GAZ-ENG-003": "40524.1003020",
    "GAZ-IGNIT-003": "2112-3705010-13",
    "GAZ-SUSP-006": "3302-2912028-ПУ",
    "GAZ-ENG-004": "6PK 1370",
    "GAZ-STEER-003": "3302-3414056",
    "GAZ-ENG-005": "406.1006040-БОН",
    "GAZ-ENG-006": "406-1007245-СИЛ",
    "GAZ-FILT-002": "3110-1117010",
    "GAZ-SENS-002": "406.1130000-01"
}


def init_database(db_path: str = None):
    """Инициализирует таблицы базы данных master_catalog.db"""
    if db_path is None:
        db_path = DB_PATH
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 1. Справочник master_catalog
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS master_catalog (
        master_id TEXT PRIMARY KEY,
        canonical_title TEXT NOT NULL,
        oem_display TEXT NOT NULL DEFAULT '',
        oem_number TEXT NOT NULL,
        cross_numbers TEXT NOT NULL,
        brands_analogs TEXT NOT NULL,
        applicability TEXT NOT NULL,
        avito_category TEXT NOT NULL,
        image_urls TEXT NOT NULL
    );
    """)

    cols = [col[1] for col in cursor.execute("PRAGMA table_info(master_catalog)").fetchall()]
    if "oem_display" not in cols:
        cursor.execute("ALTER TABLE master_catalog ADD COLUMN oem_display TEXT DEFAULT '';")

    # Индексы для сверхбыстрого детерминированного поиска
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_master_oem ON master_catalog(oem_number);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_master_oem_disp ON master_catalog(oem_display);")

    # 2. Таблица кэширования связей выгрузок 1С с эталонной базой
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS client_sku_mapping (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id TEXT NOT NULL,
        raw_code TEXT NOT NULL,
        raw_name TEXT NOT NULL,
        clean_article TEXT,
        master_id TEXT,
        match_stage TEXT NOT NULL,
        confidence_score REAL NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(client_id, raw_code)
    );
    """)

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_mapping_client_code ON client_sku_mapping(client_id, raw_code);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_mapping_stage ON client_sku_mapping(match_stage);")

    # 3. Таблица оперативных резервов
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reservations (
        res_id TEXT PRIMARY KEY,
        created_at TEXT NOT NULL,
        client_name TEXT NOT NULL,
        client_phone TEXT NOT NULL,
        master_id TEXT NOT NULL,
        canonical_title TEXT NOT NULL,
        source_1c_codes TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 1,
        price_retail REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'CONFIRMED'
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_res_status ON reservations(status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_res_master ON reservations(master_id);")

    # Наполнение эталонными карточками
    for rec in MASTER_RECORDS:
        mid = rec["master_id"]
        oem_disp = rec.get("oem_display") or OEM_DISPLAY_MAPPING.get(mid, rec["oem_number"])
        cursor.execute("""
        INSERT OR REPLACE INTO master_catalog 
        (master_id, canonical_title, oem_display, oem_number, cross_numbers, brands_analogs, applicability, avito_category, image_urls)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            rec["master_id"],
            rec["canonical_title"],
            oem_disp,
            rec["oem_number"],
            json.dumps(rec["cross_numbers"], ensure_ascii=False),
            json.dumps(rec["brands_analogs"], ensure_ascii=False),
            rec["applicability"],
            rec["avito_category"],
            json.dumps(rec["image_urls"], ensure_ascii=False)
        ))

    conn.commit()
    count = cursor.execute("SELECT COUNT(*) FROM master_catalog").fetchone()[0]
    conn.close()

    print(f"✅ База данных '{db_path}' успешно инициализирована.")
    print(f"📊 Загружено эталонных карточек в master_catalog: {count} шт.")
    return db_path


if __name__ == "__main__":
    init_database()
