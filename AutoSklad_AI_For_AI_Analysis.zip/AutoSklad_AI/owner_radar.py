"""
МОДУЛЬ 5: ЕЖЕНЕДЕЛЬНЫЙ «РАДАР СОБСТВЕННИКА» (owner_radar.py)
Платформа «АВТОСКЛАД-ИИ» для владельца сети магазинов ГАЗ / УАЗ Вячеслава Юрьевича.

Реальный динамический расчет бизнес-метрик:
1. Разморозка неликвида через маркетплейсы (delta < 0 по позициям без движения >= 180 дней).
2. Детектор анти-отката и ошибок закупщика (delta > 0 по дублям или при избыточном запасе > 4 мес).
3. Критичный дефицит ходовых позиций (падение остатка до 0 при регулярных продажах).
4. Ночные брони ИИ-продавца (агрегация из базы SQLite reservations).
"""

import os
import json
import sqlite3
import datetime
import math
from pathlib import Path
from typing import Dict, List, Any, Optional
import pandas as pd
from config import (
    DB_PATH,
    WEEK_PREV_PATH as PREV_PATH,
    WEEK_CURR_PATH as CURR_PATH,
    OWNER_NAME,
    STORE_PHONE as SUPPORT_PHONE,
    DEAD_STOCK_DAYS_THRESHOLD
)
from inventory_guard import detect_and_read_1c_file, parse_1c_number


class OwnerRadar:
    def __init__(self, prev_path: str = PREV_PATH, curr_path: str = CURR_PATH, db_path: str = DB_PATH):
        self.prev_path = prev_path
        self.curr_path = curr_path
        self.db_path = db_path
        self.master_records: Dict[str, Dict[str, Any]] = {}
        self.mappings: Dict[str, str] = {}
        self.load_metadata()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=30000;")
        conn.row_factory = sqlite3.Row
        return conn

    def load_metadata(self) -> None:
        """Загружает master_catalog и связи client_sku_mapping."""
        conn = self.get_connection()
        c = conn.cursor()

        try:
            for r in c.execute("SELECT * FROM master_catalog").fetchall():
                cols = r.keys()
                oem_disp = r["oem_display"] if "oem_display" in cols and r["oem_display"] else r["oem_number"]
                self.master_records[r["master_id"]] = {
                    "master_id": r["master_id"],
                    "canonical_title": r["canonical_title"],
                    "oem_number": oem_disp,
                    "cross_numbers": json.loads(r["cross_numbers"]) if r["cross_numbers"] else [],
                    "applicability": r["applicability"]
                }
        except Exception:
            pass

        try:
            for r in c.execute("SELECT raw_code, master_id FROM client_sku_mapping").fetchall():
                self.mappings[str(r["raw_code"]).strip()] = r["master_id"]
        except Exception:
            pass

        conn.close()

    def analyze_weekly_shifts(self) -> Dict[str, Any]:
        """
        Динамический расчет дельт между срезами двух недель:
        - Разморозка неликвида: delta < 0 и (days_no_movement >= 180 или sales_12m == 0)
        - Анти-откат / перезакуп: delta > 0 при наличии остатка по дублям или запасе > 4 мес
        - Новый дефицит: stock_prev > 0, stock_curr == 0 и среднемесячные продажи >= 3 шт.
        - Ночные брони: реальные записи из таблицы reservations
        """
        df_prev, _ = detect_and_read_1c_file(self.prev_path)
        df_curr, _ = detect_and_read_1c_file(self.curr_path)

        # Стандартизируем названия колонок для корректного слияния
        for d in [df_prev, df_curr]:
            if "raw_code" in d.columns and "Код" not in d.columns:
                d["Код"] = d["raw_code"]
            if "raw_name" in d.columns and "Наименование" not in d.columns:
                d["Наименование"] = d["raw_name"]
            if "raw_article" in d.columns and "Артикул" not in d.columns:
                d["Артикул"] = d["raw_article"]
            if "stock_qty" in d.columns and "Остаток" not in d.columns:
                d["Остаток"] = d["stock_qty"]
            if "price_retail" in d.columns and "ЦенаРозница" not in d.columns:
                d["ЦенаРозница"] = d["price_retail"]
            if "price_cost" in d.columns and "ЦенаЗакупки" not in d.columns:
                d["ЦенаЗакупки"] = d["price_cost"]
            if "sales_12m" in d.columns and "Продажи12мес" not in d.columns:
                d["Продажи12мес"] = d["sales_12m"]
            if "days_no_movement" in d.columns and "ДнейБезДвижения" not in d.columns:
                d["ДнейБезДвижения"] = d["days_no_movement"]

        # Защита от дублей строк в выгрузках 1С: дедупликация по Коду перед слиянием
        if "Код" in df_prev.columns:
            df_prev = df_prev.groupby("Код", as_index=False).first()
        if "Код" in df_curr.columns:
            df_curr = df_curr.groupby("Код", as_index=False).first()

        # Outer join с безопасной обработкой появившихся и исчезнувших SKU
        merged = pd.merge(
            df_prev[["Код", "Наименование", "Артикул", "Остаток", "ЦенаРозница", "ЦенаЗакупки", "Продажи12мес", "ДнейБезДвижения"]],
            df_curr[["Код", "Остаток"]],
            on="Код",
            how="outer",
            suffixes=("_prev", "_curr")
        )
        merged["Остаток_prev"] = merged["Остаток_prev"].fillna(0.0)
        merged["Остаток_curr"] = merged["Остаток_curr"].fillna(0.0)
        merged["Наименование"] = merged["Наименование"].fillna("Новая позиция")
        merged["Артикул"] = merged["Артикул"].fillna("")
        merged["ЦенаЗакупки"] = merged["ЦенаЗакупки"].fillna(0.0)

        # Fallback для цены розницы: если розничная цена отсутствует или <= 0, берем себестоимость * 1.25
        merged["ЦенаРозница"] = merged["ЦенаРозница"].fillna(0.0)
        mask_zero_retail = (merged["ЦенаРозница"] <= 0) & (merged["ЦенаЗакупки"] > 0)
        merged.loc[mask_zero_retail, "ЦенаРозница"] = merged.loc[mask_zero_retail, "ЦенаЗакупки"] * 1.25

        # Защита от возвратов клиентов (sales_12m < 0): заменяем отрицательный расход на 0.0
        merged["Продажи12мес"] = merged["Продажи12мес"].fillna(0.0).apply(lambda v: max(0.0, float(v)))
        merged["ДнейБезДвижения"] = merged["ДнейБезДвижения"].fillna(0)
        merged["delta"] = merged["Остаток_curr"] - merged["Остаток_prev"]

        # Предварительный расчет остатков по master_id в прошлой неделе для детектора дублей
        prev_stock_by_master: Dict[str, float] = {}
        for _, row in merged.iterrows():
            code = str(row["Код"]).strip()
            mid = self.mappings.get(code)
            if mid:
                prev_stock_by_master[mid] = prev_stock_by_master.get(mid, 0.0) + float(row["Остаток_prev"])

        # --- 1. РЕАЛЬНЫЙ ДИНАМИЧЕСКИЙ РАСЧЕТ РАЗМОРОЗКИ НЕЛИКВИДА (delta < 0) ---
        dead_stock_sales: List[Dict[str, Any]] = []
        total_unfrozen_rub = 0.0

        for _, row in merged.iterrows():
            delta = float(row["delta"])
            if delta >= 0:
                continue

            days = int(row["ДнейБезДвижения"])
            sales12 = float(row["Продажи12мес"])

            # Критерий неликвида: не было движения >= 180 дней ИЛИ годовые продажи равны 0
            is_dead_stock = (days >= DEAD_STOCK_DAYS_THRESHOLD) or (sales12 == 0.0 and float(row["Остаток_prev"]) > 0)
            if not is_dead_stock:
                continue

            code = str(row["Код"]).strip()
            qty_sold = abs(delta)
            price = float(row["ЦенаРозница"])
            cash = qty_sold * price
            total_unfrozen_rub += cash

            mid = self.mappings.get(code)
            m_info = self.master_records.get(mid, {})

            dead_stock_sales.append({
                "code": code,
                "name": str(row["Наименование"]),
                "canonical_title": m_info.get("canonical_title", str(row["Наименование"])),
                "oem": m_info.get("oem_number", str(row["Артикул"])),
                "days_no_movement": max(days, 180),
                "stock_prev": float(row["Остаток_prev"]),
                "stock_curr": float(row["Остаток_curr"]),
                "qty_sold": qty_sold,
                "price_retail": price,
                "cash_freed_rub": cash
            })

        dead_stock_sales.sort(key=lambda x: x["cash_freed_rub"], reverse=True)

        # --- 2. ДИНАМИЧЕСКИЙ ДЕТЕКТОР АНТИ-ОТКАТА И АНОМАЛЬНОГО ПЕРЕЗАКУПА (delta > 0) ---
        overbuy_items: List[Dict[str, Any]] = []
        total_overbuy_rub = 0.0

        for _, row in merged.iterrows():
            delta = float(row["delta"])
            if delta <= 0:
                continue

            qty_added = delta
            cost = float(row["ЦенаЗакупки"])
            if cost <= 0:
                cost = float(row["ЦенаРозница"]) / 1.25

            code = str(row["Код"]).strip()
            mid = self.mappings.get(code)
            stock_prev = float(row["Остаток_prev"])
            days = int(row["ДнейБезДвижения"])
            sales12 = float(row["Продажи12мес"])
            monthly_sales = sales12 / 12.0

            reason = None

            # Правило 1: Заказ при наличии остатка по другим дублям того же master_id
            if mid and prev_stock_by_master.get(mid, 0.0) > (stock_prev + 0.5):
                other_stock = prev_stock_by_master[mid] - stock_prev
                reason = f"Заказ по карточке 1С при наличии остатка {other_stock:.0f} шт. по другим дублям номенклатуры"
            # Правило 2: Перезакуп при избыточном складском запасе (> 4 месяцев спроса или при 0 продаж)
            elif (sales12 == 0 and stock_prev > 0) or (monthly_sales > 0 and (stock_prev / monthly_sales) > 4.0) or days >= 180:
                months_held = (stock_prev / monthly_sales) if monthly_sales > 0 else 40.0
                reason = f"Аномальный перезакуп (текущий запас без движения превышает {months_held:.0f} мес. спроса)"

            if reason:
                waste = qty_added * cost
                total_overbuy_rub += waste

                m_info = self.master_records.get(mid, {})
                overbuy_items.append({
                    "code": code,
                    "name": str(row["Наименование"]),
                    "canonical_title": m_info.get("canonical_title", str(row["Наименование"])),
                    "oem": m_info.get("oem_number", str(row["Артикул"])),
                    "stock_prev": stock_prev,
                    "stock_curr": float(row["Остаток_curr"]),
                    "qty_added": qty_added,
                    "price_purchase": cost,
                    "waste_cost_rub": waste,
                    "reason": reason
                })

        overbuy_items.sort(key=lambda x: x["waste_cost_rub"], reverse=True)

        # --- 3. ДИНАМИЧЕСКИЙ РАСЧЕТ КРИТИЧНОГО ДЕФИЦИТА (stock_prev > 0 -> stock_curr == 0) ---
        deficit_items: List[Dict[str, Any]] = []
        total_lost_revenue_monthly = 0.0

        for _, row in merged.iterrows():
            stock_prev = float(row["Остаток_prev"])
            stock_curr = float(row["Остаток_curr"])
            sales12 = float(row["Продажи12мес"])

            # Позиция выпала в 0 при стабильном спросе (>= 3 шт. в месяц)
            monthly_demand = round(sales12 / 12.0, 1)
            if stock_prev > 0 and stock_curr == 0.0 and monthly_demand >= 3.0:
                code = str(row["Код"]).strip()
                price = float(row["ЦенаРозница"])
                lost_rev = round(monthly_demand * price, 0)
                total_lost_revenue_monthly += lost_rev

                mid = self.mappings.get(code)
                m_info = self.master_records.get(mid, {})

                deficit_items.append({
                    "code": code,
                    "name": str(row["Наименование"]),
                    "canonical_title": m_info.get("canonical_title", str(row["Наименование"])),
                    "oem": m_info.get("oem_number", str(row["Артикул"])),
                    "sales_12m": sales12,
                    "monthly_demand": monthly_demand,
                    "stock_curr": 0.0,
                    "price_retail": price,
                    "monthly_lost_revenue_rub": lost_rev
                })

        deficit_items.sort(key=lambda x: x["monthly_lost_revenue_rub"], reverse=True)

        # --- 4. НОЧНЫЕ БРОНИ ИИ-БОТА (из реальной таблицы reservations) ---
        conn = self.get_connection()
        c = conn.cursor()
        res_rows = []
        try:
            res_rows = c.execute(
                "SELECT * FROM reservations WHERE status = 'CONFIRMED' ORDER BY created_at DESC"
            ).fetchall()
        except Exception:
            pass
        finally:
            conn.close()

        night_reservations: List[Dict[str, Any]] = []
        total_night_revenue = 0.0

        for r in res_rows:
            price = float(r["price_retail"]) * int(r["qty"])
            total_night_revenue += price
            night_reservations.append({
                "res_id": r["res_id"],
                "created_at": r["created_at"],
                "client_name": r["client_name"],
                "client_phone": r["client_phone"],
                "canonical_title": r["canonical_title"],
                "source_1c_codes": r["source_1c_codes"],
                "qty": int(r["qty"]),
                "price": price
            })

        net_impact = total_unfrozen_rub + total_night_revenue - total_overbuy_rub

        summary = {
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "owner_name": OWNER_NAME,
            "period": "Неделя 2 vs Неделя 1 (7 дней)",
            "metrics": {
                "unfrozen_cash_rub": total_unfrozen_rub,
                "overbuy_waste_rub": total_overbuy_rub,
                "lost_revenue_risk_rub": total_lost_revenue_monthly,
                "night_bot_revenue_rub": total_night_revenue,
                "net_financial_impact_rub": net_impact
            },
            "dead_stock_sales": dead_stock_sales,
            "overbuy_alerts": overbuy_items,
            "new_deficits": deficit_items,
            "night_reservations": night_reservations
        }

        return summary

    def generate_telegram_digest(self, summary: Dict[str, Any]) -> str:
        """Формирует форматированный еженедельный дайджест для отправки в Telegram директора."""
        m = summary["metrics"]
        lines = [
            f"📊 ЕЖЕНЕДЕЛЬНЫЙ РАДАР СОБСТВЕННИКА • АВТОСКЛАД-ИИ",
            f"👤 Для: {OWNER_NAME} ({summary['period']})",
            f"📅 Сформирован: {summary['timestamp']}",
            f"{'='*46}",
            f"💰 ФИНАНСОВЫЙ ИТОГ НЕДЕЛИ: +{m['net_financial_impact_rub']:,.0f} ₽".replace(",", " "),
            f"{'='*46}",
            f"",
            f"🟢 1. РАЗМОРОЗКА НЕЛИКВИДА ЧЕРЕЗ АВИТО/ДРОМ: +{m['unfrozen_cash_rub']:,.0f} ₽".replace(",", " "),
            f"   В кассу возвращены живые деньги по старым висякам (>180 дней):"
        ]

        for idx, item in enumerate(summary["dead_stock_sales"][:5], 1):
            lines.append(
                f"   {idx}. {item['canonical_title']} — {item['qty_sold']:.0f} шт. "
                f"(+{item['cash_freed_rub']:,.0f} ₽, висела {item['days_no_movement']} дн.)"
            )

        lines.extend([
            f"",
            f"🔴 2. ПРЕТЕНЗИИ К ЗАКУПЩИКУ (АНТИ-ОТКАТ): -{m['overbuy_waste_rub']:,.0f} ₽".replace(",", " "),
            f"   Выявлен опасный перезакуп и заказ по пустым карточкам-дублям 1С:"
        ])

        for idx, item in enumerate(summary["overbuy_alerts"][:5], 1):
            lines.append(
                f"   {idx}. {item['canonical_title']} (+{item['qty_added']:.0f} шт. на {item['waste_cost_rub']:,.0f} ₽)\n"
                f"      ⚠️ {item['reason']}"
            )

        lines.extend([
            f"",
            f"🚨 3. КРИТИЧНЫЙ ДЕФИЦИТ НЕДЕЛИ (ОСТАТОК 0 ШТ.):",
            f"   Ходовые позиции выбиты в ноль. Риск потери {m['lost_revenue_risk_rub']:,.0f} ₽ выручки в месяц:"
        ])

        for idx, item in enumerate(summary["new_deficits"][:5], 1):
            lines.append(
                f"   • {item['canonical_title']} (спрос {item['monthly_demand']:.1f} шт/мес, потери: {item['monthly_lost_revenue_rub']:,.0f} ₽/мес)"
            )

        lines.extend([
            f"",
            f"🌙 4. НОЧНАЯ КАССА ИИ-ПРОДАВЦА (ЧАТЫ АВИТО): +{m['night_bot_revenue_rub']:,.0f} ₽".replace(",", " "),
            f"   Оформлено {len(summary['night_reservations'])} броней в нерабочее время (детали отложены на кассе):"
        ])

        for r in summary["night_reservations"][:5]:
            lines.append(
                f"   • Бронь #{r['res_id']}: {r['client_name']} ({r['client_phone']}) — {r['canonical_title']} ({r['price']:,.0f} ₽)"
            )

        lines.extend([
            f"",
            f"📱 Поддержка платформы: {SUPPORT_PHONE}"
        ])

        return "\n".join(lines)

    def run_radar(self, output_dir: Optional[str] = None) -> Dict[str, Any]:
        """Запускает полный цикл анализа радара и экспортирует radar_summary.json и telegram_digest.txt."""
        from config import BASE_DIR, GITHUB_PAGES_DIR
        summary = self.analyze_weekly_shifts()
        digest = self.generate_telegram_digest(summary)

        target_dir = Path(output_dir) if output_dir else BASE_DIR
        target_dir.mkdir(parents=True, exist_ok=True)

        with open(target_dir / "radar_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        with open(target_dir / "telegram_digest.txt", "w", encoding="utf-8") as f:
            f.write(digest)

        if not output_dir and GITHUB_PAGES_DIR.exists():
            with open(GITHUB_PAGES_DIR / "radar_summary.json", "w", encoding="utf-8") as f:
                json.dump(summary, f, ensure_ascii=False, indent=2)

        return summary


if __name__ == "__main__":
    from config import BASE_DIR, GITHUB_PAGES_DIR
    radar = OwnerRadar()
    summary = radar.run_radar()
    print(radar.generate_telegram_digest(summary))
    print("\n✅ Сводка радара успешно рассчитана динамически и сохранена!")
