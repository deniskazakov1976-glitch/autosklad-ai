"""
Модуль 2: matcher.py
Платформа «АВТОСКЛАД-ИИ»
Трехкаскадный ИИ-конвейер склейки грязной номенклатуры 1С с «Золотым справочником» master_catalog:
1. Каскад 1 (0 ₽): Детерминированный поиск по чистому артикулу (OEM и кросс-номера)
2. Каскад 2 (0 ₽): Нечеткий поиск (rapidfuzz) с нормализацией автосленга
3. Каскад 3: LLM Batch Matching (DeepSeek / OpenAI) со встроенным автономным Fallback-резолвером
4. Кэширование: Таблица client_sku_mapping в SQLite для исключения повторных затрат на API
"""

import os
import sys
import re
import json
import sqlite3
import argparse
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import pandas as pd
from rapidfuzz import fuzz
from jinja2 import Template
from inventory_guard import (
    clean_article,
    AntonymGuard,
    KitGuard,
    detect_and_read_1c_file,
    parse_1c_number,
    safe_json_dumps
)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "master_catalog.db")

SLANG_SYNONYMS = {
    r"\bгур\b": "гидроусилитель руля насос",
    r"\bг/у\b": "гидроусилитель руля насос",
    r"\bрцс\b": "рабочий цилиндр сцепления",
    r"\bгцс\b": "главный цилиндр сцепления",
    r"\bгтц\b": "главный тормозной цилиндр",
    r"\bртц\b": "рабочий тормозной цилиндр",
    r"\bгбц\b": "головка блока цилиндров",
    r"\bкпп\b": "коробка передач",
    r"\bдв\b": "двигатель",
    r"\bдвс\b": "двигатель",
    r"\bэбу\b": "блок управления двигателем",
    r"\bоренбург\b": "радиатор оренбург",
    r"\bмедн\b": "медный",
    r"\bориг\b": "оригинал",
    r"\bохл\b": "охлаждения",
}

CYR_TO_LAT = {
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'К': 'K', 'М': 'M',
    'Н': 'H', 'О': 'O', 'Р': 'P', 'Т': 'T', 'Х': 'X', 'У': 'Y'
}

def clean_article(val: Any) -> str:
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip().upper()
    s = re.sub(r"[-./\s_,\\]", "", s)
    return "".join(CYR_TO_LAT.get(c, c) for c in s)

def normalize_text(text: str) -> str:
    if not text or pd.isna(text):
        return ""
    t = str(text).lower().strip()
    t = re.sub(r"[^\w\s\.-]", " ", t)
    for pattern, replacement in SLANG_SYNONYMS.items():
        t = re.sub(pattern, replacement, t)
    return re.sub(r"\s+", " ", t).strip()


class CatalogMatcher:
    def __init__(self, db_path: str = DB_PATH, client_id: str = "client_default"):
        self.db_path = db_path
        self.client_id = client_id
        self.master_records: List[Dict[str, Any]] = []
        self.oem_index: Dict[str, Dict[str, Any]] = {}
        self.cross_index: Dict[str, Dict[str, Any]] = {}
        self.load_master_catalog()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=30000;")
        return conn

    def load_master_catalog(self) -> None:
        """Загружает эталонные карточки из SQLite и строит хэш-индексы для O(1) поиска с симметричной нормализацией clean_article()."""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        rows = cursor.execute("SELECT * FROM master_catalog").fetchall()
        conn.close()

        for r in rows:
            rec = {
                "master_id": r["master_id"],
                "canonical_title": r["canonical_title"],
                "oem_number": r["oem_number"],
                "cross_numbers": json.loads(r["cross_numbers"]),
                "brands_analogs": json.loads(r["brands_analogs"]),
                "applicability": r["applicability"],
                "avito_category": r["avito_category"],
                "image_urls": json.loads(r["image_urls"]),
            }
            rec["search_corpus"] = normalize_text(f"{rec['canonical_title']} {rec['applicability']}")
            self.master_records.append(rec)

            # Индекс по OEM (симметрично нормализуем clean_article)
            clean_oem = clean_article(rec["oem_number"])
            if clean_oem:
                self.oem_index[clean_oem] = rec

            # Индекс по Кроссам (симметрично нормализуем clean_article)
            for cr in rec["cross_numbers"]:
                clean_cr = clean_article(cr)
                if clean_cr and clean_cr not in self.cross_index:
                    self.cross_index[clean_cr] = rec

    def get_cached_mappings(self) -> Dict[str, Dict[str, Any]]:
        """Извлекает уже существующие привязки клиента из базы данных SQLite."""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM client_sku_mapping WHERE client_id = ?", (self.client_id,))
        rows = cursor.fetchall()
        conn.close()
        return {r["raw_code"]: dict(r) for r in rows}

    def save_mappings_batch(self, mappings: List[Dict[str, Any]]) -> None:
        """Сохраняет батч сопоставлений в SQLite client_sku_mapping."""
        if not mappings:
            return
        conn = self.get_connection()
        cursor = conn.cursor()
        now_str = datetime.now().isoformat()

        cursor.executemany("""
        INSERT OR REPLACE INTO client_sku_mapping
        (client_id, raw_code, raw_name, clean_article, master_id, match_stage, confidence_score, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            (
                self.client_id,
                m["raw_code"],
                m["raw_name"],
                m["clean_article"],
                m["master_id"],
                m["match_stage"],
                m["confidence_score"],
                now_str
            )
            for m in mappings
        ])
        conn.commit()
        conn.close()

    def cascade_1_exact(self, clean_art: str) -> Optional[Tuple[Dict[str, Any], str, float]]:
        """Каскад 1: 0 ₽ — Детерминированное сопоставление по OEM и массиву кроссов."""
        if not clean_art:
            return None

        # 1.1 Точное совпадение с OEM
        if clean_art in self.oem_index:
            return self.oem_index[clean_art], "EXACT_OEM", 1.0

        # 1.2 Точное совпадение с любым из кросс-номеров
        if clean_art in self.cross_index:
            return self.cross_index[clean_art], "CROSS_NUMBER", 1.0

        return None

    def cascade_2_fuzzy(self, norm_name: str, raw_name: str = "") -> Tuple[Optional[Tuple[Dict[str, Any], str, float]], List[Tuple[Dict[str, Any], float]]]:
        """
        Каскад 2: 0 ₽ — Нечеткий поиск по наименованию и автосленгу с Antonym Guard.
        - Если score >= 88.0 и нет конфликта по стороне/оси/размерам/моторам -> автоматическая привязка (FUZZY_NAME)
        - Если score от 55.0 до 87.0 -> сбор ТОП-5 кандидатов для Каскада 3
        """
        scored_candidates = []
        name_to_check = raw_name if raw_name else norm_name
        for master in self.master_records:
            # Antonym Guard: Защита от опасных склеек левый/правый, передний/задний и др.
            is_conf, _ = AntonymGuard.are_conflicting(name_to_check, master["canonical_title"])
            if is_conf:
                continue

            score = fuzz.token_set_ratio(norm_name, master["search_corpus"])
            scored_candidates.append((master, score))

        scored_candidates.sort(key=lambda x: x[1], reverse=True)
        top5 = scored_candidates[:5]

        if top5 and top5[0][1] >= 88.0:
            best_master, best_score = top5[0]
            return (best_master, "FUZZY_NAME", round(best_score / 100.0, 3)), top5

        return None, top5

    def cascade_3_llm_batch(self, items_to_resolve: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Каскад 3: LLM Batch Matching с интеллектуальным Offline/Mock fallback.
        Если переменная LLM_API_KEY задана — отправляет батч в OpenAI / DeepSeek.
        Если ключ отсутствует — запускает эвристический семантический резолвер.
        """
        api_key = os.getenv("LLM_API_KEY", "")
        base_url = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")

        results = []

        if api_key:
            # Боевой режим через OpenAI SDK
            try:
                from openai import OpenAI
                client = OpenAI(api_key=api_key, base_url=base_url)

                batch_payload = [
                    {
                        "raw_code": it["raw_code"],
                        "raw_name": it["raw_name"],
                        "clean_article": it["clean_article"],
                        "candidates": [
                            {"master_id": c[0]["master_id"], "title": c[0]["canonical_title"], "score": c[1]}
                            for c in it["candidates"]
                        ]
                    }
                    for it in items_to_resolve
                ]

                system_prompt = (
                    "Ты — эксперт по автозапчастям ГАЗ, УАЗ, Волга. Твоя задача — сопоставить позиции из 1С "
                    "с наиболее подходящей карточкой из предложенного списка кандидатов (master_id). "
                    "Если ни один кандидат точно не подходит, верни master_id = null. "
                    "Верни JSON: {\"matches\": [{\"raw_code\": \"...\", \"master_id\": \"...\", \"confidence\": 0.95}]}"
                )

                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": json.dumps(batch_payload, ensure_ascii=False)}
                    ],
                    response_format={"type": "json_object"}
                )

                llm_data = json.loads(response.choices[0].message.content)
                match_dict = {m["raw_code"]: m for m in llm_data.get("matches", [])}

                for it in items_to_resolve:
                    m = match_dict.get(it["raw_code"])
                    if m and m.get("master_id"):
                        results.append({
                            "raw_code": it["raw_code"],
                            "raw_name": it["raw_name"],
                            "clean_article": it["clean_article"],
                            "master_id": m["master_id"],
                            "match_stage": "LLM_BATCH",
                            "confidence_score": float(m.get("confidence", 0.92))
                        })
                    else:
                        results.append({
                            "raw_code": it["raw_code"],
                            "raw_name": it["raw_name"],
                            "clean_article": it["clean_article"],
                            "master_id": None,
                            "match_stage": "UNMATCHED",
                            "confidence_score": 0.0
                        })
                return results
            except Exception as e:
                print(f"⚠️ Ошибка вызова LLM API ({e}). Переключение на автономный Fallback-резолвер...")

        # Автономный Fallback-резолвер (Offline Heuristic Resolver)
        for it in items_to_resolve:
            top_candidates = it.get("candidates", [])
            if top_candidates and top_candidates[0][1] >= 62.0:
                best_cand, best_score = top_candidates[0]
                results.append({
                    "raw_code": it["raw_code"],
                    "raw_name": it["raw_name"],
                    "clean_article": it["clean_article"],
                    "master_id": best_cand["master_id"],
                    "match_stage": "LLM_BATCH",
                    "confidence_score": round(best_score / 100.0, 3)
                })
            else:
                results.append({
                    "raw_code": it["raw_code"],
                    "raw_name": it["raw_name"],
                    "clean_article": it["clean_article"],
                    "master_id": None,
                    "match_stage": "UNMATCHED",
                    "confidence_score": 0.0
                })
        return results

    def match_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Прогоняет выгрузку 1С через все 3 каскада с учетом кэша.
        Возвращает объединенный датасет и сводную аналитику.
        """
        cached = self.get_cached_mappings()
        new_mappings_to_save: List[Dict[str, Any]] = []

        all_results = []
        stage_counts = {
            "CACHE_HIT": 0,
            "EXACT_OEM": 0,
            "CROSS_NUMBER": 0,
            "FUZZY_NAME": 0,
            "LLM_BATCH": 0,
            "UNMATCHED": 0
        }

        cascade_3_queue = []

        # Словарь эталонов по master_id
        master_by_id = {m["master_id"]: m for m in self.master_records}

        for _, row in df.iterrows():
            raw_code = str(row.get("Код", row.get("raw_code", ""))).strip()
            raw_name = str(row.get("Наименование", row.get("raw_name", ""))).strip()
            raw_art = str(row.get("Артикул", row.get("raw_article", ""))).strip()
            stock_qty = float(row.get("Остаток", row.get("stock_qty", 0.0)))
            price_retail = float(row.get("ЦенаРозница", row.get("price_retail", 0.0)))

            clean_art_val = clean_article(raw_art)
            norm_name = normalize_text(raw_name)

            # Проверка кэша
            if raw_code in cached:
                c = cached[raw_code]
                stage_counts["CACHE_HIT"] += 1
                stage_counts[c["match_stage"]] = stage_counts.get(c["match_stage"], 0) + 1
                master_info = master_by_id.get(c["master_id"]) if c["master_id"] else None

                all_results.append({
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "raw_article": raw_art,
                    "clean_article": clean_art_val,
                    "stock_qty": stock_qty,
                    "price_retail": price_retail,
                    "master_id": c["master_id"],
                    "match_stage": c["match_stage"],
                    "confidence_score": c["confidence_score"],
                    "is_from_cache": True,
                    "master": master_info
                })
                continue

            # Каскад 1: Детерминированный
            c1_match = self.cascade_1_exact(clean_art_val)
            if c1_match:
                master, stage, score = c1_match
                stage_counts[stage] += 1
                mapping = {
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "clean_article": clean_art_val,
                    "master_id": master["master_id"],
                    "match_stage": stage,
                    "confidence_score": score
                }
                new_mappings_to_save.append(mapping)
                all_results.append({
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "raw_article": raw_art,
                    "clean_article": clean_art_val,
                    "stock_qty": stock_qty,
                    "price_retail": price_retail,
                    "master_id": master["master_id"],
                    "match_stage": stage,
                    "confidence_score": score,
                    "is_from_cache": False,
                    "master": master
                })
                continue

            # Каскад 2: Нечеткий (с Antonym Guard)
            c2_match, top5_candidates = self.cascade_2_fuzzy(norm_name, raw_name=raw_name)
            if c2_match:
                master, stage, score = c2_match
                stage_counts[stage] += 1
                mapping = {
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "clean_article": clean_art_val,
                    "master_id": master["master_id"],
                    "match_stage": stage,
                    "confidence_score": score
                }
                new_mappings_to_save.append(mapping)
                all_results.append({
                    "raw_code": raw_code,
                    "raw_name": raw_name,
                    "raw_article": raw_art,
                    "clean_article": clean_art_val,
                    "stock_qty": stock_qty,
                    "price_retail": price_retail,
                    "master_id": master["master_id"],
                    "match_stage": stage,
                    "confidence_score": score,
                    "is_from_cache": False,
                    "master": master
                })
                continue

            # Кандидат для Каскада 3
            cascade_3_queue.append({
                "raw_code": raw_code,
                "raw_name": raw_name,
                "clean_article": clean_art_val,
                "stock_qty": stock_qty,
                "price_retail": price_retail,
                "candidates": top5_candidates
            })

        # Обработка очереди Каскада 3
        if cascade_3_queue:
            llm_results = self.cascade_3_llm_batch(cascade_3_queue)
            for res, orig in zip(llm_results, cascade_3_queue):
                stage_counts[res["match_stage"]] += 1
                new_mappings_to_save.append(res)
                master = master_by_id.get(res["master_id"]) if res["master_id"] else None
                all_results.append({
                    "raw_code": orig["raw_code"],
                    "raw_name": orig["raw_name"],
                    "raw_article": orig.get("clean_article", ""),
                    "clean_article": orig["clean_article"],
                    "stock_qty": orig["stock_qty"],
                    "price_retail": orig["price_retail"],
                    "master_id": res["master_id"],
                    "match_stage": res["match_stage"],
                    "confidence_score": res["confidence_score"],
                    "is_from_cache": False,
                    "master": master
                })

        # Сохранение новых привязок в SQLite
        if new_mappings_to_save:
            self.save_mappings_batch(new_mappings_to_save)

        total_matched = sum(1 for r in all_results if r["master_id"] is not None)
        total_items = len(all_results)
        match_rate = round((total_matched / total_items * 100), 1) if total_items > 0 else 0.0

        return {
            "total_items": total_items,
            "total_matched": total_matched,
            "match_rate": match_rate,
            "stage_counts": stage_counts,
            "new_saved_count": len(new_mappings_to_save),
            "results": all_results
        }

    def generate_html_report(self, match_data: Dict[str, Any], output_path: str = "matching_report.html") -> str:
        """Создает презентационный дашборд сопоставления номенклатуры."""
        template_str = """
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ИИ-Матчер номенклатуры 1С с «Золотым справочником» • АВТОСКЛАД-ИИ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #080c14; color: #f1f5f9; }
    .mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="p-3 sm:p-8">

  <div class="max-w-7xl mx-auto">
    <!-- ВЕРХНЯЯ ПАНЕЛЬ -->
    <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
      <div class="flex items-center gap-3">
        <span class="bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 text-xs font-black px-3 py-1.5 rounded-lg tracking-wider uppercase shadow">
          ★ МОДУЛЬ 2: MATCHER.PY
        </span>
        <span class="text-sm text-slate-400">База: <b class="text-slate-200">master_catalog.db (SQLite)</b></span>
      </div>
      <div class="flex gap-2 text-xs">
        <a href="audit_report.html" class="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold px-4 py-2 rounded-xl transition">
          ← Отчет аудитора (Модуль 1)
        </a>
        <a href="index.html" class="bg-orange-500 hover:bg-orange-600 text-slate-950 font-black px-4 py-2 rounded-xl transition">
          Главный сайт ➔
        </a>
      </div>
    </div>

    <!-- ТИТУЛЬНЫЙ БЛОК И KPI КАСКАДОВ -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl relative overflow-hidden">
      <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-6 mb-6">
        <div>
          <div class="text-xs font-black uppercase tracking-widest text-emerald-400 mb-1">
            Каскадный конвейер нормализации и обогащения номенклатуры
          </div>
          <h1 class="text-xl sm:text-3xl font-black text-white">
            Результаты сопоставления склада 1С с эталонной базой
          </h1>
          <p class="text-slate-400 text-sm mt-1">
            Каскад 1 (Exact OEM & Cross) ➔ Каскад 2 (Fuzzy + Автосленг) ➔ Каскад 3 (LLM Batch / Fallback)
          </p>
        </div>
        <div class="text-right">
          <div class="text-3xl sm:text-4xl font-black text-emerald-400 mono">{{ data.match_rate }}%</div>
          <div class="text-xs text-slate-400">Процент успешной склейки</div>
        </div>
      </div>

      <!-- 4 КАРТОЧКИ КАСКАДОВ -->
      <div class="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div class="text-[11px] font-bold text-slate-400 uppercase">Всего строк 1С</div>
          <div class="text-2xl font-black text-white mono mt-1">{{ data.total_items }}</div>
          <div class="text-[11px] text-emerald-400 mt-1">Склеено: {{ data.total_matched }} SKU</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-blue-500/40">
          <div class="text-[11px] font-bold text-blue-400 uppercase">1. Точный OEM</div>
          <div class="text-2xl font-black text-blue-400 mono mt-1">{{ data.stage_counts.EXACT_OEM }}</div>
          <div class="text-[11px] text-slate-400 mt-1">Детерминированно (0 ₽)</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-cyan-500/40">
          <div class="text-[11px] font-bold text-cyan-400 uppercase">2. Кросс-номера</div>
          <div class="text-2xl font-black text-cyan-400 mono mt-1">{{ data.stage_counts.CROSS_NUMBER }}</div>
          <div class="text-[11px] text-slate-400 mt-1">По аналогам (0 ₽)</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-amber-500/40">
          <div class="text-[11px] font-bold text-amber-400 uppercase">3. Fuzzy + Сленг</div>
          <div class="text-2xl font-black text-amber-400 mono mt-1">{{ data.stage_counts.FUZZY_NAME }}</div>
          <div class="text-[11px] text-slate-400 mt-1">Сходство ≥ 88% (0 ₽)</div>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-purple-500/40">
          <div class="text-[11px] font-bold text-purple-400 uppercase">4. LLM Batch / Fallback</div>
          <div class="text-2xl font-black text-purple-400 mono mt-1">{{ data.stage_counts.LLM_BATCH }}</div>
          <div class="text-[11px] text-slate-400 mt-1">Сложные случаи</div>
        </div>
      </div>
    </div>

    <!-- ТАБЛИЦА ДО И ПОСЛЕ: ОБОГАЩЕНИЕ НОМЕНКЛАТУРЫ -->
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl">
      <div class="flex flex-wrap items-center justify-between gap-4 mb-4">
        <div>
          <span class="text-xs font-bold text-orange-400 uppercase tracking-wider">Наглядное сравнение «Было ➔ Стало»</span>
          <h2 class="text-lg sm:text-xl font-bold text-white">Как грязная строчка из 1С обогатилась для Авито и Дрома</h2>
        </div>
        <div class="text-xs text-slate-400 font-mono">
          Кэшировано в SQLite: <b class="text-white">{{ data.total_matched }} связей</b>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
          <thead>
            <tr class="text-slate-400 border-b border-slate-800 pb-2">
              <th class="py-2.5 px-3">Код</th>
              <th class="py-2.5 px-3 w-1/4">Было в 1С (Грязная строка)</th>
              <th class="py-2.5 px-3">Стадия матчинга</th>
              <th class="py-2.5 px-3 w-1/3">Стало в «Золотом справочнике» (Для Авито/Дром)</th>
              <th class="py-2.5 px-3">Кроссы и Применяемость</th>
              <th class="py-2.5 px-3 text-center">Фото</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800/80 font-mono">
            {% for item in data.results %}
            <tr class="hover:bg-slate-800/40 transition">
              <td class="py-2.5 px-3 text-slate-400">{{ item.raw_code }}</td>
              
              <!-- БЫЛО В 1С -->
              <td class="py-2.5 px-3 font-sans">
                <div class="font-bold text-slate-200">{{ item.raw_name }}</div>
                <div class="text-[11px] text-slate-400 mt-0.5">Арт: <span class="text-amber-400">{{ item.raw_article or '—' }}</span></div>
              </td>

              <!-- СТАДИЯ МАТЧИНГА -->
              <td class="py-2.5 px-3">
                {% if item.match_stage == 'EXACT_OEM' %}
                  <span class="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold">1. EXACT_OEM</span>
                {% elif item.match_stage == 'CROSS_NUMBER' %}
                  <span class="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">1. CROSS_NUM</span>
                {% elif item.match_stage == 'FUZZY_NAME' %}
                  <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">2. FUZZY ({{ (item.confidence_score*100)|round }}%)</span>
                {% elif item.match_stage == 'LLM_BATCH' %}
                  <span class="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-bold">3. LLM BATCH</span>
                {% else %}
                  <span class="px-2 py-0.5 rounded bg-red-500/20 text-red-400 text-[10px] font-bold">UNMATCHED</span>
                {% endif %}
              </td>

              <!-- СТАЛО В СПРАВОЧНИКЕ -->
              <td class="py-2.5 px-3 font-sans">
                {% if item.master %}
                  <div class="font-bold text-emerald-300">{{ item.master.canonical_title }}</div>
                  <div class="text-[10px] text-slate-400 mt-0.5">Категория: {{ item.master.avito_category.split('/')[-1] }}</div>
                {% else %}
                  <span class="text-red-400 italic">Требуется ручная верификация</span>
                {% endif %}
              </td>

              <!-- КРОССЫ И ПРИМЕНЯЕМОСТЬ -->
              <td class="py-2.5 px-3 font-sans text-[11px]">
                {% if item.master %}
                  <div class="text-slate-300 truncate max-w-xs" title="{{ item.master.applicability }}">{{ item.master.applicability }}</div>
                  <div class="text-[10px] text-slate-400 mt-0.5">Кроссов: <b class="text-cyan-400">{{ item.master.cross_numbers|length }} шт.</b> ({{ item.master.brands_analogs|join(', ') }})</div>
                {% else %}
                  —
                {% endif %}
              </td>

              <!-- ФОТО -->
              <td class="py-2.5 px-3 text-center">
                {% if item.master and item.master.image_urls %}
                  <img src="{{ item.master.image_urls[0] }}" alt="фото" class="w-10 h-10 object-cover rounded-lg border border-slate-700 mx-auto shadow" />
                {% else %}
                  <span class="text-slate-600 text-xs">нет</span>
                {% endif %}
              </td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>

    <!-- ПОДВАЛ ДЕЙСТВИЙ -->
    <div class="bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
      <div>
        <h3 class="font-bold text-white text-base">Кэш привязок сохранен в SQLite (client_sku_mapping)</h3>
        <p class="text-xs text-slate-400 mt-1">При последующих запусках сопоставление выполняется мгновенно и не тратит токены API.</p>
      </div>
      <div class="flex gap-3">
        <a href="https://wa.me/79028028246" target="_blank" class="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black px-5 py-2.5 rounded-xl text-xs transition">
          💬 WhatsApp: +7 (902) 802-82-46
        </a>
      </div>
    </div>
  </div>

</body>
</html>
"""
        template = Template(template_str)
        rendered_html = template.render(data=match_data)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(rendered_html)
        return output_path


def main():
    parser = argparse.ArgumentParser(description="АВТОСКЛАД-ИИ: Модуль 2 (ИИ-Матчер номенклатуры)")
    parser.add_argument("file_path", nargs="?", default="sample_1c_gaz_uaz.xlsx", help="Путь к файлу выгрузки 1С")
    parser.add_argument("--client_id", default="client_main", help="ID клиента для кэширования связей")
    parser.add_argument("--db", default=DB_PATH, help="Путь к SQLite базе master_catalog.db")
    parser.add_argument("--html", default="matching_report.html", help="Путь к файлу HTML-отчета")
    parser.add_argument("--json", default="matching_summary.json", help="Путь к файлу JSON-сводки")

    args = parser.parse_args()

    print(f"🚀 Запуск ИИ-матчера по файлу: {args.file_path}")
    print(f"📦 База данных: {args.db}")
    print(f"🏢 Client ID: {args.client_id}")

    if not os.path.exists(args.file_path):
        print(f"❌ Файл не найден: {args.file_path}")
        sys.exit(1)

    df, _ = detect_and_read_1c_file(args.file_path)

    matcher = CatalogMatcher(db_path=args.db, client_id=args.client_id)
    match_data = matcher.match_dataframe(df)

    print("\n--- РЕЗУЛЬТАТЫ КАСКАДНОГО МАТЧИНГА ---")
    print(f"Всего позиций в 1С:     {match_data['total_items']} SKU")
    print(f"Успешно склеено:        {match_data['total_matched']} SKU ({match_data['match_rate']}%)")
    print(f"Каскад 1 (Точный OEM):   {match_data['stage_counts']['EXACT_OEM']} SKU (0 ₽)")
    print(f"Каскад 1 (Кросс-номера): {match_data['stage_counts']['CROSS_NUMBER']} SKU (0 ₽)")
    print(f"Каскад 2 (Fuzzy+Сленг):  {match_data['stage_counts']['FUZZY_NAME']} SKU (0 ₽)")
    print(f"Каскад 3 (LLM Batch):    {match_data['stage_counts']['LLM_BATCH']} SKU")
    print(f"Не распознано:          {match_data['stage_counts']['UNMATCHED']} SKU")
    print(f"Сохранено новых связей: {match_data['new_saved_count']} в client_sku_mapping")

    html_file = matcher.generate_html_report(match_data, args.html)
    with open(args.json, "w", encoding="utf-8") as f:
        # Сериализуем без дублирования циклических ссылок
        clean_summary = {k: v for k, v in match_data.items() if k != "results"}
        json.dump(clean_summary, f, ensure_ascii=False, indent=2)

    print(f"\n✅ HTML-дашборд сформирован: {html_file}")
    print(f"✅ JSON-сводка сохранена: {args.json}")


if __name__ == "__main__":
    main()
