"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_frontend_sync.py
Тестирование целостности, синхронизации и безопасности фронтенда:
- Наличие всех 9 HTML-страниц платформы
- Полное отсутствие устаревшего имени «Иван Иванович» (Zero Tolerance)
- Наличие имени собственника «Вячеслав Юрьевич»
- Единый контактный телефон +7 (902) 802-82-46 и Telegram @dkazak1999
- Синхронизация файлов витрины с папкой github-pages/
- XSS и JSON безопасность: отсутствие неэкранированных </script> внутри тегов <script>
- Работоспособность ссылок на все 5 модулей в ERP-кабинете dashboard.html
"""

import os
import re
import pytest

from config import BASE_DIR, GITHUB_PAGES_DIR

ROOT_DIR = str(BASE_DIR)
PAGES_DIR = str(GITHUB_PAGES_DIR)

ALL_HTML_FILES = [
    "index.html",
    "dashboard.html",
    "audit_report.html",
    "matching_report.html",
    "feeds_preview.html",
    "bot_simulator.html",
    "owner_radar.html",
    "ai_studio_code.html",
    "ai_studio_code моушен+слава.html"
]


def test_frontend_all_html_files_exist():
    """Все 9 ключевых страниц платформы существуют в корневом каталоге."""
    for filename in ALL_HTML_FILES:
        full_path = os.path.join(ROOT_DIR, filename)
        assert os.path.exists(full_path), f"Файл {filename} отсутствует в корне проекта!"


def test_frontend_zero_ivan_ivanovich():
    """Ни на одной странице не должно остаться упоминаний 'Иван Иванович'."""
    forbidden_patterns = [
        re.compile(r"Иван\s+Иванович", re.IGNORECASE),
        re.compile(r"Ивана\s+Ивановича", re.IGNORECASE),
        re.compile(r"Ивану\s+Ивановичу", re.IGNORECASE),
    ]

    for filename in ALL_HTML_FILES:
        full_path = os.path.join(ROOT_DIR, filename)
        if not os.path.exists(full_path):
            continue
        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        for pattern in forbidden_patterns:
            matches = pattern.findall(content)
            assert len(matches) == 0, f"В файле {filename} найдено запрещенное имя: {matches}"


def test_frontend_vyacheslav_yuryevich_presence():
    """Имя собственника 'Вячеслав Юрьевич' присутствует на ключевых экранах."""
    key_pages = ["dashboard.html", "owner_radar.html", "index.html"]
    for filename in key_pages:
        full_path = os.path.join(ROOT_DIR, filename)
        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        assert "Вячеслав Юрьевич" in content or "Вячеслава Юрьевича" in content, (
            f"В файле {filename} не найдено имя собственника Вячеслав Юрьевич!"
        )


def test_frontend_contacts_consistency():
    """Телефон +7 (902) 802-82-46 и Telegram @dkazak1999 присутствуют на лендинге и дашборде."""
    for filename in ["index.html", "dashboard.html", "owner_radar.html"]:
        full_path = os.path.join(ROOT_DIR, filename)
        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        assert "79028028246" in content or "802-82-46" in content, (
            f"В файле {filename} отсутствует контактный телефон!"
        )
        assert "dkazak1999" in content, (
            f"В файле {filename} отсутствует Telegram @dkazak1999!"
        )


def test_frontend_github_pages_sync():
    """Ключевые страницы синхронизированы в репозитории github-pages/."""
    synced_pages = [
        "index.html",
        "dashboard.html",
        "audit_report.html",
        "matching_report.html",
        "feeds_preview.html",
        "bot_simulator.html",
        "owner_radar.html"
    ]
    for filename in synced_pages:
        gh_path = os.path.join(PAGES_DIR, filename)
        assert os.path.exists(gh_path), f"Файл {filename} не скопирован в github-pages/!"


def test_frontend_script_tags_no_raw_closing_script():
    """В тегах <script> нет неэкранированных строковых закрывающих тегов </script>."""
    for filename in ["owner_radar.html", "bot_simulator.html"]:
        full_path = os.path.join(ROOT_DIR, filename)
        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        # Ищем блоки <script>...</script>
        script_blocks = re.findall(r"<script[\s\S]*?</script>", content, re.IGNORECASE)
        for block in script_blocks:
            # Внутри скрипта (за исключением самого финального тега) не должно быть незаэкранированного </script>
            inner = block[block.find(">") + 1 : block.rfind("</script>")]
            assert "</script>" not in inner, f"Внутри <script> в {filename} найден опасный сырой </script>!"


def test_frontend_dashboard_cards_and_links():
    """ERP-дашборд dashboard.html содержит ссылки на все 5 модулей платформы."""
    with open(os.path.join(ROOT_DIR, "dashboard.html"), "r", encoding="utf-8") as f:
        content = f.read()

    assert "audit_report.html" in content
    assert "matching_report.html" in content
    assert "feeds_preview.html" in content
    assert "bot_simulator.html" in content
    assert "owner_radar.html" in content
