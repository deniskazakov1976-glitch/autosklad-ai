"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_guard.py
Тестирование модуля inventory_guard.py:
- clean_article: CYR/LAT homoglyphs, спецсимволы, пустые значения
- parse_1c_number: форматы чисел, неразрывные пробелы, запятые, дефолты
- detect_and_read_1c_file: мульти-кодировки (cp1251, utf-8-sig, cp866), разделители, приоритет «Конечный остаток», мульти-склад
- AntonymGuard + KitGuard: защита от склеек несовместимых запчастей и комплектов
- clean_avito_title, sanitize_xml_string, safe_json_dumps
"""

import os
import tempfile
import pytest
import pandas as pd
import numpy as np

from inventory_guard import (
    clean_article,
    parse_1c_number,
    detect_and_read_1c_file,
    AntonymGuard,
    KitGuard,
    clean_avito_title,
    sanitize_xml_string,
    safe_json_dumps
)


# =====================================================================
# 1. ТЕСТЫ CLEAN_ARTICLE (СИММЕТРИЧНАЯ НОРМАЛИЗАЦИЯ И ГОМОГЛИФЫ)
# =====================================================================

def test_clean_article_homoglyphs():
    """Проверка транслитерации 12 кириллических букв-двойников в латиницу."""
    cyr = "АВСЕКМНОРТХУ"
    lat = "ABCEKMHOPTXY"
    assert clean_article(cyr) == lat


def test_clean_article_mixed_and_punctuation():
    """Очистка от пробелов, дефисов, точек, слешей и смешанных символов."""
    assert clean_article("  3302-1701025 / А  ") == "33021701025A"
    assert clean_article("УМЗ-4216.1000400_01") == "YMЗ4216100040001"
    assert clean_article("К-405-СТД") == "K405CTД"
    assert clean_article("3163.2401010-10") == "3163240101010"


def test_clean_article_empty_and_nan():
    """Обработка пустых строк, None и np.nan."""
    assert clean_article("") == ""
    assert clean_article("   ") == ""
    assert clean_article(None) == ""
    assert clean_article(np.nan) == ""


# =====================================================================
# 2. ТЕСТЫ PARSE_1C_NUMBER
# =====================================================================

def test_parse_1c_number_standard_and_dirty():
    """Тест парсинга строковых чисел с неразрывными пробелами и запятыми."""
    assert parse_1c_number("12 400,50") == 12400.5
    assert parse_1c_number("1\xa0250,00") == 1250.0
    assert parse_1c_number("45'000,75") == 45000.75
    assert parse_1c_number(100) == 100.0
    assert parse_1c_number(99.9) == 99.9


def test_parse_1c_number_empty_and_fallback():
    """Проверка возврата default при пустых, прочерках и невалидных строках."""
    assert parse_1c_number("-") == 0.0
    assert parse_1c_number("", default=-1.0) == -1.0
    assert parse_1c_number(None, default=0.0) == 0.0
    assert parse_1c_number("не число", default=42.0) == 42.0


# =====================================================================
# 3. ТЕСТЫ ЧТЕНИЯ ФАЙЛОВ 1С, КОДИРОВОК И МУЛЬТИ-СКЛАДОВ
# =====================================================================

def test_detect_and_read_1c_file_cp1251_semicolon():
    """Чтение выгрузки 1С в кодировке cp1251 с разделителем точка с запятой."""
    content = (
        "ООО «Автодеталь»;;;;\n"
        "Остатки товаров на складе;;;;\n"
        "Код;Артикул;Наименование;Конечный остаток;Цена\n"
        "001;3302-10;Редуктор моста ГАЗ;3;28500,00\n"
        "002;3163-20;Сцепление УАЗ;5;7200,00\n"
        "Итого;;;8;35700,00\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="cp1251", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        df, report = detect_and_read_1c_file(temp_path)
        assert len(df) == 2
        assert "Итого" not in df["raw_name"].values
        assert df["stock_qty"].iloc[0] == 3.0
        assert df["price_retail"].iloc[0] == 28500.0
        assert isinstance(report, list)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_detect_and_read_1c_file_utf8_sig_tab():
    """Чтение выгрузки 1С в кодировке utf-8-sig с табуляцией."""
    content = (
        "Шапка отчета 1С\t\t\t\t\n"
        "Код\tАртикул\tНаименование\tКонечный остаток\tЦена продажи\n"
        "010\t4216-10\tГБЦ УМЗ 4216\t2\t45000\n"
        "011\t405-20\tСтартер ЗМЗ 405\t4\t6800\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8-sig", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        df, report = detect_and_read_1c_file(temp_path)
        assert len(df) == 2
        assert df["stock_qty"].iloc[0] == 2.0
        assert df["price_retail"].iloc[0] == 45000.0
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_detect_and_read_1c_file_prioritize_konechny_ostotok():
    """Парсер обязан предпочитать 'Конечный остаток' и игнорировать 'Начальный остаток' / 'Приход'."""
    content = (
        "Код,Артикул,Наименование,Начальный остаток,Приход,Расход,Конечный остаток,Цена\n"
        "K1,402-10,Вал коленчатый 402,100,50,145,5,15000\n"
        "K2,4216-20,Поршневая 4216,80,20,98,2,9500\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        df, _ = detect_and_read_1c_file(temp_path)
        assert len(df) == 2
        assert df["stock_qty"].iloc[0] == 5.0
        assert df["stock_qty"].iloc[1] == 2.0
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_detect_and_read_1c_file_multi_warehouse_sum():
    """Суммирование остатков по нескольким складам ('Склад Центр', 'Склад Запад')."""
    content = (
        "Код;Артикул;Наименование;Склад Центр;Склад Запад;Цена\n"
        "MW1;3302-01;Фара левая ГАЗ-3302;3;4;2200\n"
        "MW2;3302-02;Фара правая ГАЗ-3302;2;5;2200\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        df, _ = detect_and_read_1c_file(temp_path)
        assert len(df) == 2
        assert df["stock_qty"].iloc[0] == 7.0  # 3 + 4
        assert df["stock_qty"].iloc[1] == 7.0  # 2 + 5
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


# =====================================================================
# 4. ТЕСТЫ ANTONYM_GUARD И KIT_GUARD
# =====================================================================

def test_antonym_guard_sides_and_axes():
    """Проверка конфликтов сторон (левый vs правый) и осей (передний vs задний)."""
    guard = AntonymGuard()

    # Стороны
    conf, reason = guard.are_conflicting("Фара левая ГАЗ-3302", "Фара правая ГАЗ-3302")
    assert conf is True
    assert "сторон" in reason

    # Оси
    conf, reason = guard.are_conflicting("Колодки тормозные передние Газель", "Колодки тормозные задние Газель")
    assert conf is True
    assert "оси" in reason or "осей" in reason


def test_antonym_guard_positions_and_engines():
    """Проверка конфликтов положений (верх/низ, впуск/выпуск) и моторов (402 vs 4216)."""
    guard = AntonymGuard()

    # Положения
    conf, _ = guard.are_conflicting("Рычаг верхний правый УАЗ", "Рычаг нижний правый УАЗ")
    assert conf is True

    conf, _ = guard.are_conflicting("Клапан впускной ЗМЗ-406", "Клапан выпускной ЗМЗ-406")
    assert conf is True

    # Двигатели
    conf, reason = guard.are_conflicting("Вал коленчатый ЗМЗ 402", "Вал коленчатый УМЗ 4216")
    assert conf is True
    assert "двигателей" in reason

    conf, _ = guard.are_conflicting("ГБЦ Cummins ISF 2.8 Газель", "ГБЦ Evotech A274 Газель")
    assert conf is True

    # Ремонтные размеры
    conf, reason = guard.are_conflicting("Вкладыши шатунные ЗМЗ-406 СТД", "Вкладыши шатунные ЗМЗ-406 0.25")
    assert conf is True
    assert "размер" in reason

    conf, _ = guard.are_conflicting("Поршневая 4216 размер 0.5", "Поршневая 4216 размер 1.0")
    assert conf is True


def test_detect_and_read_1c_file_negative_stock_anomaly():
    """Проверка выявления и обнуления отрицательных остатков (пересортица)."""
    content = (
        "Код,Артикул,Наименование,Конечный остаток,Цена\n"
        "NEG1,3302-99,Трос ручника,-3,450\n"
        "POS1,3302-98,Колодки ручника,5,600\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        df, anomalies = detect_and_read_1c_file(temp_path)
        assert len(df) == 2
        # Отрицательный остаток обнулен для безопасности витрин
        assert df["stock_qty"].iloc[0] == 0.0
        assert df["stock_qty"].iloc[1] == 5.0
        # Аномалия зафиксирована в логе
        assert any(a.get("type") == "negative_stock_anomaly" for a in anomalies)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_kit_guard_piece_vs_kit():
    """KitGuard: штучная деталь никогда не должна склеиваться с комплектом / набором."""
    guard = AntonymGuard()

    conf, reason = guard.are_conflicting("Поршень ЗМЗ-405 95.5 мм (1 шт)", "Комплект поршней ЗМЗ-405 95.5 мм (4 шт)")
    assert conf is True
    assert "комплектации" in reason

    conf, _ = guard.are_conflicting("Шкворень УАЗ 469 штука", "Ремкомплект шкворней УАЗ 469 с подшипниками")
    assert conf is True

    # Совместимые (оба комплекты или оба штуки)
    conf, _ = guard.are_conflicting("Комплект прокладок 4216", "Набор прокладок двигателя 4216")
    assert conf is False


# =====================================================================
# 5. ТЕСТЫ CLEAN_AVITO_TITLE, SANITIZE_XML И SAFE_JSON_DUMPS
# =====================================================================

def test_clean_avito_title():
    """Обрезка длинных заголовков строго до <= 50 символов по границе слова."""
    long_title = "Редуктор заднего моста ГАЗ-3302 Газель Бизнес с блокировкой колес"
    cleaned = clean_avito_title(long_title, max_len=50)
    assert len(cleaned) <= 50
    assert not cleaned.endswith(" ")
    assert "Бизнес" in cleaned or "Газель" in cleaned


def test_sanitize_xml_string():
    """Удаление невидимых управляющих символов и экранирование спецсимволов XML."""
    dirty = "Деталь ГАЗ <3302> & \"УАЗ\"\x00\x08\x1f"
    sanitized = sanitize_xml_string(dirty)
    assert "\x00" not in sanitized
    assert "\x08" not in sanitized
    assert "&lt;3302&gt;" in sanitized
    assert "&amp;" in sanitized


def test_safe_json_dumps_xss_protection():
    """Сериализация JSON с экранированием </script>, <!-- и unicode разделителей."""
    payload = {
        "xss": "</script><script>alert('pwned')</script>",
        "comment": "<!-- secret comment -->",
        "unicode_sep": "line1\u2028line2\u2029line3"
    }
    dumped = safe_json_dumps(payload)
    assert "</script>" not in dumped
    assert r"<\/script>" in dumped
    assert "<!--" not in dumped
    assert r"<\!--" in dumped
    assert "\u2028" not in dumped or r"\u2028" in dumped
