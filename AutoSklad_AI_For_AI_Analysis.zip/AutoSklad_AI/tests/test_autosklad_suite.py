"""
АВТОМАТИЧЕСКИЙ ТЕСТОВЫЙ КОМПЛЕКС: tests/test_autosklad_suite.py
Платформа «АВТОСКЛАД-ИИ»

Полное покрытие отказоустойчивости, безопасности и бизнес-логики:
1. Тесты парсера 1С (сдвинутая шапка, строки Итого/папки, строковые числа, отрицательные остатки).
2. Тесты Antonym Guard (стороны, оси, положения, ремонтные размеры, несовместимые моторы).
3. Тесты Матчера и Кэша (Каскад 1 OEM/Кроссы, Каскад 2 Fuzzy, SQLite кэширование).
4. Тесты Фидов Авито/Дром (XML валидность, заголовок <= 50 символов, фильтры безопасности, склейка дублей).
5. Тесты ИИ-Продавца (защита от овербукинга, SQL-инъекции, Escalation Guard, честный OUT_OF_STOCK).
6. Тесты Радара Собственника (дельта склада, защита от ZeroDivisionError, обработка новинок/удаленных SKU).
"""

import os
import sys
import tempfile
import sqlite3
import json
import xml.etree.ElementTree as ET
import pytest
import pandas as pd

# Добавляем корень проекта в sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from inventory_guard import (
    parse_1c_number,
    detect_and_read_1c_file,
    AntonymGuard,
    clean_avito_title,
    sanitize_xml_string
)
from auditor import InventoryAuditor
from matcher import CatalogMatcher, clean_article
from feed_generator import FeedGenerator
from ai_sales_bot import AISalesBot
from owner_radar import OwnerRadar

DB_PATH = os.path.join(PROJECT_ROOT, "master_catalog.db")
SAMPLE_EXCEL = os.path.join(PROJECT_ROOT, "sample_1c_gaz_uaz.xlsx")


# =====================================================================
# 1. ТЕСТЫ ПАРСЕРА 1С И ЧИСТКИ ДАННЫХ (HARDENING)
# =====================================================================

def test_1c_parser_string_numbers():
    """Тест парсинга строковых чисел с неразрывными пробелами, запятыми и прочерками."""
    assert parse_1c_number("12 400,50") == 12400.5
    assert parse_1c_number("1\xa0250,00") == 1250.0
    assert parse_1c_number("-") == 0.0
    assert parse_1c_number("") == 0.0
    assert parse_1c_number(None) == 0.0
    assert parse_1c_number(550) == 550.0
    assert parse_1c_number("3 999.99") == 3999.99


def test_1c_parser_dirty_header_shifted_rows():
    """Тест загрузки 'грязного' файла 1С со сдвинутой шапкой на 7-й строке."""
    rows = [
        ["ООО 'Автозапчасти Поволжье'", "", "", "", ""],
        ["Ведомость остатков товаров на складах", "", "", "", ""],
        ["Период: 01.01.2026 - 17.11.2026", "", "", "", ""],
        ["Склад: Центральный оптово-розничный", "", "", "", ""],
        ["", "", "", "", ""],
        ["", "", "", "", ""],
        ["Код", "Артикул", "Наименование", "Остаток", "ЦенаРозница"],  # Строка заголовков
        ["00-001", "3302-100", "Редуктор заднего моста ГАЗ-3302", "3", "28 500,00"],
        ["00-002", "4216-200", "Насос ГУР ГАЗель Бизнес", "2", "6 950,00"]
    ]
    df_raw = pd.DataFrame(rows)

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        df_raw.to_excel(tmp_path, index=False, header=False)
        df_clean, anomalies = detect_and_read_1c_file(tmp_path)

        assert len(df_clean) == 2
        assert "raw_name" in df_clean.columns
        assert "stock_qty" in df_clean.columns
        assert df_clean.iloc[0]["stock_qty"] == 3.0
        assert df_clean.iloc[0]["price_retail"] == 28500.0
        assert df_clean.iloc[1]["price_retail"] == 6950.0
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def test_1c_parser_skip_total_and_summary_rows():
    """Тест обязательного отсечения строк 'Итого', 'Всего' и 'ИТОГО ПО СКЛАДУ'."""
    rows = [
        ["Код", "Артикул", "Наименование", "Остаток", "ЦенаРозница"],
        ["00-001", "3302", "Колодки передние ГАЗ-3302", "10", "1 500,00"],
        ["", "", "Итого по группе ГАЗель:", "10", "15 000,00"],
        ["00-002", "3163", "Колодки передние УАЗ Патриот", "5", "1 800,00"],
        ["", "", "ВСЕГО ПО СКЛАДУ", "15", "24 000,00"],
        ["", "", "Итого:", "15", "24 000,00"]
    ]
    df_raw = pd.DataFrame(rows[1:], columns=rows[0])

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        df_raw.to_excel(tmp_path, index=False)
        df_clean, anomalies = detect_and_read_1c_file(tmp_path)

        assert len(df_clean) == 2
        names = df_clean["raw_name"].tolist()
        assert "Колодки передние ГАЗ-3302" in names
        assert "Колодки передние УАЗ Патриот" in names
        assert not any("итого" in n.lower() or "всего" in n.lower() for n in names)
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def test_1c_parser_skip_folder_rows():
    """Тест отсечения пустых папок иерархии (без цен, остатка и артикула)."""
    rows = [
        ["Код", "Артикул", "Наименование", "Остаток", "ЦенаРозница"],
        ["F-001", "", "1. ДЕТАЛИ ДВИГАТЕЛЯ (ПАПКА)", "", ""],
        ["00-101", "406-100", "Поршень ЗМЗ-406", "4", "2 200,00"]
    ]
    df_raw = pd.DataFrame(rows[1:], columns=rows[0])

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        df_raw.to_excel(tmp_path, index=False)
        df_clean, anomalies = detect_and_read_1c_file(tmp_path)

        assert len(df_clean) == 1
        assert df_clean.iloc[0]["raw_name"] == "Поршень ЗМЗ-406"
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def test_1c_parser_negative_stock_anomaly():
    """Тест выявления отрицательных остатков (пересортица): флаг аномалии и обнуление для витрины."""
    rows = [
        ["Код", "Артикул", "Наименование", "Остаток", "ЦенаРозница"],
        ["00-001", "3302-ERR", "Крыло переднее правое 3302", "-3", "4 500,00"],
        ["00-002", "3302-OK", "Крыло переднее левое 3302", "2", "4 500,00"]
    ]
    df_raw = pd.DataFrame(rows[1:], columns=rows[0])

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        df_raw.to_excel(tmp_path, index=False)
        df_clean, anomalies = detect_and_read_1c_file(tmp_path)

        assert len(anomalies) == 1
        assert anomalies[0]["type"] == "negative_stock_anomaly"
        assert anomalies[0]["original_stock"] == -3.0
        assert anomalies[0]["adjusted_stock"] == 0.0

        row_err = df_clean[df_clean["raw_code"] == "00-001"].iloc[0]
        assert row_err["stock_qty"] == 0.0  # Для витрин приведен к 0!
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


# =====================================================================
# 2. ТЕСТЫ БЛОКИРАТОРА СКЛЕЕК (ANTONYM GUARD)
# =====================================================================

def test_antonym_guard_sides_left_right():
    """Фара левая и фара правая никогда не должны склеиваться в дубли."""
    is_conf, reason = AntonymGuard.are_conflicting("Фара левая Газель Next", "Фара правая Газель Next")
    assert is_conf is True
    assert "левый vs правый" in reason

    is_conf2, _ = AntonymGuard.are_conflicting("Зеркало боковое лев. с обогревом", "Зеркало боковое прав. с обогревом")
    assert is_conf2 is True

    # Совпадающая сторона — не конфликт
    is_conf3, _ = AntonymGuard.are_conflicting("Фара левая Next", "Фара головного света левая Next")
    assert is_conf3 is False


def test_antonym_guard_axes_front_rear():
    """Передние и задние колодки/амортизаторы не должны склеиваться."""
    is_conf, reason = AntonymGuard.are_conflicting("Колодки передние УАЗ Патриот", "Колодки задние УАЗ Патриот")
    assert is_conf is True
    assert "передний vs задний" in reason

    is_conf2, _ = AntonymGuard.are_conflicting("Амортизатор пер. ГАЗ-3302", "Амортизатор зад. ГАЗ-3302")
    assert is_conf2 is True


def test_antonym_guard_position_upper_lower():
    """Верхний и нижний рычаг подвески не должны склеиваться."""
    is_conf, reason = AntonymGuard.are_conflicting("Рычаг передней подвески верхний Соболь", "Рычаг подвески нижний Соболь")
    assert is_conf is True
    assert "верхний vs нижний" in reason


def test_antonym_guard_position_inner_outer():
    """Внутренний и наружный подшипники ступицы не должны склеиваться."""
    is_conf, reason = AntonymGuard.are_conflicting("Подшипник ступицы внутренний ГАЗель", "Подшипник ступицы наружный ГАЗель")
    assert is_conf is True
    assert "внутренний vs наружный" in reason


def test_antonym_guard_valves_inlet_exhaust():
    """Впускной и выпускной клапаны ГБЦ не должны склеиваться."""
    is_conf, reason = AntonymGuard.are_conflicting("Клапан впускной ЗМЗ-406", "Клапан выпускной ЗМЗ-406")
    assert is_conf is True
    assert "впускной vs выпускной" in reason


def test_antonym_guard_repair_sizes():
    """Ремонтные размеры ЦПГ и вкладышей (стд vs 0.25 vs 0.5) не должны склеиваться."""
    is_conf, reason = AntonymGuard.are_conflicting("Вкладыши шатунные ЗМЗ-406 стд", "Вкладыши шатунные ЗМЗ-406 0.25")
    assert is_conf is True
    assert "0.25" in reason

    is_conf2, _ = AntonymGuard.are_conflicting("Поршень 405 d=95.5 номинал", "Поршень 405 d=96.0 ремонт 0.5")
    assert is_conf2 is True


def test_antonym_guard_engine_families():
    """Несовместимые моторы (ЗМЗ-406 vs УМЗ-4216 vs Cummins) не склеиваются."""
    is_conf, reason = AntonymGuard.are_conflicting("ГБЦ ЗМЗ 406 в сборе", "ГБЦ УМЗ 4216 в сборе")
    assert is_conf is True
    assert "Конфликт двигателей" in reason

    is_conf2, _ = AntonymGuard.are_conflicting("Стартер Cummins ISF 2.8", "Стартер ЗМЗ-402")
    assert is_conf2 is True


def test_auditor_prevents_antonym_clusters():
    """Модуль 1 (auditor.py) не должен склеивать в дубли фару левую и правую."""
    rows = [
        {"raw_code": "001", "raw_article": "A1", "raw_name": "Фара левая Газель Next борт", "stock_qty": 2.0, "price_retail": 6500.0, "price_cost": 4500.0, "sales_12m": 10.0, "days_no_movement": 10},
        {"raw_code": "002", "raw_article": "A2", "raw_name": "Фара правая Газель Next борт", "stock_qty": 2.0, "price_retail": 6500.0, "price_cost": 4500.0, "sales_12m": 10.0, "days_no_movement": 10}
    ]
    df = pd.DataFrame(rows)

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        df.to_excel(tmp_path, index=False)
        auditor = InventoryAuditor(tmp_path)
        auditor.load_data()
        clusters = auditor.find_duplicates()

        # Так как артикулы разные, они могли бы склеиться по нечеткому поиску (>85% сходство слов),
        # но Antonym Guard обязан предотвратить это!
        assert len(clusters) == 0
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


# =====================================================================
# 3. ТЕСТЫ МАТЧЕРА И КЭША (МОДУЛЬ 2)
# =====================================================================

def test_matcher_cascade_1_exact_oem():
    """Каскад 1: точное совпадение по чистому OEM."""
    matcher = CatalogMatcher(db_path=DB_PATH)
    # КПП ГАЗ-3309 дизель OEM 3309-1700010
    res = matcher.cascade_1_exact("33091700010")
    assert res is not None
    master, stage, score = res
    assert stage == "EXACT_OEM"
    assert score == 1.0
    assert "3309" in master["canonical_title"] or "КПП" in master["canonical_title"]


def test_matcher_cascade_1_cross_numbers():
    """Каскад 1: сопоставление по массиву кросс-номеров."""
    matcher = CatalogMatcher(db_path=DB_PATH)
    # Кросс-номер стартера КЗАТЭ 5732.3708
    res = matcher.cascade_1_exact("57323708")
    assert res is not None
    master, stage, score = res
    assert stage in ["EXACT_OEM", "CROSS_NUMBER"]
    assert score == 1.0


def test_matcher_cascade_2_fuzzy_with_antonym_guard():
    """Каскад 2: не склеивает несовместимые детали при похожем названии."""
    matcher = CatalogMatcher(db_path=DB_PATH)
    # Ищем зеркало правое, в то время как в каталоге может быть только левое
    match, candidates = matcher.cascade_2_fuzzy("зеркало левое газель некст", raw_name="Зеркало правое ГАЗель Next")
    # Если в базе карточка левого зеркала — Antonym Guard не даст выдать её за правое с кодом FUZZY_NAME
    if match:
        assert "правое" not in match[0]["canonical_title"].lower() or "левое" not in match[0]["canonical_title"].lower()


def test_matcher_cache_persistence():
    """Проверка работы SQLite-кэша: повторный прогон берет данные из client_sku_mapping без API."""
    matcher = CatalogMatcher(db_path=DB_PATH, client_id="test_cache_client")
    test_df = pd.DataFrame([{
        "raw_code": "TEST-CACHE-001",
        "raw_name": "Колодки тормозные передние ГАЗель Бизнес",
        "raw_article": "3302-3501170",
        "stock_qty": 5.0,
        "price_retail": 1200.0
    }])

    # Первый прогон (сохранение в кэш)
    res1 = matcher.match_dataframe(test_df)
    assert res1["total_matched"] == 1
    assert res1["new_saved_count"] >= 1

    # Второй прогон (должен быть CACHE_HIT)
    res2 = matcher.match_dataframe(test_df)
    assert res2["total_matched"] == 1
    assert res2["stage_counts"]["CACHE_HIT"] == 1
    assert res2["new_saved_count"] == 0

    # Очистка тестовых данных
    conn = matcher.get_connection()
    conn.cursor().execute("DELETE FROM client_sku_mapping WHERE client_id = 'test_cache_client'")
    conn.commit()
    conn.close()


# =====================================================================
# 4. ТЕСТЫ ФИДОВ АВИТО И ДРОМ (МОДУЛЬ 3)
# =====================================================================

def test_feed_generator_title_word_boundary_50_chars():
    """Заголовок для Авито строго <= 50 символов и не режет слова посередине."""
    long_title = "Коробка передач (КПП) ГАЗ-3309, 33081 дизель 5-ступенчатая в сборе"
    short_title = clean_avito_title(long_title, max_len=50)

    assert len(short_title) <= 50
    assert not short_title.endswith(" ")
    assert not short_title.endswith("-")
    # Проверяем, что последнее слово не обрезано наполовину
    words = short_title.split()
    assert words[-1] in long_title


def test_feed_generator_xml_escape_and_control_chars():
    """Очистка XML от непечатаемых управляющих символов и экранирование спецсимволов."""
    dirty_text = "Колодки & диски <Next>\x00\x08\x1f \"Премиум\""
    sanitized = sanitize_xml_string(dirty_text)

    assert "\x00" not in sanitized
    assert "\x08" not in sanitized
    assert "\x1f" not in sanitized
    assert "&amp;" in sanitized
    assert "&lt;" in sanitized
    assert "&gt;" in sanitized
    assert "&quot;" in sanitized


def test_feed_generator_xml_schema_valid():
    """Сгенерированный XML-фид Авито успешно проходит синтаксический разбор ElementTree."""
    feed_path = os.path.join(PROJECT_ROOT, "avito_feed.xml")
    if not os.path.exists(feed_path):
        # Генерируем фид, если еще не создан
        gen = FeedGenerator(db_path=DB_PATH)
        df_1c, _ = detect_and_read_1c_file(SAMPLE_EXCEL)
        feed_data = gen.aggregate_and_filter(df_1c)
        feed_path = gen.generate_avito_xml(feed_data, feed_path)

    # Проверка разбора XML
    tree = ET.parse(feed_path)
    root = tree.getroot()
    assert root.tag == "Ads"
    assert root.attrib.get("target") == "Avito.ru"
    ads = root.findall("Ad")
    assert len(ads) > 0

    # Проверяем каждый заголовок
    for ad in ads:
        title = ad.find("Title").text
        assert len(title) <= 50
        stock = int(ad.find("Stock").text)
        assert stock >= 1
        price = int(ad.find("Price").text)
        assert price >= 300


def test_feed_generator_safety_filters():
    """Фильтры безопасности: отсеиваются позиции с остатком 0 и ценой < 300 руб."""
    gen = FeedGenerator(db_path=DB_PATH)
    fake_df = pd.DataFrame([
        {"Код": "00-001041", "Остаток": 0.0, "ЦенаРозница": 5000.0},  # 0 остаток
        {"Код": "00-002001", "Остаток": 5.0, "ЦенаРозница": 150.0},   # < 300 руб
        {"Код": "00-003002", "Остаток": 1.0, "ЦенаРозница": 92000.0}  # OK
    ])
    feed_data = gen.aggregate_and_filter(fake_df)

    assert len(feed_data["zero_stock_filtered"]) >= 1
    assert len(feed_data["cheap_filtered"]) >= 1
    # Только корректная позиция попала в фид
    feed_codes = [code for it in feed_data["feed_items"] for code in it["source_1c_codes"]]
    assert "00-003002" in feed_codes
    assert "00-001041" not in feed_codes
    assert "00-002001" not in feed_codes


def test_feed_generator_master_id_aggregation():
    """Агрегация нескольких дублей 1С в одну карточку master_id без дублирования."""
    gen = FeedGenerator(db_path=DB_PATH)
    # Насос ГУР 4216 представлен в 1С кодами 00-001041 (2 шт) и 00-001042 (2 шт)
    fake_df = pd.DataFrame([
        {"Код": "00-001041", "Остаток": 2.0, "ЦенаРозница": 6950.0},
        {"Код": "00-001042", "Остаток": 2.0, "ЦенаРозница": 7100.0}
    ])
    feed_data = gen.aggregate_and_filter(fake_df)

    assert feed_data["total_feed_skus"] == 1
    item = feed_data["feed_items"][0]
    assert item["total_stock"] == 4  # 2 + 2
    assert item["price_retail"] == 7100  # max розница
    assert set(item["source_1c_codes"]) == {"00-001041", "00-001042"}


# =====================================================================
# 5. ТЕСТЫ ИИ-ПРОДАВЦА (МОДУЛЬ 4)
# =====================================================================

def test_ai_sales_bot_overbooking_guard():
    """Защита от овербукинга: заказ 10 шт. при остатке 2 шт. возвращает INSUFFICIENT_STOCK."""
    bot = AISalesBot(db_path=DB_PATH, excel_path=SAMPLE_EXCEL)

    # Ищем деталь с остатком > 0
    res = bot.search_inventory("КПП дизель 3309")
    assert res["status"] in ["IN_STOCK", "FOUND_EXACT", "FOUND_SIMILAR"]
    master_id = res["top_match"]["master_id"]
    avail = res["top_match"]["total_stock"]

    # Пытаемся забронировать на 10 шт. больше доступного (в пределах лимита 100 шт.)
    overbook_res = bot.create_reservation(
        client_name="Тест Овербукинг",
        client_phone="+7 (999) 000-11-22",
        master_id=master_id,
        qty=int(avail) + 10
    )

    assert overbook_res["status"] == "INSUFFICIENT_STOCK"
    assert "доступно только" in overbook_res["customer_reply"]
    assert overbook_res["available_qty"] == int(avail)


def test_ai_sales_bot_sql_injection_defense():
    """Безопасность SQL: поисковый запрос со встроенной SQL-инъекцией не ломает базу."""
    bot = AISalesBot(db_path=DB_PATH, excel_path=SAMPLE_EXCEL)
    injection_query = "ГУР'; DROP TABLE master_catalog; --"

    # Поиск должен отработать без исключений и найти ГУР
    res = bot.search_inventory(injection_query)
    assert res["status"] in ["IN_STOCK", "FOUND_EXACT", "FOUND_SIMILAR", "OUT_OF_STOCK"]

    # Проверяем, что таблица master_catalog цела и невредима
    conn = bot.get_connection()
    c = conn.cursor()
    c.execute("SELECT count(*) FROM master_catalog")
    count = c.fetchone()[0]
    conn.close()
    assert count >= 10


def test_ai_sales_bot_escalation_guard():
    """Escalation Guard: запросы на нестандартный свап (2JZ / турбокит) перенаправляются агрегатчику."""
    bot = AISalesBot(db_path=DB_PATH, excel_path=SAMPLE_EXCEL)
    res = bot.search_inventory("Нужен комплект для свапа тойота 2JZ в ГАЗель")

    assert res["status"] == "ESCALATED_CUSTOM"
    assert res["lead_recorded"] is True
    assert "старшему мастеру-агрегатчику" in res["customer_reply"]


def test_ai_sales_bot_honest_out_of_stock():
    """Честный ответ при нулевом остатке: статус OUT_OF_STOCK и предложение привезти завтра к 10:00."""
    bot = AISalesBot(db_path=DB_PATH, excel_path=SAMPLE_EXCEL)
    # Ищем деталь, которой заведомо нет в наличии (или обнулена)
    res = bot.search_inventory("Стартер КЗАТЭ")
    # Проверяем логику честного ответа
    assert "customer_reply" in res
    assert len(res["customer_reply"]) > 20


# =====================================================================
# 6. ТЕСТЫ РАДАРА СОБСТВЕННИКА (МОДУЛЬ 5)
# =====================================================================

def test_owner_radar_zero_division_guard():
    """Защита от ZeroDivisionError при sales_12m == 0 в анализе склада."""
    radar = OwnerRadar(db_path=DB_PATH)
    shifts = radar.analyze_weekly_shifts()

    assert "metrics" in shifts
    assert "dead_stock_sales" in shifts
    assert "overbuy_alerts" in shifts
    assert "new_deficits" in shifts
    # Проверяем, что нет inf или NaN
    for k, v in shifts["metrics"].items():
        assert not pd.isna(v)
        assert v != float("inf")


def test_owner_radar_new_and_deleted_skus():
    """Outer join в радаре корректно обрабатывает новинки и удаленные позиции."""
    prev_rows = [
        {"Код": "SKU-001", "Наименование": "Старый товар", "Артикул": "001", "Остаток": 5.0, "ЦенаРозница": 1000.0, "ЦенаЗакупки": 700.0, "Продажи12мес": 10.0, "ДнейБезДвижения": 300}
    ]
    curr_rows = [
        {"Код": "SKU-002", "Наименование": "Абсолютно новый товар", "Артикул": "002", "Остаток": 3.0, "ЦенаРозница": 2000.0, "ЦенаЗакупки": 1400.0, "Продажи12мес": 0.0, "ДнейБезДвижения": 0}
    ]

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f1, tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f2:
        p1 = f1.name
        p2 = f2.name

    try:
        pd.DataFrame(prev_rows).to_excel(p1, index=False)
        pd.DataFrame(curr_rows).to_excel(p2, index=False)

        radar = OwnerRadar(prev_path=p1, curr_path=p2, db_path=DB_PATH)
        shifts = radar.analyze_weekly_shifts()

        assert shifts is not None
        assert "metrics" in shifts
    finally:
        for p in [p1, p2]:
            if os.path.exists(p):
                os.remove(p)


def test_owner_radar_financial_balance():
    """Проверка финансовых показателей: разморозка +193 800 ₽, перезакуп -42 100 ₽, ночной бот +15 650 ₽."""
    radar = OwnerRadar(db_path=DB_PATH)
    shifts = radar.analyze_weekly_shifts()

    metrics = shifts["metrics"]
    assert metrics["unfrozen_cash_rub"] == 193800.0
    assert metrics["overbuy_waste_rub"] == 42100.0
    assert metrics["night_bot_revenue_rub"] >= 15650.0
    expected_net = metrics["unfrozen_cash_rub"] + metrics["night_bot_revenue_rub"] - metrics["overbuy_waste_rub"]
    assert metrics["net_financial_impact_rub"] == expected_net
