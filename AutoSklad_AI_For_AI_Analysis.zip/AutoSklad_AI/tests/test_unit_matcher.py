"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_matcher.py
Тестирование модуля matcher.py (Каскадный матчер номенклатуры 1С):
- Каскад 1: точное совпадение по OEM и кросс-номерам с симметричными гомоглифами
- Каскад 2: нечеткое сопоставление по наименованию с фильтрацией AntonymGuard и KitGuard
- Каскад 3: автономный fallback-резолвер для спорных позиций
- Кэширование привязок в SQLite client_sku_mapping
- Пакетная обработка DataFrame и расчет метрик матчинга
"""

import os
import sqlite3
import pytest
import pandas as pd

from config import DB_PATH
from matcher import CatalogMatcher, clean_article, normalize_text


@pytest.fixture
def matcher():
    """Инициализация экземпляра CatalogMatcher для тестов с изолированным client_id."""
    import uuid
    client_id = f"test_unit_{uuid.uuid4().hex[:8]}"
    m = CatalogMatcher(db_path=DB_PATH, client_id=client_id)
    yield m
    # Очистка тестовых записей после теста
    try:
        conn = m.get_connection()
        conn.execute("DELETE FROM client_sku_mapping WHERE client_id = ?", (client_id,))
        conn.commit()
        conn.close()
    except Exception:
        pass


def test_matcher_init(matcher):
    """Проверка успешной загрузки эталонов и построения хэш-индексов."""
    assert len(matcher.master_records) > 0
    assert len(matcher.oem_index) > 0
    assert len(matcher.cross_index) > 0


def test_matcher_cascade1_exact_oem(matcher):
    """Каскад 1: Мгновенное сопоставление по эталонному OEM-номеру."""
    # Берем первый эталон с OEM
    master = matcher.master_records[0]
    clean_oem = clean_article(master["oem_number"])

    res = matcher.cascade_1_exact(clean_oem)
    assert res is not None
    matched_master, stage, score = res
    assert stage == "EXACT_OEM"
    assert score == 1.0
    assert matched_master["master_id"] == master["master_id"]


def test_matcher_cascade1_cross_numbers(matcher):
    """Каскад 1: Сопоставление по массиву кросс-номеров."""
    # Находим master_record, у которого есть хотя бы один кросс-номер
    master_with_cross = None
    target_cross = None
    for m in matcher.master_records:
        if m["cross_numbers"]:
            master_with_cross = m
            target_cross = m["cross_numbers"][0]
            break

    assert master_with_cross is not None
    clean_cross = clean_article(target_cross)
    res = matcher.cascade_1_exact(clean_cross)

    assert res is not None
    matched_master, stage, score = res
    assert stage in ["EXACT_OEM", "CROSS_NUMBER"]
    assert score == 1.0


def test_matcher_cascade1_homoglyphs_symmetry(matcher):
    """Каскад 1: Симметричное сопоставление латинских и кириллических двойников в артикуле."""
    # Тестируем на КПП ГАЗ-3309 (3309-1700010)
    cyr_art = clean_article("3309-1700010")
    lat_art = clean_article("3309-1700010")

    res1 = matcher.cascade_1_exact(cyr_art)
    res2 = matcher.cascade_1_exact(lat_art)

    assert res1 is not None
    assert res2 is not None
    assert res1[0]["master_id"] == res2[0]["master_id"]


def test_matcher_cascade1_empty_article(matcher):
    """Каскад 1: Пустой артикул возвращает None без падений."""
    assert matcher.cascade_1_exact("") is None
    assert matcher.cascade_1_exact(None) is None


def test_matcher_cascade2_fuzzy_title_match(matcher):
    """Каскад 2: Нечеткое сопоставление по наименованию (FUZZY_NAME)."""
    # Ищем КПП 3309 по близкому словесному названию
    norm_query = normalize_text("Коробка передач 5 ступ ГАЗ 3309 дизель")
    res, candidates = matcher.cascade_2_fuzzy(norm_query, raw_name="КПП ГАЗ-3309 дизель")

    assert res is not None or len(candidates) > 0
    if res:
        matched_master, stage, score = res
        assert stage == "FUZZY_NAME"
        assert score >= 0.88


def test_matcher_cascade2_blocked_by_antonym_guard(matcher):
    """Каскад 2: AntonymGuard блокирует неверную привязку при конфликте сторон (левый vs правый)."""
    # Запрос на левую фару не должен привязаться к правой
    norm_query = normalize_text("Фара левая ГАЗ-3302 Газель")
    # Проверяем фильтрацию
    for m in matcher.master_records:
        if "правая" in m["canonical_title"].lower():
            conf, _ = matcher.cascade_2_fuzzy(norm_query, raw_name="Фара левая ГАЗ-3302")
            if conf:
                # Ни в коем случае не правая фара
                assert "правая" not in conf[0]["canonical_title"].lower()


def test_matcher_cascade2_blocked_by_kit_guard(matcher):
    """Каскад 2: KitGuard блокирует склейку штучной детали с комплектом."""
    norm_query = normalize_text("Шкворень УАЗ 469 штука")
    res, candidates = matcher.cascade_2_fuzzy(norm_query, raw_name="Шкворень УАЗ 469 штука 1 шт")

    if res:
        title = res[0]["canonical_title"].lower()
        assert "комплект" not in title and "ремкомплект" not in title


def test_matcher_sqlite_caching_and_retrieval(matcher):
    """Сохранение сопоставлений в SQLite и последующее извлечение из кэша."""
    test_code = "TEST-RAW-CODE-001"
    sample_mapping = [{
        "raw_code": test_code,
        "raw_name": "Тестовая шестерня КПП",
        "clean_article": "33021701025",
        "master_id": "M-GAZ-3302-GEAR",
        "match_stage": "EXACT_OEM",
        "confidence_score": 1.0
    }]

    matcher.save_mappings_batch(sample_mapping)
    cached = matcher.get_cached_mappings()

    assert test_code in cached
    assert cached[test_code]["master_id"] == "M-GAZ-3302-GEAR"
    assert cached[test_code]["match_stage"] == "EXACT_OEM"


def test_matcher_match_dataframe_batch(matcher):
    """Пакетное сопоставление мини-DataFrame через match_dataframe."""
    df_input = pd.DataFrame([
        {
            "raw_code": "TC-01",
            "raw_name": "КПП ГАЗ-3309 дизель 5-ст",
            "raw_article": "3309-1700010",
            "clean_article": "33091700010"
        },
        {
            "raw_code": "TC-02",
            "raw_name": "Совершенно неизвестная деталь с марса",
            "raw_article": "UNKNOWN99999",
            "clean_article": "UNKNOWN99999"
        }
    ])

    summary = matcher.match_dataframe(df_input)
    assert summary["total_items"] == 2
    assert "results" in summary

    results = summary["results"]
    assert len(results) == 2

    # Первая позиция должна найтись по OEM
    row1 = next(r for r in results if r["raw_code"] == "TC-01")
    assert row1["match_stage"] == "EXACT_OEM"
    assert row1["master_id"] is not None

    # Вторая позиция должна быть UNMATCHED или fallback
    row2 = next(r for r in results if r["raw_code"] == "TC-02")
    assert row2["match_stage"] in ["UNMATCHED", "OFFLINE_HEURISTIC"]


def test_matcher_generate_html_report(matcher, tmp_path):
    """Генерация HTML-отчета матчера и проверка отсутствия старых имен."""
    match_data = {
        "total_items": 1,
        "total_matched": 1,
        "match_rate": 100.0,
        "stage_counts": {"CACHE_HIT": 0, "EXACT_OEM": 1, "CROSS_NUMBER": 0, "FUZZY_NAME": 0, "LLM_BATCH": 0, "OFFLINE_HEURISTIC": 0, "UNMATCHED": 0},
        "new_saved_count": 1,
        "results": [{
            "raw_code": "R-1",
            "raw_name": "Тестовая деталь",
            "raw_article": "3302",
            "clean_article": "3302",
            "stock_qty": 1,
            "price_retail": 1000,
            "master_id": "M-1",
            "match_stage": "EXACT_OEM",
            "confidence_score": 1.0,
            "is_from_cache": False,
            "master": matcher.master_records[0]
        }]
    }
    out_file = str(tmp_path / "test_match_report.html")
    generated = matcher.generate_html_report(match_data, out_file)
    assert os.path.exists(generated)
    with open(generated, "r", encoding="utf-8") as f:
        html_text = f.read()
    assert "Иван Иванович" not in html_text
    assert "ИИ-Матчер" in html_text


def test_matcher_cascade3_offline_heuristic_fallback(matcher, monkeypatch):
    """Каскад 3: Автономный эвристический резолвер при отсутствии LLM_API_KEY."""
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    items_to_resolve = [
        {
            "raw_code": "HEUR-01",
            "raw_name": "Шестерня КПП",
            "clean_article": "3302",
            "candidates": [(matcher.master_records[0], 75.0)]
        },
        {
            "raw_code": "HEUR-02",
            "raw_name": "Непонятная штуковина",
            "clean_article": "NONE",
            "candidates": [(matcher.master_records[0], 40.0)]
        }
    ]
    results = matcher.cascade_3_llm_batch(items_to_resolve)
    assert len(results) == 2
    assert results[0]["match_stage"] == "LLM_BATCH"
    assert results[0]["master_id"] is not None
    assert results[1]["match_stage"] == "UNMATCHED"
    assert results[1]["master_id"] is None
