"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_auditor.py
Тестирование модуля auditor.py (Аудитор склада 1С):
- Загрузка и валидация структуры данных
- Расчет ключевых KPI (замороженный капитал, упущенная выручка, себестоимость)
- Выявление скрытых дублей 1С и кластеров с риском перезакупа
- Классификация мертвого неликвида (> 270 дней / 0 продаж)
- Выявление дефицита ходовых позиций (out-of-stock)
- Экспорт JSON и HTML-отчетов
"""

import os
import json
import tempfile
import pytest
import pandas as pd

from config import SAMPLE_1C_PATH
from auditor import InventoryAuditor, clean_article, normalize_item_name

SAMPLE_EXCEL = str(SAMPLE_1C_PATH)


def test_auditor_init():
    """Инициализация аудитора с корректными начальными атрибутами."""
    auditor = InventoryAuditor("non_existent_file.xlsx")
    assert auditor.file_path == "non_existent_file.xlsx"
    assert auditor.df.empty
    assert auditor.summary == {}


def test_auditor_file_not_found():
    """Вызов load_data на несуществующем файле должен выбрасывать FileNotFoundError."""
    auditor = InventoryAuditor("missing_file_xyz_123.xlsx")
    with pytest.raises(FileNotFoundError):
        auditor.run_audit()


def test_auditor_run_audit_sample():
    """Успешный полный цикл аудита на базовом файле sample_1c_gaz_uaz.xlsx."""
    auditor = InventoryAuditor(SAMPLE_EXCEL)
    summary = auditor.run_audit()

    assert "kpi" in summary
    assert "duplicate_clusters" in summary
    assert "top_dead_stock" in summary
    assert "out_of_stock_items" in summary

    kpi = summary["kpi"]
    assert kpi["total_skus"] > 0
    assert kpi["total_cost_valuation"] > 0
    assert kpi["dead_capital_cost"] > 0
    assert kpi["duplicate_clusters_count"] > 0
    assert kpi["lost_monthly_revenue"] > 0


def test_auditor_dead_stock_logic():
    """Тест классификации неликвида: дни простоя > 270 и продажи = 0."""
    content = (
        "Код,Артикул,Наименование,Остаток,Цена,Себестоимость,Продажи12мес,ДнейБезДвижения\n"
        "D1,3302-DEAD1,Вал карданный старый,2,10000,7000,0,380\n"
        "D2,3302-ACT1,Колодки ходовые,10,1200,800,120,5\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        auditor = InventoryAuditor(temp_path)
        summary = auditor.run_audit()
        dead_list = summary["top_dead_stock"]

        assert len(dead_list) == 1
        assert dead_list[0]["raw_code"] == "D1"
        assert dead_list[0]["frozen_cost"] == 14000.0  # 2 * 7000
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_auditor_out_of_stock_logic():
    """Тест выявления дефицита: остаток <= 1 при наличии продаж за 12 мес."""
    content = (
        "Код,Артикул,Наименование,Остаток,Цена,Себестоимость,Продажи12мес,ДнейБезДвижения\n"
        "O1,3163-OOS,Стартер редукторный УАЗ,0,8000,5500,36,0\n"
        "O2,3163-OK,Генератор УАЗ,5,9000,6000,36,2\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        auditor = InventoryAuditor(temp_path)
        summary = auditor.run_audit()
        oos = summary["out_of_stock_items"]

        assert len(oos) == 1
        assert oos[0]["raw_code"] == "O1"
        assert oos[0]["avg_monthly_sales"] == 3.0  # 36 / 12
        assert oos[0]["lost_monthly_revenue"] == 24000.0  # 3 * 8000
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_auditor_duplicate_clusters_and_risk_overbuy():
    """Поиск дублей по артикулу и выставление флага risk_overbuy при дисбалансе остатков."""
    content = (
        "Код,Артикул,Наименование,Остаток,Цена,Себестоимость,Продажи12мес,ДнейБезДвижения\n"
        "DUP1,3302-1701025,Шестерня КПП Газель 1,0,2500,1800,10,30\n"
        "DUP2,3302-1701025,Шестерня КПП Газель 2,3,2500,1800,10,30\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        auditor = InventoryAuditor(temp_path)
        summary = auditor.run_audit()
        clusters = summary["duplicate_clusters"]

        assert len(clusters) >= 1
        cl = clusters[0]
        assert cl["count"] == 2
        assert cl["risk_overbuy"] is True
        assert cl["total_stock"] == 3.0
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_auditor_cost_fallback_72_percent():
    """Если цена закупки пустая или 0, применяется расчетный коэффициент себестоимости 72%."""
    content = (
        "Код,Артикул,Наименование,Остаток,Цена,Себестоимость,Продажи12мес,ДнейБезДвижения\n"
        "COST1,4216-01,Прокладка ГБЦ,10,1000,-,12,10\n"
    )
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
        f.write(content)
        temp_path = f.name

    try:
        auditor = InventoryAuditor(temp_path)
        summary = auditor.run_audit()
        row = auditor.df.iloc[0]
        assert row["price_cost"] == 720.0  # 1000 * 0.72
        assert row["total_cost_val"] == 7200.0
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_auditor_export_json(tmp_path):
    """Экспорт результатов аудита в валидный JSON-файл."""
    auditor = InventoryAuditor(SAMPLE_EXCEL)
    out_file = str(tmp_path / "test_summary.json")
    exported = auditor.export_json(out_file)

    assert os.path.exists(exported)
    with open(exported, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert "kpi" in data
    assert data["kpi"]["total_skus"] > 0


def test_auditor_export_html_report(tmp_path):
    """Генерация HTML-отчета с проверкой контактов и имени Вячеслава Юрьевича."""
    auditor = InventoryAuditor(SAMPLE_EXCEL)
    out_file = str(tmp_path / "test_report.html")
    exported = auditor.export_html_report(out_file)

    assert os.path.exists(exported)
    with open(exported, "r", encoding="utf-8") as f:
        html_text = f.read()

    assert "+7 (902) 802-82-46" in html_text
    assert "@dkazak1999" in html_text
    assert "Отчет ревизии складских остатков" in html_text
    assert "Иван Иванович" not in html_text


def test_auditor_normalize_item_name():
    """Тестирование нормализации автосленга (гбц, кпп, двс)."""
    assert "головка блока цилиндров" in normalize_item_name("ГБЦ 4216 под газ")
    assert "коробка передач" in normalize_item_name("Ремкомплект КПП ГАЗ-3302")


def test_auditor_incompatible_nodes_no_clustering():
    """Защита от ложных склеек: картер/колокол сцепления и диск сцепления никогда не объединяются."""
    rows = [
        {"Код": "C1", "Артикул": "3151-1601015", "Наименование": "Картер сцепления УАЗ Патриот", "Остаток": 2.0, "ЦенаРозница": 8500.0, "ЦенаЗакупки": 5500.0, "Продажи12мес": 1.0, "ДнейБезДвижения": 120},
        {"Код": "C2", "Артикул": "3151-1601130", "Наименование": "Диск сцепления УАЗ Патриот ведомый", "Остаток": 4.0, "ЦенаРозница": 3200.0, "ЦенаЗакупки": 2100.0, "Продажи12мес": 6.0, "ДнейБезДвижения": 40}
    ]
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        p = f.name
    try:
        pd.DataFrame(rows).to_excel(p, index=False)
        auditor = InventoryAuditor(p)
        auditor.load_data()
        clusters = auditor.find_duplicates()
        # Должно быть 0 кластеров дублей, так как детали принципиально разные
        assert len(clusters) == 0
    finally:
        if os.path.exists(p):
            os.remove(p)

    assert "двигатель" in normalize_item_name("Подушка ДВС Газель")
