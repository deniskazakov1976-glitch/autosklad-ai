"""
pytest configuration and shared fixtures for AutoSklad AI test suite.
Provides clean isolated SQLite database fixtures in tmp_path to prevent
any test pollution of the production master_catalog.db.
"""

import os
import sys
import shutil
import sqlite3
import pytest
from pathlib import Path

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import DB_PATH, BASE_DIR, SAMPLE_1C_PATH
from seed_master_catalog import init_database


@pytest.fixture
def isolated_db(tmp_path, monkeypatch):
    """
    Создает изолированную копию master_catalog.db в tmp_path.
    Все тесты работают с этой временной БД и никогда не загрязняют боевую БД.
    """
    test_db_path = str(tmp_path / "test_master_catalog.db")
    
    # Инициализируем структуру и эталоны
    init_database(test_db_path)
    
    # Копируем client_sku_mapping из боевой БД, если есть
    if os.path.exists(DB_PATH):
        src_conn = sqlite3.connect(DB_PATH)
        dst_conn = sqlite3.connect(test_db_path)
        try:
            mappings = src_conn.execute("SELECT * FROM client_sku_mapping").fetchall()
            if mappings:
                dst_conn.executemany(
                    "INSERT OR REPLACE INTO client_sku_mapping VALUES (?,?,?,?,?,?,?,?,?)",
                    mappings
                )
                dst_conn.commit()
        except Exception:
            pass
        finally:
            src_conn.close()
            dst_conn.close()
            
    # Подменяем пути в config и переменных окружения
    monkeypatch.setenv("AUTOSKLAD_DB_PATH", test_db_path)
    monkeypatch.setattr("config.DB_PATH", test_db_path)
    
    return test_db_path


@pytest.fixture
def clean_reservations_db(isolated_db):
    """
    Предоставляет изолированную БД с гарантированно очищенной таблицей броней.
    """
    conn = sqlite3.connect(isolated_db)
    conn.execute("DELETE FROM reservations")
    conn.commit()
    conn.close()
    return isolated_db
