"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_radar.py
Тестирование модуля owner_radar.py (Радар Собственника для Вячеслава Юрьевича):
- Анализ еженедельной динамики склада (4 ключевых бизнес-бакета)
- Разморозка старого неликвида через Авито/Дром (+193 800 ₽)
- Выявление неэффективного закупа и анти-откат (-42 100 ₽)
- Анализ рисков дефицита ходовых позиций (out-of-stock)
- Учет ночных продаж ИИ-продавца
- Обработка возвратов покупателей (sales_12m < 0) и дедупликация перед merge
- Форматирование Telegram-дайджеста и проверка брендинга собственника
"""

import os
import json
import tempfile
import pytest
import pandas as pd

from config import DB_PATH, WEEK_PREV_PATH, WEEK_CURR_PATH, BASE_DIR
from owner_radar import OwnerRadar, OWNER_NAME, SUPPORT_PHONE

PREV_PATH = str(WEEK_PREV_PATH)
CURR_PATH = str(WEEK_CURR_PATH)


@pytest.fixture
def radar():
    """Фикстура экземпляра OwnerRadar."""
    return OwnerRadar(prev_path=PREV_PATH, curr_path=CURR_PATH, db_path=str(DB_PATH))


def test_radar_init(radar):
    """Инициализация радара и загрузка метаданных эталонного каталога."""
    assert len(radar.master_records) > 0
    assert len(radar.mappings) > 0
    assert radar.prev_path == PREV_PATH
    assert radar.curr_path == CURR_PATH


def test_radar_analyze_weekly_shifts_buckets(radar):
    """Проверка формирования 4 бизнес-бакетов и расчета метрик."""
    summary = radar.analyze_weekly_shifts()

    assert "metrics" in summary
    assert "dead_stock_sales" in summary
    assert "overbuy_alerts" in summary
    assert "new_deficits" in summary
    assert "night_reservations" in summary

    m = summary["metrics"]
    assert m["unfrozen_cash_rub"] >= 190000.0
    assert m["overbuy_waste_rub"] >= 40000.0
    assert m["lost_revenue_risk_rub"] > 0
    assert m["night_bot_revenue_rub"] >= 15650.0
    expected_net = m["unfrozen_cash_rub"] + m["night_bot_revenue_rub"] - m["overbuy_waste_rub"]
    assert m["net_financial_impact_rub"] == expected_net


def test_radar_customer_returns_negative_sales():
    """Обработка возвратов клиентов (sales_12m < 0): demand не должен быть отрицательным."""
    df_p = pd.DataFrame([{
        "Код": "00-002004",
        "Артикул": "5702-3708",
        "Наименование": "Стартер КЗАТЭ",
        "Остаток": 2.0,
        "ЦенаРозница": 6850.0,
        "ЦенаЗакупки": 4500.0,
        "Продажи12мес": -5.0,  # Возврат в 1С
        "ДнейБезДвижения": 10
    }])
    df_c = pd.DataFrame([{
        "Код": "00-002004",
        "Артикул": "5702-3708",
        "Наименование": "Стартер КЗАТЭ",
        "Остаток": 0.0,
        "ЦенаРозница": 6850.0
    }])

    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fp:
        df_p.to_csv(fp.name, sep=";", index=False)
        p_path = fp.name
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fc:
        df_c.to_csv(fc.name, sep=";", index=False)
        c_path = fc.name

    try:
        r = OwnerRadar(prev_path=p_path, curr_path=c_path, db_path=DB_PATH)
        summary = r.analyze_weekly_shifts()
        # В дефицитах demand должен быть >= 0.0
        for item in summary["new_deficits"]:
            assert item["monthly_demand"] >= 0.0
            assert item["monthly_lost_revenue_rub"] >= 0.0
    finally:
        if os.path.exists(p_path):
            os.remove(p_path)
        if os.path.exists(c_path):
            os.remove(c_path)


def test_radar_zero_or_nan_price_fallback():
    """Если розничная цена 0 или NaN, применяется fallback себестоимость * 1.25."""
    df_p = pd.DataFrame([{
        "Код": "00-003002",
        "Артикул": "3309-1700010",
        "Наименование": "КПП ГАЗ-3309",
        "Остаток": 2.0,
        "ЦенаРозница": 0.0,  # Ошибочная нулевая розница
        "ЦенаЗакупки": 70000.0,
        "Продажи12мес": 0.0,
        "ДнейБезДвижения": 520
    }])
    df_c = pd.DataFrame([{
        "Код": "00-003002",
        "Артикул": "3309-1700010",
        "Наименование": "КПП ГАЗ-3309",
        "Остаток": 1.0,
        "ЦенаРозница": 0.0
    }])

    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fp:
        df_p.to_csv(fp.name, sep=";", index=False)
        p_path = fp.name
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fc:
        df_c.to_csv(fc.name, sep=";", index=False)
        c_path = fc.name

    try:
        r = OwnerRadar(prev_path=p_path, curr_path=c_path, db_path=DB_PATH)
        summary = r.analyze_weekly_shifts()
        assert len(summary["dead_stock_sales"]) == 1
        assert summary["dead_stock_sales"][0]["price_retail"] > 0
    finally:
        if os.path.exists(p_path):
            os.remove(p_path)
        if os.path.exists(c_path):
            os.remove(c_path)


def test_radar_deduplication_before_merge():
    """Строки с одинаковым кодом дедуплицируются перед слиянием, исключая декартово произведение."""
    df_p = pd.DataFrame([
        {"Код": "00-003002", "Артикул": "3309-1700010", "Наименование": "КПП 1", "Остаток": 2.0, "ЦенаРозница": 92000.0, "ЦенаЗакупки": 65000.0, "Продажи12мес": 0.0, "ДнейБезДвижения": 520},
        {"Код": "00-003002", "Артикул": "3309-1700010", "Наименование": "КПП дубль", "Остаток": 2.0, "ЦенаРозница": 92000.0, "ЦенаЗакупки": 65000.0, "Продажи12мес": 0.0, "ДнейБезДвижения": 520}
    ])
    df_c = pd.DataFrame([
        {"Код": "00-003002", "Артикул": "3309-1700010", "Наименование": "КПП 1", "Остаток": 1.0, "ЦенаРозница": 92000.0},
        {"Код": "00-003002", "Артикул": "3309-1700010", "Наименование": "КПП дубль", "Остаток": 1.0, "ЦенаРозница": 92000.0}
    ])

    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fp:
        df_p.to_csv(fp.name, sep=";", index=False)
        p_path = fp.name
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as fc:
        df_c.to_csv(fc.name, sep=";", index=False)
        c_path = fc.name

    try:
        r = OwnerRadar(prev_path=p_path, curr_path=c_path, db_path=DB_PATH)
        summary = r.analyze_weekly_shifts()
        # Должен быть ровно один элемент, а не 4
        assert len(summary["dead_stock_sales"]) == 1
    finally:
        if os.path.exists(p_path):
            os.remove(p_path)
        if os.path.exists(c_path):
            os.remove(c_path)


def test_radar_telegram_digest_formatting(radar):
    """Форматирование утреннего дайджеста для Telegram: Вячеслав Юрьевич и Пермь."""
    summary = radar.analyze_weekly_shifts()
    digest = radar.generate_telegram_digest(summary)

    assert "РАДАР СОБСТВЕННИКА" in digest
    assert "Вячеслав Юрьевич" in digest
    assert "Иван Иванович" not in digest
    assert "194 800" in digest or "194,800" in digest or "193 800" in digest
    assert "52 600" in digest or "52,600" in digest or "42 100" in digest
    assert "+7 (902) 802-82-46" in digest


def test_radar_run_radar_export(radar, tmp_path):
    """Запуск полного цикла run_radar() с экспортом файлов в изолированную директорию."""
    export_dir = str(tmp_path / "radar_export")
    summary = radar.run_radar(output_dir=export_dir)
    assert summary is not None
    assert os.path.exists(os.path.join(export_dir, "radar_summary.json"))
    assert os.path.exists(os.path.join(export_dir, "telegram_digest.txt"))
