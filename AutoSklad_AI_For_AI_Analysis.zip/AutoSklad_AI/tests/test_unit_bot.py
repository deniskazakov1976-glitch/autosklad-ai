"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_bot.py
Тестирование модуля ai_sales_bot.py (ИИ-Продавец чатов Авито / WhatsApp):
- RAG-поиск по остаткам (OEM, кроссы, автосленг ГАЗ/УАЗ)
- Zero Hallucination: честный ответ OUT_OF_STOCK при нулевом остатке
- Escalation Guard: перехват нестандартных свапов (1JZ/2JZ) с фиксацией лида
- Валидация количества (qty <= 0, qty > 100, не-числа -> INVALID_QTY)
- Защита от овербукинга (INSUFFICIENT_STOCK)
- Параметризованная защита от SQL-инъекций в SQLite
"""

import os
import sqlite3
import pytest

from ai_sales_bot import AISalesBot

DB_PATH = "F:/AutoSklad_AI/master_catalog.db"
SAMPLE_EXCEL = "F:/AutoSklad_AI/sample_1c_gaz_uaz.xlsx"


@pytest.fixture
def bot():
    """Фикстура экземпляра AISalesBot."""
    return AISalesBot(db_path=DB_PATH, excel_path=SAMPLE_EXCEL)


def test_bot_init(bot):
    """Инициализация бота, базы данных и загрузка каталога остатков."""
    assert len(bot.inventory) > 0


def test_bot_search_exact_oem(bot):
    """Поиск по точному каталожному номеру (OEM)."""
    res = bot.search_inventory("3309-1700010")
    assert res["status"] in ["IN_STOCK", "FOUND_EXACT", "FOUND_SIMILAR"]
    assert res["top_match"] is not None
    assert "3309" in res["top_match"]["oem_number"]


def test_bot_search_slang_gur(bot):
    """Поиск по сленговому запросу 'гур на патриот'."""
    res = bot.search_inventory("гур на патриот")
    assert res["status"] in ["IN_STOCK", "FOUND_EXACT", "FOUND_SIMILAR"]
    assert res["top_match"] is not None
    top_title = res["top_match"]["canonical_title"].lower()
    assert "рул" in top_title or "насос" in top_title or "гур" in top_title


def test_bot_search_slang_sztcepa(bot):
    """Поиск по сленговому запросу 'сцепа 4216'."""
    res = bot.search_inventory("сцепа 4216")
    assert res["status"] in ["IN_STOCK", "OUT_OF_STOCK", "FOUND_EXACT", "FOUND_SIMILAR"]
    assert res["top_match"] is not None
    top_title = res["top_match"]["canonical_title"].lower()
    assert "сцеплен" in top_title or "диск" in top_title or "корзин" in top_title


def test_bot_search_zero_stock_truth(bot):
    """Zero Hallucination: деталь с нулевым остатком честно возвращает OUT_OF_STOCK."""
    # Искусственно ищем позицию с total_stock == 0
    zero_stock_item = None
    for item in bot.inventory.values():
        if item["total_stock"] == 0:
            zero_stock_item = item
            break

    if zero_stock_item:
        res = bot.search_inventory(zero_stock_item["oem_number"])
        assert res["status"] == "OUT_OF_STOCK"
        assert "PASSED" in res["anti_hallucination"]
        assert "под заказ" in res["customer_reply"] or "0 шт" in res["customer_reply"] or "нет в наличии" in res["customer_reply"]


def test_bot_search_not_found(bot):
    """Запрос несуществующей детали возвращает статус NOT_FOUND и предложение уточнить VIN."""
    res = bot.search_inventory("космический генератор антигравитации змз-999")
    assert res["status"] == "NOT_FOUND"
    assert "не найдено" in res["customer_reply"]
    assert "VIN" in res["customer_reply"] or "номер" in res["customer_reply"]


def test_bot_escalation_guard_swaps(bot):
    """Escalation Guard: запросы на свап (1JZ/2JZ) перенаправляются на старшего мастера."""
    res = bot.search_inventory("хочу сделать свап 1jz в газель соболь")
    assert res["status"] in ["ESCALATION_TRIGGERED", "ESCALATED_CUSTOM"]
    assert res["lead_recorded"] is True
    assert "старшему мастеру" in res["customer_reply"]
    assert "Toyota 1JZ/2JZ" in res["customer_reply"]


def test_bot_create_reservation_invalid_qty(bot):
    """Валидация количества: отклонение неположительных, оптовых > 100 и строковых qty."""
    # Берем любую позицию из инвентаря
    master_id = list(bot.inventory.keys())[0]

    # qty <= 0
    res_zero = bot.create_reservation("Тест", "+79991112233", master_id, qty=0)
    assert res_zero["status"] == "INVALID_QTY"

    res_neg = bot.create_reservation("Тест", "+79991112233", master_id, qty=-3)
    assert res_neg["status"] == "INVALID_QTY"

    # qty > 100
    res_huge = bot.create_reservation("Тест", "+79991112233", master_id, qty=101)
    assert res_huge["status"] == "INVALID_QTY"

    # Невалидные типы
    res_str = bot.create_reservation("Тест", "+79991112233", master_id, qty="два")
    assert res_str["status"] == "INVALID_QTY"

    res_none = bot.create_reservation("Тест", "+79991112233", master_id, qty=None)
    assert res_none["status"] == "INVALID_QTY"


def test_bot_create_reservation_insufficient_stock(bot):
    """Защита от овербукинга: заказ количества больше доступного остатка возвращает INSUFFICIENT_STOCK."""
    # Находим позицию с остатком от 1 до 5 шт.
    target = None
    for item in bot.inventory.values():
        if 1 <= item["total_stock"] <= 10:
            target = item
            break

    assert target is not None
    avail = int(target["total_stock"])
    res = bot.create_reservation("Тест Овербук", "+79028028246", target["master_id"], qty=avail + 5)

    assert res["status"] == "INSUFFICIENT_STOCK"
    assert "доступно только" in res["customer_reply"]
    assert res["available_qty"] == avail


def test_bot_create_reservation_success_and_sql_injection(bot):
    """Успешное создание брони и защита от SQL-инъекций в полях имени и телефона."""
    # Находим деталь с остатком >= 1
    target = None
    for item in bot.inventory.values():
        if item["total_stock"] >= 1:
            target = item
            break

    assert target is not None

    injection_name = "Вячеслав'; DROP TABLE reservations; --"
    res = bot.create_reservation(
        client_name=injection_name,
        client_phone="+7 (902) 802-82-46",
        master_id=target["master_id"],
        qty=1
    )

    assert res["status"] == "CONFIRMED"
    assert "res_id" in res

    # Проверяем, что таблица reservations цела и запись добавлена корректно
    conn = bot.get_connection()
    c = conn.cursor()
    saved = c.execute("SELECT client_name FROM reservations WHERE res_id = ?", (res["res_id"],)).fetchone()
    conn.close()

    assert saved is not None
    assert saved["client_name"] == injection_name


def test_bot_process_message_search_and_reservation(bot):
    """Тест диспетчера сообщений: автоматическое распознавание интентов поиска и брони."""
    # 1. Поисковый интент
    search_msg = "Здравствуйте, подскажите наличие редуктора на Газель"
    res1 = bot.process_message(search_msg)
    assert res1["tool_called"] == "search_inventory"
    assert "execution" in res1

    # 2. Интент бронирования с извлечением имени и телефона
    reserve_msg = "Забронируйте стартер редукторный на завтра. Меня зовут Денис, телефон 89028028246"
    res2 = bot.process_message(reserve_msg)
    assert res2["tool_called"] == "create_reservation"
    assert res2["telegram_alert"] is not None


def test_bot_benchmark_suite(bot):
    """Прогон полного набора из 5 эталонных диалогов benchmark_tests."""
    results = bot.run_benchmark_tests()
    assert len(results) == 5
    for r in results:
        assert r["passed"] is True, f"Тест '{r['test_name']}' не пройден: {r}"
