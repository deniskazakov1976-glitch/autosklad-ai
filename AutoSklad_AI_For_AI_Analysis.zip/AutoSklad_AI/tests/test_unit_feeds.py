"""
МОДУЛЬНЫЕ ЮНИТ-ТЕСТЫ: tests/test_unit_feeds.py
Тестирование модуля feed_generator.py (Генератор товарных фидов Авито и Дром):
- Дедупликация и склейка остатков 1С по master_id (Single Stock Truth)
- Защита маржинальности MarginFloorGuard (запрет продажи в минус, пол себестоимости +10% и +5%)
- Фильтрация нулевых остатков (stock < 1) и нерентабельной мелочевки (< 300 ₽)
- Строгая валидация XML-схемы Авито и длины заголовков (Title <= 50)
- Валидация формата CSV Базы.Дром
- Генерация витрины предпросмотра feeds_preview.html
"""

import os
import tempfile
import xml.etree.ElementTree as ET
import pytest
import pandas as pd

from config import DB_PATH, SAMPLE_1C_PATH
from feed_generator import FeedGenerator
from inventory_guard import detect_and_read_1c_file

SAMPLE_EXCEL = str(SAMPLE_1C_PATH)


@pytest.fixture
def generator():
    """Фикстура экземпляра FeedGenerator с боевым client_id = 'client_main'."""
    return FeedGenerator(db_path=str(DB_PATH), client_id="client_main")


@pytest.fixture
def sample_df():
    """Загрузка базового DataFrame 1С."""
    df, _ = detect_and_read_1c_file(SAMPLE_EXCEL)
    return df


def test_feed_generator_init(generator):
    """Инициализация генератора фидов и загрузка каталога."""
    assert len(generator.master_records) > 0


def test_feed_aggregation_single_stock_truth(generator, sample_df):
    """Суммирование остатков дублей 1С по master_id и фиксация source_1c_codes."""
    data = generator.aggregate_and_filter(sample_df)
    items = data["feed_items"]

    assert len(items) > 0
    # Находим карточку, у которой несколько исходных кодов 1С (дубли)
    multi_code_items = [it for it in items if len(it["source_1c_codes"]) > 1]
    assert len(multi_code_items) > 0

    first_multi = multi_code_items[0]
    assert first_multi["total_stock"] >= 1.0
    assert len(first_multi["source_1c_codes"]) >= 2


def test_feed_margin_floor_guard_normal(generator, sample_df):
    """При нормальной розничной цене MarginFloorGuard не занижает цену."""
    data = generator.aggregate_and_filter(sample_df)
    for it in data["feed_items"]:
        assert it["price_retail"] >= it["price_cost"]


def test_feed_margin_floor_guard_prevent_loss(generator):
    """Тест защиты от продажи в минус: розница ниже себестоимости поднимается до cost * 1.10."""
    # Создаем DataFrame с ошибочной ценой розницы 500 ₽ при закупке 1000 ₽
    # 00-001041 привязан к M-GAZ-3302-GEAR
    df_err = pd.DataFrame([{
        "Код": "00-001041",
        "Артикул": "3302-1701025",
        "Наименование": "Шестерня КПП Газель",
        "Остаток": 2.0,
        "ЦенаРозница": 500.0,
        "ЦенаЗакупки": 1000.0,
        "Продажи12мес": 10.0,
        "ДнейБезДвижения": 30
    }])

    data = generator.aggregate_and_filter(df_err)
    items = data["feed_items"]
    assert len(items) >= 1
    item = items[0]
    # Цена должна быть скорректирована как минимум до 1000 * 1.10 = 1100 ₽
    assert item["price_retail"] >= 1100
    assert item["margin_guard_triggered"] is True


def test_feed_zero_stock_and_cheap_filtering(generator):
    """Фильтрация позиций с нулевым остатком и ценой < 300 ₽."""
    df_filter = pd.DataFrame([
        {
            "Код": "00-001041",
            "Артикул": "3302-1701025",
            "Наименование": "Шестерня КПП",
            "Остаток": 0.0,
            "ЦенаРозница": 2500.0,
            "ЦенаЗакупки": 1800.0,
            "Продажи12мес": 10.0,
            "ДнейБезДвижения": 30
        },
        {
            "Код": "00-003001",
            "Артикул": "3302-2402010",
            "Наименование": "Редуктор дешевый",
            "Остаток": 2.0,
            "ЦенаРозница": 150.0,
            "ЦенаЗакупки": 80.0,
            "Продажи12мес": 5.0,
            "ДнейБезДвижения": 5
        }
    ])

    data = generator.aggregate_and_filter(df_filter)
    assert len(data["feed_items"]) == 0
    assert len(data["zero_stock_filtered"]) >= 1
    assert len(data["cheap_filtered"]) >= 1


def test_feed_avito_xml_structure_and_elementtree(generator, sample_df, tmp_path):
    """Генерация Avito XML и строгая валидация структуры через xml.etree.ElementTree."""
    feed_data = generator.aggregate_and_filter(sample_df)
    out_xml = str(tmp_path / "test_avito.xml")
    xml_path = generator.generate_avito_xml(feed_data, out_xml)

    assert os.path.exists(xml_path)

    # Парсинг XML
    tree = ET.parse(xml_path)
    root = tree.getroot()
    assert root.tag == "Ads"
    assert root.attrib.get("formatVersion") == "3"

    ads = root.findall("Ad")
    assert len(ads) == len(feed_data["feed_items"])

    for ad in ads:
        assert ad.find("Id") is not None
        assert ad.find("Title") is not None
        assert ad.find("Price") is not None
        assert ad.find("Stock") is not None
        assert float(ad.find("Stock").text) >= 1.0
        assert float(ad.find("Price").text) >= 300.0


def test_feed_avito_title_length_limit(generator, sample_df, tmp_path):
    """Все заголовки <Title> в XML Авито строго <= 50 символов."""
    feed_data = generator.aggregate_and_filter(sample_df)
    out_xml = str(tmp_path / "test_avito_titles.xml")
    xml_path = generator.generate_avito_xml(feed_data, out_xml)

    tree = ET.parse(xml_path)
    for title_node in tree.getroot().iter("Title"):
        title_text = title_node.text or ""
        assert len(title_text) <= 50, f"Заголовок '{title_text}' превышает 50 символов ({len(title_text)})"


def test_feed_drom_csv_structure(generator, sample_df, tmp_path):
    """Генерация CSV-фида для Дром и проверка структуры колонок."""
    feed_data = generator.aggregate_and_filter(sample_df)
    out_csv = str(tmp_path / "test_drom.csv")
    csv_path = generator.generate_drom_csv(feed_data, out_csv)

    assert os.path.exists(csv_path)

    df_drom = pd.read_csv(csv_path, sep=";")
    assert "Артикул (OEM)" in df_drom.columns
    assert "Наименование" in df_drom.columns
    assert "Цена" in df_drom.columns
    assert "Наличие (шт)" in df_drom.columns
    assert len(df_drom) == len(feed_data["feed_items"])


def test_feed_preview_html_generation(generator, sample_df, tmp_path):
    """Генерация витрины предпросмотра feeds_preview.html."""
    feed_data = generator.aggregate_and_filter(sample_df)
    out_html = str(tmp_path / "test_feeds_preview.html")
    html_path = generator.generate_preview_html(feed_data, out_html)

    assert os.path.exists(html_path)
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    assert "Витрина объявлений Авито и Дром" in html_content
    assert "Иван Иванович" not in html_content


def test_feed_unmatched_rows_tracking(generator):
    """Строки без привязки к master_id фиксируются в unmatched_rows."""
    df_unmatched = pd.DataFrame([{
        "Код": "UNKNOWN-999",
        "Артикул": "ART-999",
        "Наименование": "Неизвестная деталь",
        "Остаток": 5.0,
        "ЦенаРозница": 1000.0,
        "ЦенаЗакупки": 700.0,
        "Продажи12мес": 0.0,
        "ДнейБезДвижения": 0
    }])
    data = generator.aggregate_and_filter(df_unmatched)
    assert len(data["unmatched_rows"]) == 1
    assert data["unmatched_rows"][0]["raw_code"] == "UNKNOWN-999"


def test_feed_promo_price_floor_cap(generator):
    """Промо-цена на неликвид не может опускаться ниже 105% себестоимости."""
    # Создаем позицию с неликвидом: цена 1080 ₽, себестоимость 1000 ₽.
    # 10% скидка дала бы 972 ₽, что ниже 1050 ₽ (105% себестоимости).
    # MarginFloorGuard обязан поднять промо-цену до ceil(1000 * 1.05) = 1050 ₽.
    df_promo = pd.DataFrame([{
        "Код": "00-001041",
        "Артикул": "3302-1701025",
        "Наименование": "Шестерня КПП Газель",
        "Остаток": 2.0,
        "ЦенаРозница": 1080.0,
        "ЦенаЗакупки": 1000.0,
        "Продажи12мес": 0.0,
        "ДнейБезДвижения": 300
    }])
    data = generator.aggregate_and_filter(df_promo)
    assert len(data["feed_items"]) == 1
    item = data["feed_items"][0]
    assert item["is_dead_stock"] is True
    assert item["promo_price"] == 1050
    assert item["margin_guard_triggered"] is True
