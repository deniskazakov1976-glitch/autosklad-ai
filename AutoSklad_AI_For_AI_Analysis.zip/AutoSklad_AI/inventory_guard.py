"""
МОДУЛЬ БЕЗОПАСНОСТИ И ВАЛИДАЦИИ ДАННЫХ 1С: inventory_guard.py
Платформа «АВТОСКЛАД-ИИ»

Ключевые защитные механизмы:
1. detect_and_read_1c_file(): автоматический пропуск метаданных шапки 1С (строки 1-25),
   поддержка кодировок (utf-8-sig, utf-8, cp1251, cp866) и разделителей (;, tab, ,),
   приоритетный выбор «Конечный остаток» (вместо «Начальный остаток»),
   агрегация остатков мульти-складов («Склад 1» + «Склад 2»),
   отсечение строк «Итого»/папок, безопасный парсинг строковых чисел и логирование отрицательных остатков.
2. clean_article(): абсолютно симметричная нормализация артикулов (CYR <-> LAT homoglyphs).
3. AntonymGuard + KitGuard: защита от склеек несовместимых запчастей:
   - Стороны: левый vs правый
   - Оси: передний vs задний
   - Положения: верхний vs нижний, внутренний vs наружный, впуск vs выпуск
   - Ремонтные размеры: стд vs 0.25 vs 0.5 vs 0.75 vs 1.0
   - Моторы: 402 vs 405/406 vs 4216 vs Cummins vs Evotech
   - Комплектация (KitGuard): штука vs комплект / ремкомплект / набор
4. sanitize_xml_string() и clean_avito_title(): обрезка заголовка по границе слова (<= 50 символов),
   экранирование и удаление непечатаемых управляющих символов XML [\\x00-\\x1f].
5. safe_json_dumps(): XSS-защищенная сериализация JSON для встраивания в тег <script>.
"""

import os
import re
import json
import html
from typing import Dict, List, Any, Optional, Tuple, Set
import pandas as pd


# =====================================================================
# 1. СИММЕТРИЧНАЯ НОРМАЛИЗАЦИЯ АРТИКУЛОВ
# =====================================================================
CYR_TO_LAT = {
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'К': 'K', 'М': 'M',
    'Н': 'H', 'О': 'O', 'Р': 'P', 'Т': 'T', 'Х': 'X', 'У': 'Y'
}

def clean_article(val: Any) -> str:
    """
    Симметричная нормализация артикула:
    - приводит к верхнему регистру;
    - удаляет любые пробелы, тире, точки, слеши, запятые, знаки подчеркивания;
    - транслитерирует кириллические буквы-двойники в латиницу (A, B, C, E, K, M, H, O, P, T, X, Y);
    - удаляет невидимые управляющие символы.
    """
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip().upper()
    s = re.sub(r"[-./\s_,\\]", "", s)
    res = [CYR_TO_LAT.get(ch, ch) for ch in s]
    return "".join(res)


# =====================================================================
# 2. ПАРСЕР ЧИСЕЛ ИЗ 1С
# =====================================================================
def parse_1c_number(val: Any, default: float = 0.0) -> float:
    """
    Безопасно переводит строковые и числовые значения 1С во float:
    - '12 400,50' -> 12400.5
    - '1\xa0250,00' (неразрывный пробел) -> 1250.0
    - '-' или '' или None -> default (0.0)
    """
    if val is None or pd.isna(val):
        return default
    if isinstance(val, (int, float)):
        return float(val)

    s = str(val).strip()
    if not s or s == "-":
        return default

    # Удаляем неразрывные и обычные пробелы, апострофы
    s = s.replace("\xa0", "").replace(" ", "").replace("'", "")
    # Заменяем запятую на точку
    s = s.replace(",", ".")

    try:
        return float(s)
    except (ValueError, TypeError):
        return default


# =====================================================================
# 3. МЕТАДАННЫЕ И ЧТЕНИЕ ФАЙЛОВ 1С (МУЛЬТИ-КОДИРОВКИ И ОСТАТКИ)
# =====================================================================
COLUMN_HEADER_KEYWORDS = {
    "raw_code": ["код", "код номенклатуры", "код_номенклатуры", "id", "код товара", "артикулкод"],
    "raw_name": ["наименование", "номенклатура", "наименование товара", "товар", "название"],
    "raw_article": ["артикул", "номер", "код производителя", "артикул производителя", "оем"],
    "stock_qty": [
        "конечный остаток", "остаток на конец", "остаток конечный",
        "текущий остаток", "остаток склад", "остаток", "количество", "склад", "ост"
    ],
    "price_retail": ["цена", "ценарозница", "розничная", "цена продажи", "розница", "цена розничная"],
    "price_cost": ["себестоимость", "ценазакупки", "закупочная", "цена закупки", "закупка", "цена входная"],
    "sales_12m": ["расход", "продажи12мес", "продажи", "расход за 12 мес", "продажи за год", "отгрузка за 12 мес", "отгрузка", "продано"],
    "days_no_movement": ["днейбездвижения", "дней без движения", "дней без продаж", "простой", "дней простоя"]
}

TOTAL_ROW_PATTERNS = [
    r"^\s*итого\b", r"^\s*всего\b", r"^\s*итого\s+по\s+складу\b"
]


def sanitize_csv_formula(val: Any) -> str:
    """
    Экранирует опасные лидирующие символы формул для CSV/Excel (=, +, -, @, tab, cr).
    Предотвращает CSV Formula Injection (CWE-1236).
    """
    if val is None or pd.isna(val):
        return ""
    s = str(val)
    if s and s[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + s
    return s


def validate_safe_path(filepath: str) -> str:
    """
    Валидирует путь к файлу, защищая от null-byte и Path Traversal.
    """
    if "\x00" in str(filepath):
        raise ValueError("Обнаружен запрещенный null-byte в пути файла.")
    return os.path.abspath(str(filepath))


def detect_and_read_1c_file(
    file_path_or_df: Any,
    max_header_scan_rows: int = 25
) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    """
    Загружает файл Excel или CSV/TSV от 1С:
    - Поддерживает кодировки utf-8-sig, utf-8, cp1251, cp866 и разделители ;, tab, ,
    - Находит строку заголовков в первых max_header_scan_rows строках.
    - Приоритетно выбирает «Конечный остаток» (игнорирует «Начальный остаток»).
    - Умеет суммировать остатки по нескольким складам (например «Остаток Магазин 1» + «Остаток Магазин 2»).
    - Отсекает строки 'Итого', папки иерархии и пустые строки.
    - Корректно парсит числа со строковыми пробелами и запятыми.
    - Выявляет и логирует отрицательные остатки (пересортица), обнуляя их для витрин.
    Возвращает (очищенный DataFrame, список аномалий).
    """
    anomalies: List[Dict[str, Any]] = []

    if isinstance(file_path_or_df, pd.DataFrame):
        raw_df = file_path_or_df.copy()
    else:
        file_path = str(file_path_or_df)
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Файл 1С не найден: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()
        if ext in [".xlsx", ".xls"]:
            raw_df = pd.read_excel(file_path, header=None)
        elif ext in [".csv", ".txt", ".tsv"]:
            raw_df = None
            encodings = ["utf-8-sig", "utf-8", "cp866", "cp1251"]
            delimiters = [";", "\t", ","]
            best_candidate = None
            best_score = -1

            for enc in encodings:
                for sep in delimiters:
                    try:
                        temp_df = pd.read_csv(file_path, header=None, sep=sep, encoding=enc, dtype=str)
                        if temp_df.shape[1] > 1:
                            # Оцениваем осмысленность русского текста и ключевых слов 1С
                            sample_text = " ".join(
                                str(x) for x in temp_df.iloc[:min(25, len(temp_df))].values.flatten() if pd.notna(x)
                            ).lower()
                            score = 0
                            for kw in ["наименование", "номенклатура", "остаток", "артикул", "код", "цена", "склад", "количество"]:
                                if kw in sample_text:
                                    score += 20
                            cyrillic_count = len(re.findall(r"[а-яё]", sample_text))
                            score += min(cyrillic_count, 50)
                            if score > best_score:
                                best_score = score
                                best_candidate = temp_df
                    except Exception:
                        continue
            raw_df = best_candidate
            if raw_df is None:
                # Резервная загрузка
                raw_df = pd.read_csv(file_path, header=None, sep=",", encoding="utf-8", encoding_errors="replace")
        else:
            raise ValueError(f"Неподдерживаемый формат: {ext}")

    # 1. Поиск строки заголовков
    header_row_idx = 0
    found_header = False

    for idx in range(min(max_header_scan_rows, len(raw_df))):
        row_values = [str(v).strip().lower() for v in raw_df.iloc[idx].values if pd.notna(v) and str(v).strip()]
        # Строка заголовков таблицы обязательно имеет как минимум 3 непустые ячейки (в отличие от метаданных A1)
        if len(row_values) < 3:
            continue

        matched_targets = set()
        for val in row_values:
            if len(val) > 80:
                continue
            for target_col, aliases in COLUMN_HEADER_KEYWORDS.items():
                if any(val == alias or (alias in val and len(val) <= 80) for alias in aliases):
                    matched_targets.add(target_col)

        # Если в строке найдено как минимум 2 целевых поля, включая наименование или остаток
        if len(matched_targets) >= 2 and any(k in matched_targets for k in ["raw_name", "stock_qty"]):
            header_row_idx = idx
            found_header = True
            break

    if found_header:
        headers = [str(v).strip() for v in raw_df.iloc[header_row_idx].values]
        df = raw_df.iloc[header_row_idx + 1:].copy()
        df.columns = headers
    else:
        df = raw_df.copy()
        if not isinstance(df.columns[0], str):
            df.columns = [str(c).strip() for c in df.iloc[0].values]
            df = df.iloc[1:].copy()

    df = df.reset_index(drop=True)

    # 2. Умный маппинг колонок (с защитой от «Начальный остаток» и поддержкой мульти-склада)
    col_map = {}
    multi_stock_cols = []

    # Сначала проверяем наличие колонок остатка
    stock_assigned = False

    # Шаг 2.1: Ищем приоритетные колонки конечного остатка
    for col in df.columns:
        c_clean = str(col).strip().lower()
        # Игнорируем начальный остаток
        if "начальн" in c_clean or "на начало" in c_clean:
            continue

        if any(term in c_clean for term in ["конечный остаток", "остаток на конец", "остаток конечный", "текущий остаток"]):
            col_map[col] = "stock_qty"
            stock_assigned = True
            break

    # Шаг 2.2: Проверяем наличие нескольких колонок складов (мульти-склад)
    if not stock_assigned:
        for col in df.columns:
            c_clean = str(col).strip().lower()
            if "начальн" in c_clean or "на начало" in c_clean:
                continue
            if (
                re.search(r"остаток\s+(?:склад|магаз|тц|филиал|\d+|\w+)", c_clean) or
                re.search(r"(?:склад|магаз|филиал)\s*(?:\d+|\b(?:центр|запад|восток|север|основной|опт|розница)\b)", c_clean) or
                re.search(r"^склад\s+", c_clean)
            ):
                multi_stock_cols.append(col)

        if len(multi_stock_cols) >= 2:
            # Будет выполнено суммирование позже
            pass
        elif len(multi_stock_cols) == 1:
            col_map[multi_stock_cols[0]] = "stock_qty"
            stock_assigned = True

    # Шаг 2.3: Стандартный маппинг остальных колонок
    for col in df.columns:
        if col in col_map:
            continue
        c_clean = str(col).strip().lower()

        # Защита от "Начальный остаток" и "Приход"
        if "начальн" in c_clean or "на начало" in c_clean:
            continue
        if c_clean in ["приход", "поступление"] and "sales_12m" not in col_map.values():
            continue

        for target, aliases in COLUMN_HEADER_KEYWORDS.items():
            if target == "stock_qty" and stock_assigned:
                continue
            if c_clean in aliases:
                col_map[col] = target
                if target == "stock_qty":
                    stock_assigned = True
                break

    df = df.rename(columns=col_map)

    # Шаг 2.4: Если определен мульти-склад, суммируем колонки в единый stock_qty
    if len(multi_stock_cols) >= 2 and "stock_qty" not in df.columns:
        df["stock_qty"] = 0.0
        for m_col in multi_stock_cols:
            df["stock_qty"] += df[m_col].apply(lambda v: parse_1c_number(v, 0.0))

    # Убеждаемся, что ключевые колонки присутствуют
    for req in ["raw_name", "stock_qty", "price_retail"]:
        if req not in df.columns:
            for col in df.columns:
                c_clean = str(col).strip().lower()
                if "начальн" in c_clean or "на начало" in c_clean:
                    continue
                for alias in COLUMN_HEADER_KEYWORDS[req]:
                    if alias in c_clean:
                        df = df.rename(columns={col: req})
                        break
                if req in df.columns:
                    break

    if "raw_name" not in df.columns:
        raise ValueError("В выгрузке 1С не найдена колонка Наименования/Номенклатуры.")

    # 3. Фильтрация пустых строк и строк «ИТОГО» / папок
    valid_rows = []
    for idx, row in df.iterrows():
        raw_name = str(row.get("raw_name", "")).strip()
        if not raw_name or raw_name.lower() in ["nan", "none"]:
            continue

        is_total = False
        name_lower = raw_name.lower()
        for pat in TOTAL_ROW_PATTERNS:
            if re.search(pat, name_lower):
                is_total = True
                break
        if is_total:
            continue

        raw_art = str(row.get("raw_article", "")).strip()
        price_val = parse_1c_number(row.get("price_retail", None), default=-1.0)
        stock_val = parse_1c_number(row.get("stock_qty", None), default=-999999.0)

        # Папка иерархии: нет артикула, цена пустая/0, остаток пустой
        if (not raw_art or raw_art.lower() in ["nan", "none"]) and price_val <= 0 and stock_val == -999999.0:
            continue

        valid_rows.append(row)

    if not valid_rows:
        df_clean = pd.DataFrame(columns=df.columns)
    else:
        df_clean = pd.DataFrame(valid_rows).reset_index(drop=True)

    # 4. Нормализация числовых колонок и обработка отрицательных остатков
    if "raw_code" not in df_clean.columns:
        df_clean["raw_code"] = [f"AUTO-{i+1:05d}" for i in range(len(df_clean))]
    else:
        df_clean["raw_code"] = df_clean["raw_code"].fillna("").astype(str).str.strip()

    if "raw_article" not in df_clean.columns:
        df_clean["raw_article"] = ""
    else:
        df_clean["raw_article"] = df_clean["raw_article"].fillna("").astype(str).str.strip()

    clean_stocks = []
    clean_prices = []
    clean_costs = []
    clean_sales = []
    clean_days = []

    for idx, row in df_clean.iterrows():
        s_qty = parse_1c_number(row.get("stock_qty"), 0.0)
        p_ret = parse_1c_number(row.get("price_retail"), 0.0)
        p_cost = parse_1c_number(row.get("price_cost"), round(p_ret * 0.72, 2))
        sales = parse_1c_number(row.get("sales_12m"), 0.0)
        days = int(parse_1c_number(row.get("days_no_movement"), 0.0))

        # Логирование отрицательного остатка (пересортица 1С)
        if s_qty < 0:
            anomaly = {
                "type": "negative_stock_anomaly",
                "raw_code": row.get("raw_code"),
                "raw_name": row.get("raw_name"),
                "original_stock": s_qty,
                "adjusted_stock": 0.0,
                "message": f"Отрицательный остаток в 1С ({s_qty} шт.) приведен к 0 для витрины."
            }
            anomalies.append(anomaly)
            s_qty = 0.0

        clean_stocks.append(s_qty)
        clean_prices.append(p_ret)
        clean_costs.append(p_cost)
        clean_sales.append(sales)
        clean_days.append(days)

    df_clean["stock_qty"] = clean_stocks
    df_clean["price_retail"] = clean_prices
    df_clean["price_cost"] = clean_costs
    df_clean["sales_12m"] = clean_sales
    df_clean["days_no_movement"] = clean_days

    return df_clean, anomalies


# =====================================================================
# 4. БАРЬЕР КОМПЛЕКТАЦИИ (KitGuard: Штука vs Комплект)
# =====================================================================
class KitGuard:
    """
    Предохранитель от опасных склеек одиночной детали с комплектом/набором/парой:
    - 'Комплект прокладок ЗМЗ-406' NEVER matches 'Прокладка ГБЦ ЗМЗ-406'
    - 'Ремкомплект суппорта' NEVER matches 'Суппорт передний'
    - 'Набор шкворней (комплект)' NEVER matches 'Шкворень 1 шт'
    """
    KIT_TOKENS = {
        "комплект", "комплекты", "комплекта", "комплектом",
        "к-т", "к/т", "кт", "к-кт", "компл", "комплектный",
        "ремкомплект", "ремкомплекты", "ремкомплекта", "р/к", "рк",
        "набор", "наборы", "набора", "пара", "пары"
    }
    PIECE_TOKENS = {
        "штука", "штучно", "штучный", "шт", "1 шт", "1шт",
        "отдельно", "голый", "одиночный"
    }

    @classmethod
    def are_conflicting(cls, name1: str, name2: str) -> Tuple[bool, Optional[str]]:
        t1 = set(re.sub(r"[^\w\s]", " ", name1.lower()).split())
        t2 = set(re.sub(r"[^\w\s]", " ", name2.lower()).split())

        has_kit1 = bool(t1 & cls.KIT_TOKENS)
        has_kit2 = bool(t2 & cls.KIT_TOKENS)

        if has_kit1 != has_kit2:
            kit_name = name1 if has_kit1 else name2
            piece_name = name2 if has_kit1 else name1
            return True, f"Конфликт комплектации: '{kit_name}' (комплект) vs '{piece_name}' (штучно)"

        return False, None


# =====================================================================
# 5. АНТОНИМ-ГАРД (AntonymGuard: Стороны, Оси, Положения, Размеры, Моторы)
# =====================================================================
class AntonymGuard:
    """
    Проверяет два наименования деталей на наличие взаимоисключающих параметров:
    1. Сторона: левый vs правый
    2. Ось: передний vs задний
    3. Положение: верхний vs нижний, внутренний vs наружный, впускной vs выпускной
    4. Ремонтные размеры: стд vs 0.25 vs 0.5 vs 0.75 vs 1.0
    5. Двигатели: 402 vs 405 vs 406 vs 4216 vs cummins vs evotech
    6. Комплектация (KitGuard): штука vs комплект
    """

    SIDE_LEFT = {"левый", "левая", "левое", "левые", "лев", "lh", "l"}
    SIDE_RIGHT = {"правый", "правая", "правое", "правые", "прав", "rh", "r"}

    AXIS_FRONT = {"передний", "передняя", "переднее", "передние", "перед", "пер"}
    AXIS_REAR = {"задний", "задняя", "заднее", "задние", "зад"}

    POS_UPPER = {"верхний", "верхняя", "верхнее", "верхние", "верх"}
    POS_LOWER = {"нижний", "нижняя", "нижнее", "нижние", "нижн", "низ"}

    POS_INNER = {"внутренний", "внутренняя", "внутреннее", "внутренние", "внутр"}
    POS_OUTER = {"наружный", "наружная", "наружное", "наружные", "внешний", "внешняя", "внешнее", "внешние", "наруж"}

    VALVE_INLET = {"впускной", "впускная", "впускное", "впускные", "впуск"}
    VALVE_EXHAUST = {"выпускной", "выпускная", "выпускное", "выпускные", "выпуск"}

    REPAIR_SIZES = [
        ("стд", re.compile(r"\b(?:стд|std|номинал)\b", re.IGNORECASE)),
        ("0.25", re.compile(r"\b(?:0[.,]25|р1|r1)\b", re.IGNORECASE)),
        ("0.50", re.compile(r"\b(?:0[.,]50?|р2|r2)\b", re.IGNORECASE)),
        ("0.75", re.compile(r"\b(?:0[.,]75|р3|r3)\b", re.IGNORECASE)),
        ("1.00", re.compile(r"\b(?:1[.,]00?|р4|r4)\b", re.IGNORECASE)),
    ]

    ENGINE_FAMILIES = [
        ("zmz_402", re.compile(r"\b(?:402|змз-?402)\b", re.IGNORECASE)),
        ("zmz_405", re.compile(r"\b(?:405|змз-?405)\b", re.IGNORECASE)),
        ("zmz_406", re.compile(r"\b(?:406|змз-?406)\b", re.IGNORECASE)),
        ("zmz_409", re.compile(r"\b(?:409|змз-?409)\b", re.IGNORECASE)),
        ("umz_4216", re.compile(r"\b(?:4216|умз-?4216)\b", re.IGNORECASE)),
        ("cummins", re.compile(r"\b(?:cummins|каммин[зс]|isf\s*2\.8)\b", re.IGNORECASE)),
        ("evotech", re.compile(r"\b(?:evotech|эвотек|a274|a275)\b", re.IGNORECASE)),
    ]

    @classmethod
    def _extract_tokens(cls, text: str) -> Set[str]:
        # Удаляем знаки препинания (включая точку после сокращений "лев.", "прав.", "пер.", "зад.")
        cleaned = re.sub(r"[^\w\s]", " ", text.lower())
        return set(cleaned.split())

    @classmethod
    def are_conflicting(cls, name1: str, name2: str) -> Tuple[bool, Optional[str]]:
        """
        Возвращает (True, причина), если наименования содержат взаимоисключающие параметры,
        и (False, None), если конфликтов не обнаружено.
        """
        # 0. Проверка комплектации (KitGuard)
        is_kit_conf, kit_reason = KitGuard.are_conflicting(name1, name2)
        if is_kit_conf:
            return True, kit_reason

        toks1 = cls._extract_tokens(name1)
        toks2 = cls._extract_tokens(name2)

        # 1. Сторона
        has_l1 = bool(toks1 & cls.SIDE_LEFT)
        has_r1 = bool(toks1 & cls.SIDE_RIGHT)
        has_l2 = bool(toks2 & cls.SIDE_LEFT)
        has_r2 = bool(toks2 & cls.SIDE_RIGHT)

        if (has_l1 and has_r2) or (has_r1 and has_l2):
            return True, "Конфликт стороны: левый vs правый"

        # 2. Ось
        has_f1 = bool(toks1 & cls.AXIS_FRONT)
        has_b1 = bool(toks1 & cls.AXIS_REAR)
        has_f2 = bool(toks2 & cls.AXIS_FRONT)
        has_b2 = bool(toks2 & cls.AXIS_REAR)

        if (has_f1 and has_b2) or (has_b1 and has_f2):
            return True, "Конфликт оси: передний vs задний"

        # 3. Положение (Верх/Низ)
        has_u1 = bool(toks1 & cls.POS_UPPER)
        has_d1 = bool(toks1 & cls.POS_LOWER)
        has_u2 = bool(toks2 & cls.POS_UPPER)
        has_d2 = bool(toks2 & cls.POS_LOWER)

        if (has_u1 and has_d2) or (has_d1 and has_u2):
            return True, "Конфликт положения: верхний vs нижний"

        # Внутренний / Наружный
        has_in1 = bool(toks1 & cls.POS_INNER)
        has_out1 = bool(toks1 & cls.POS_OUTER)
        has_in2 = bool(toks2 & cls.POS_INNER)
        has_out2 = bool(toks2 & cls.POS_OUTER)

        if (has_in1 and has_out2) or (has_out1 and has_in2):
            return True, "Конфликт положения: внутренний vs наружный"

        # Впуск / Выпуск
        has_vin1 = bool(toks1 & cls.VALVE_INLET)
        has_vout1 = bool(toks1 & cls.VALVE_EXHAUST)
        has_vin2 = bool(toks2 & cls.VALVE_INLET)
        has_vout2 = bool(toks2 & cls.VALVE_EXHAUST)

        if (has_vin1 and has_vout2) or (has_vout1 and has_vin2):
            return True, "Конфликт газораспределения: впускной vs выпускной"

        # 4. Ремонтные размеры
        size1 = None
        for tag, pat in cls.REPAIR_SIZES:
            if pat.search(name1):
                size1 = tag
                break

        size2 = None
        for tag, pat in cls.REPAIR_SIZES:
            if pat.search(name2):
                size2 = tag
                break

        if size1 and size2 and size1 != size2:
            return True, f"Конфликт ремонтного размера: {size1} vs {size2}"

        # 5. Двигатели
        eng1 = None
        for tag, pat in cls.ENGINE_FAMILIES:
            if pat.search(name1):
                eng1 = tag
                break

        eng2 = None
        for tag, pat in cls.ENGINE_FAMILIES:
            if pat.search(name2):
                eng2 = tag
                break

        if eng1 and eng2 and eng1 != eng2:
            if (eng1 == "umz_4216" and eng2 != "umz_4216") or (eng2 == "umz_4216" and eng1 != "umz_4216"):
                return True, f"Конфликт двигателей: {eng1} vs {eng2}"
            if (eng1 == "cummins" and eng2 != "cummins") or (eng2 == "cummins" and eng1 != "cummins"):
                return True, f"Конфликт двигателей: {eng1} vs {eng2}"
            if (eng1 == "evotech" and eng2 != "evotech") or (eng2 == "evotech" and eng1 != "evotech"):
                return True, f"Конфликт двигателей: {eng1} vs {eng2}"
            if (eng1 == "zmz_402" and eng2 != "zmz_402") or (eng2 == "zmz_402" and eng1 != "zmz_402"):
                return True, f"Конфликт двигателей: {eng1} vs {eng2}"

        return False, None


# =====================================================================
# 6. ВАЛИДАЦИЯ И ОЧИСТКА XML / ЗАГОЛОВКОВ ДЛЯ АВИТО
# =====================================================================
def clean_avito_title(title: str, max_len: int = 50) -> str:
    """
    Обрезает заголовок strictly до max_len символов по границе целого слова.
    Никогда не превышает max_len и не разрывает слова.
    """
    if not title:
        return ""
    t = str(title).strip()
    if len(t) <= max_len:
        return t

    cutoff = t[:max_len]
    last_space = cutoff.rfind(" ")
    if last_space > 20:
        return cutoff[:last_space].rstrip(",.-/ ")
    return cutoff.rstrip(",.-/ ")


def sanitize_xml_string(val: Any) -> str:
    """
    Удаляет управляющие символы XML [\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f] и экранирует спецсимволы.
    """
    if val is None or pd.isna(val):
        return ""
    s = str(val)
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)
    return html.escape(s)


# =====================================================================
# 7. XSS И JSON БЕЗОПАСНОСТЬ ДЛЯ FRONTEND HTML
# =====================================================================
def safe_json_dumps(data: Any) -> str:
    """
    Безопасная сериализация JSON для встраивания в тег <script> в HTML:
    - Защита от XSS и закрытия тега script: </script> -> <\\/script>
    - Экранирование HTML-комментариев: <!-- -> <\\!--
    - Экранирование спецсимволов Unicode U+2028 и U+2029
    """
    json_str = json.dumps(data, ensure_ascii=False)
    json_str = json_str.replace("</script>", r"<\/script>")
    json_str = json_str.replace("<!--", r"<\!--")
    json_str = json_str.replace("<script", r"<\script")
    json_str = json_str.replace("\u2028", r"\u2028")
    json_str = json_str.replace("\u2029", r"\u2029")
    return json_str
